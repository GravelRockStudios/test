const assert=require('assert/strict'),fs=require('fs'),path=require('path'),http=require('http'),{chromium}=require('playwright'),C=require('./extract-core.cjs');
const root=path.resolve(__dirname,'..'),key='necropolis-v3-save',errors=[];
const server=http.createServer((req,res)=>{try{const f=path.join(root,new URL(req.url,'http://localhost').pathname);res.setHeader('Content-Type',f.endsWith('.png')?'image/png':f.endsWith('.svg')?'image/svg+xml':'text/html');res.end(fs.readFileSync(f));}catch{res.statusCode=404;res.end();}});
(async()=>{await new Promise(r=>server.listen(0,'127.0.0.1',r));const browser=await chromium.launch({executablePath:process.env.NECRO_CHROMIUM,args:['--no-sandbox','--disable-dev-shm-usage']});
const open=async({width=390,theme='dark',state=C.fresh(),mobile=false,ipad=false}={})=>{
 const ctx=await browser.newContext({viewport:{width,height:1000},hasTouch:mobile||ipad,userAgent:mobile?'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 Mobile/15E148':'Mozilla/5.0'});
 await ctx.addInitScript(({raw,key,theme,ipad})=>{if(!localStorage.getItem(key)){localStorage.setItem(key,raw);localStorage.setItem('necropolis-v3-preferences',JSON.stringify({theme,large:true}));}let now=JSON.parse(localStorage.getItem(key)).last;Date.now=()=>now;window.setInterval=(fn,ms)=>{if(ms===1000){window.__tick=fn;window.__advance=seconds=>{now+=seconds*1000;fn();};}return 0;};if(ipad){Object.defineProperty(navigator,'platform',{get:()=> 'MacIntel'});Object.defineProperty(navigator,'maxTouchPoints',{get:()=>5});}},{raw:C.serialize(state),key,theme,ipad});
 const p=await ctx.newPage();p.on('pageerror',e=>errors.push(e.message));await p.goto(`http://127.0.0.1:${server.address().port}/index.html`);await p.locator('#tabs button').first().waitFor();return {ctx,p};
};
const read=p=>p.evaluate(key=>localStorage.getItem(key),key),step=p=>p.locator('#firstSteps .eyebrow').innerText(),menus=p=>p.locator('#tabs [data-tab]').evaluateAll(els=>els.map(el=>el.dataset.tab));
try{
 for(const width of [320,390,1440])for(const theme of ['dark','light']){
  const {ctx,p}=await open({width,theme,mobile:width<500});
  assert.match(await step(p),/1 of 7/i);assert.deepEqual(await menus(p),['undead','options']);assert.equal(await p.locator('[data-undead-page="upgrades"]').count(),0,'upgrades are introduced after the first milestone');
  assert.equal(await p.locator('#mobileSaveNotice').isVisible(),width<500);
  await p.keyboard.press('5');assert.equal(await p.locator('#tabs [data-tab][aria-current="page"]').getAttribute('data-tab'),'undead','keyboard respects intro menu gates');
  const before=await read(p);await p.locator('[data-action="guideOpen"]').click();assert.equal(await read(p),before,'opening a tour destination spends nothing');
  await p.locator('[data-buy="skeletons"][data-count="1"]').click();assert.equal(C.unpack(await read(p)).n.skeletons.num(),1);assert.match(await step(p),/2 of 7/i,'actual purchase completes first step');assert((await menus(p)).includes('milestones'));assert(!(await menus(p)).includes('empire'));
  await p.reload();await p.locator('#firstStepsTitle').waitFor();assert.match(await step(p),/2 of 7/i,'guided progress survives reload');
  await p.locator('[data-action="guideOpen"]').click();assert.match(await step(p),/3 of 7/i,'viewing earned milestones completes the next step');assert.equal(await p.locator('#undeadTierRail').isVisible(),false,'tiers stay inside Undead');
  // Earn the required resources using real elapsed production and UI purchases.
  await p.locator('#tabs [data-tab="undead"]').click();assert(await p.locator('#undeadTierRail').isVisible());await p.locator('#unitList [data-unit="skeletons"]').click();await p.locator('[data-undead-page="recruitment"]').first().click();
  for(let i=0;i<40;i++){
   const state=C.unpack(await read(p));if(C.affordable(state,'necromancers').cmp(1)>=0)break;
   const buy=p.locator('[data-buy="skeletons"][data-count="max"]');if(await buy.isEnabled())await buy.click();await p.evaluate(()=>window.__advance(120));
  }
  assert(C.affordable(C.unpack(await read(p)),'necromancers').cmp(1)>=0,'earned first Necromancer recipe');
  await p.locator('[data-action="guideOpen"]').click();await p.locator('[data-buy="necromancers"][data-count="1"]').click();assert.match(await step(p),/4 of 7/i);assert(!(await menus(p)).includes('energy'));
  for(let n=1;n<3;n++){
   for(let i=0;i<40&&C.affordable(C.unpack(await read(p)),'necromancers').cmp(1)<0;i++)await p.evaluate(()=>window.__advance(600));
   await p.locator('[data-buy="necromancers"][data-count="1"]').click();
  }
  assert((await menus(p)).includes('energy'));assert.match(await step(p),/4 of 7/i,'unlock alone does not complete the visit');
  await p.locator('[data-action="guideOpen"]').click();assert.match(await step(p),/5 of 7/i);assert((await menus(p)).includes('empire'));assert(!(await menus(p)).includes('automation'));
  await p.locator('[data-action="guideOpen"]').click();assert.match(await step(p),/6 of 7/i);assert((await menus(p)).includes('automation'));
  await p.locator('[data-action="guideOpen"]').click();assert.match(await step(p),/7 of 7/i);assert(!(await menus(p)).includes('ritual'));
  await p.locator('[data-action="guideOpen"]').click();await p.locator('[data-action="makeSaveCode"]').click();await p.waitForFunction(()=>document.getElementById('portableSaveCode').value.startsWith('NECRO-SAVE-9.'));
  assert(await p.locator('#firstSteps').isHidden(),'successful backup creation completes tour');assert((await menus(p)).includes('ritual'));assert.match(await p.locator('#guideAnnouncement').innerText(),/outside the browser/);
  await p.reload();await p.locator('#tabs button').first().waitFor();assert(await p.locator('#firstSteps').isHidden());
  if(width<500){await p.locator('[data-action="backupReminder"]').click();assert.equal(await p.evaluate(()=>document.activeElement.dataset.action),'makeSaveCode');}else await p.locator('#tabs [data-tab="options"]').click();
  await p.locator('[data-action="guideReplay"]').click();assert.match(await step(p),/Review introduction.*1 of 7/i);assert((await menus(p)).includes('ritual'),'review does not hide unlocked menus');await p.evaluate(()=>window.__tick());assert.match(await step(p),/1 of 7/i,'review never auto-skips existing progress');
  await p.locator('[data-action="guideSkip"]').focus();await p.keyboard.press('Enter');assert(await p.locator('#firstSteps').isHidden());
  assert(await p.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));await ctx.close();console.log(`PASS ${width}px ${theme}: all 7 goals auto-advance from real gameplay, gated menus, reload, backup, manual replay, mobile navigation`);
 }
 const fresh=await open();await fresh.p.locator('[data-action="guideSkip"]').click();assert.deepEqual(await menus(fresh.p),['undead','empire','automation','ritual','milestones','options'],'skip restores normal gameplay gates');await fresh.p.reload();await fresh.p.locator('#tabs button').first().waitFor();assert(await fresh.p.locator('#firstSteps').isHidden());await fresh.ctx.close();
 const state=C.fresh();state.prestiges=1;const old=await open({state,ipad:true});assert(await old.p.locator('#firstSteps').isHidden());assert(await old.p.locator('#mobileSaveNotice').isVisible());assert((await menus(old.p)).includes('automation'));await old.ctx.close();
 assert.deepEqual(errors,[]);console.log('PASS skip, returning players and iPad backup reminder; no browser errors');
}finally{await browser.close();server.close();}
})().catch(e=>{console.error(e);server.close();process.exitCode=1;});
