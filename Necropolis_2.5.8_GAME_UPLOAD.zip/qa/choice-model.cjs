// Same economic engine and spending policy; change only the declared research choice.
const fs=require('fs'),path=require('path'),C=require(process.env.NECRO_MODEL_CORE||'./extract-core.cjs'),M=require('./balance-model.cjs');
const rows=[];
for(const doctrine of ['horde','lich','cult'])for(const research of ['seeds','binding','warfare','night']){
 const profile={doctrine,research,minutes:5,warps:true,offeringMinutes:60},s=C.fresh();let t=0,observations=0,missing={souls:0,graveSeeds:0,predecessor:0};
 for(;t<=90*86400;t+=300){
  const i=C.IDS.findIndex(id=>s.n['total_'+id].cmp(1)<0);
  if(i>=4){observations++;if(s.n.souls.cmp(C.SOUL_COST[i])<0)missing.souls++;if(s.n.graveSeeds.cmp(C.SEED_COST[i])<0)missing.graveSeeds++;if(s.n[C.IDS[i-1]].cmp(C.PREV_COST[i])<0)missing.predecessor++;}
  M.act(s,profile,t);if(s.n.total_endbringers.cmp(1)>=0)break;C.advance(s,300);
 }
 const row={...profile,reached:s.n.total_endbringers.cmp(1)>=0,hours:+(t/3600).toFixed(2),observations,missingAtCheckIn:missing};rows.push(row);console.log(JSON.stringify(row));
}
fs.writeFileSync(process.env.NECRO_CHOICES_OUTPUT||path.join(__dirname,'choice-results-2.3.0.json'),JSON.stringify({assumptions:'Change only research choice; balanced plots; Cult buries 10% hourly. Counts allow multiple missing ingredients, not exclusive waiting-time shares. No ascensions, 90-day horizon.',rows},null,2));
