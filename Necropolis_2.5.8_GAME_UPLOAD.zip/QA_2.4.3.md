# Necropolis 2.4.3 — Automation emblems

The Automation submenu now uses the same artwork and icon frames as the main navigation. Overview uses the existing automation gear, Undead uses the army banner, Conquest uses crossed swords, and Resources uses Grave Seeds. Each page heading shows its corresponding emblem. Text labels remain visible; decorative images do not add duplicate screen-reader labels.

Verification completed:

- Existing template and Automation browser suites passed.
- Navigation checked at 320, 390, 900 and 1440 pixels, in dark and light themes, with no page or submenu overflow.
- Keyboard, touch, responsive resizing, focus retention and remembered sections passed.
- All 50 buyer switches, saved settings, an actual buyer cycle, V8 restore and post-ascension locks passed the existing browser checks.
- Desktop and phone screenshots were visually inspected. Selected screenshots are in `qa/screenshots-2.4.3/`.
- Production and milestone scripts, every original art asset, and the license are unchanged from 2.4.2. Save format and game balance are unchanged.

Tests used headless Chromium. Native iPhone Safari and live itch.io were not tested. Earlier reports describe their respective builds; this update reran the two existing suites relevant to the presentation change.

Upload `Necropolis_2.4.3_upload.zip` with `index.html` at its root. No publication was performed.
