# 2.4.7 pacing audit

The aim is meaningful idle progression with clear ways to improve production. This update does not remove the Seed budget or the tier-to-tier army requirements.

## Reproduced issues and changes

Automatic buyers could repeatedly consume the Seeds needed for the first purchase of the next undead tier. A percentage reserve alone is insufficient: with small recurring income, the balance converges below the next tier's price. Buyers now protect one first-purchase Seed budget for the next unraised, revealed undead tier. The larger of this floor and the chosen percentage is kept; they do not stack. This applies at every percentage, including 0%. Manual purchases can spend it. Once every tier has been raised, the floor is zero. Seed research can continue using Souls and Territory while Seeds accumulate. Brief Automation help describes the rule.

The last Soul-price jumps were steeper than the rest of the progression. Prices now rise more gradually from Dreadlords onward. The associated Empowerment and Multiplicity Soul prices use these same bases, so the corresponding upgrades become more accessible too.

| Unit | Previous Souls per purchase | New Souls per purchase | Seed price (unchanged) |
|---|---:|---:|---:|
| Deathlords | 150,000,000 | 150,000,000 | 10,000 |
| Dreadlords | 2e12 | 1e12 | 100,000 |
| Grave Kings | 5e17 | 1e17 | 1,000,000 |
| Eternal Sovereigns | 2e23 | 1e22 | 10,000,000 |
| Void Regents | 1e29 | 2e27 | 100,000,000 |
| Endbringers | 1e35 | 1e33 | 1,000,000,000 |

Early prices, previous-unit recipes, passive production rates, the escalating refill horizons, Grave Bloom, other permanent blessings and upgrade growth factors are unchanged. Existing unit counts, upgrade ranks and saves are retained; there is no reset or retrospective refund.

## Earned-resource comparison

All samples start fresh, spend earned resources, choose Horde, allocate 20% to conquest and 10% to excavation, invest in Seed production, rotate campaigns and progress through all ten tiers without ascending. The manual policy buys at most one ordinary upgrade of each kind per visit and at most one earned warp when enabled. The buyer policy also enables available undead recruitment and production/multiplicity/Seed upgrades with the default 50% reserve and offline spending. These are reproducible strategy samples, not promised player completion times.

| Check-in policy | 2.4.6 first Endbringers | 2.4.7 first Endbringers |
|---|---:|---:|
| Every 5 minutes, earned warps | 8h 5m | 6h 45m |
| Hourly, no warps or buyers | 32d 3h | 22d 13h |
| Every 8h, no warps or buyers | 37d 8h | 27d 16h |
| Daily, no warps or buyers | 50d | 41d |
| Every 8h, offline buyers, no warps | Not reached by 60d (Grave Kings) | 22d |

With eight-hour check-ins and no buyers/warps, Deathlords still arrive at 72h, Dreadlords at 104h and Grave Kings at 144h. The main excess was later: the Void Regent-to-Endbringer gap falls from 528h to 320h. Both Souls and prior-tier units still constrain the final unlock. Seeds remain a meaningful investment resource, especially with buyers enabled.

The active and eight-hour manual strategies were also exercised through actual browser UI handlers, including earned ascension and a Grave Bloom purchase. The scripted economy and browser progression agree. See QA_2.4.7.md and qa/results-2.4.7.

## Reproduction

Run `node qa/pacing-247.cjs` from the uploaded project to write `qa/balance-2.4.7.json`. Set `NECRO_AUDIT_CORE` to a CommonJS-exporting earlier engine and `NECRO_AUDIT_OUTPUT` to a separate path for comparison. Baseline observations are retained in `qa/balance-baseline-2.4.6.json`. Blocked-resource hours overlap; they must not be summed.

No supplied late-game player save was available. The audit covers costs, reproducible strategies and save compatibility, not every possible build or long-term prestige strategy.
