const assert=require('assert'),C=require('./extract-core.cjs'),N=C.N;
const near=(a,b)=>assert(Math.abs(N.of(a).div(b).num()-1)<1e-8);
// Each next tier, all percentage settings: upgrades and cheap recruits cannot
// spend the first-purchase Seed budget, but direct recruitment can use it.
for(let i=1;i<C.IDS.length;i++)for(const reserve of [0,25,50,75]){
 const s=C.fresh();for(let j=0;j<i;j++){s.n[C.IDS[j]]=N.of(10000);s.n['total_'+C.IDS[j]]=s.n[C.IDS[j]];}
 s.n.souls=N.of('1e90');s.n.territory=N.of('1e90');s.n.totalTerritory=N.of('1e90');s.n.graveSeeds=N.of(C.SEED_COST[i]);s.autoConfig.units=C.IDS.filter(id=>C.autoBuyerUnlocked(s,id));s.autoConfig.upgrades=C.AUTO_UPGRADES.filter(id=>C.autoUpgradeUnlocked(s,id));s.autoConfig.reserve=reserve;
 near(C.nextTierSeedReserve(s),C.SEED_COST[i]);C.autoBuy(s);near(s.n.graveSeeds,C.SEED_COST[i]);assert(C.buy(s,C.IDS[i],1));assert.equal(s.n.graveSeeds.num(),0);
 const old=C.serialize(s);assert.equal(C.serialize(C.unpack(old)),old);
}
// Reproduced starvation: Seeds slowly accumulate even with cheap buyers left on.
for(const reserve of [0,50,75]){
 const s=C.fresh();s.n.souls=N.of('1e30');s.n.skeletons=N.of(10000);s.n.total_skeletons=N.of(10000);s.n.necromancers=N.of(100);s.n.total_necromancers=N.of(100);s.n.liches=N.of(1);s.n.total_liches=N.of(1);s.n.graveSeeds=N.of(0);s.autoConfig.units=['skeletons','necromancers'];s.autoConfig.reserve=reserve;
 for(let i=0;i<1500;i++){s.n.graveSeeds=s.n.graveSeeds.add(1);C.autoBuy(s);}near(s.n.graveSeeds,1500);s.n.liches=N.of(72);assert(C.buy(s,'deathlords',1));
}
// Once every tier is raised there is no floor. It does not stack with percentage.
const s=C.fresh();for(const id of C.IDS)s.n['total_'+id]=N.of(1);assert.equal(C.nextTierSeedReserve(s).num(),0);
console.log('PASS next-tier Seed protection at all nine gates/four reserves, manual access, serialization, and reproduced slow-income starvation');
