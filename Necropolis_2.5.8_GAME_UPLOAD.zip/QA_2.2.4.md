# Necropolis 2.2.4 — wording consistency

| Previous active wording | Current feature name |
| --- | --- |
| Teachings / Lost teachings / teaching levels | Empire Research / Empire Research levels |
| Buildings / building costs / territory development | Territory Development / developed plots / development cost |
| Patient Ruler reward | +1 starting Empire Research level |
| Soul Harvesting | Grave Seed Cultivation |
| Expand Domain / Domain Expansion | Grave Seed Expansion |
| Energy Storage | Dark Energy Storage |

Updated active upgrade cards, Empire, Ritual, challenge rewards, milestones, notifications, tips and bonus comparisons. Research specialties retain their names (Bonebinding, Warcraft, Night Studies, Grave Studies); each description names the affected production. Historical changelogs retain the terminology used at release. Saved keys and milestone IDs are unchanged.

Territory Development's next-plot display now subtracts the full permanent Claimed Ground rank before calculating the next unlock threshold. This corrects the displayed requirement; the unlock formula itself is unchanged.

Browser coverage at 390px and 1440px checks feature names, resource names, milestone references, actual research and development actions, starting research levels, multi-rank plot text, overflow and script errors. Core progression and save-format checks cover unchanged gameplay and old-save compatibility.

Passed: both browser sizes, 40 core scenarios, 14 progression scenarios, 12 enduring progression scenarios, script/template checks, 100 save precision fixtures, retired Blueprint imports and all supported portable-save round trips. Artwork, embedded icons, license and frozen save dictionaries were compared byte-for-byte with 2.2.3 before packaging.
