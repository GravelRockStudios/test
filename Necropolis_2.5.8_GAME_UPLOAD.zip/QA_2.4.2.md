# Necropolis 2.4.2 — Automation navigation

Automation is split into four focused pages within a navigation submenu:

- **Overview:** start/pause, shared reserve, offline buying, a compact Seed budget, and optional buying rules.
- **Undead:** one row per relevant tier with Recruit, Empower and Multiply controls.
- **Conquest:** one row per relevant troop tier and a link to the existing campaign settings.
- **Resources:** Grave Seed and Dark Energy upgrade buyers.

Desktop shows the submenu directly below Automation. Phone and tablet layouts show all four choices beneath the main navigation. The Undead tier navigator is hidden while Automation is open. The most recently chosen Automation page survives reloads as a display preference. Newly unlocked buyers still begin Off.

Repeated descriptions and cost paragraphs were removed from the Automation roster. Full purchase costs remain on the respective Undead and Territory pages. The master buyer control remains available on every Automation page. Detailed buying rules are available in one expandable section on Overview; its open state survives ticks and page changes during the session.

## Verification

All nine suites in `qa/run-242.cjs` passed. Detailed logs are in `qa/results-2.4.2/`.

- New navigation checked at 320, 390, 900 and 1440 pixels in dark and light themes.
- Desktop placement, mobile placement, responsive resizing, keyboard navigation, touch interaction, focused-control retention during ticks and remembered page selection verified.
- All 15 recruitment switches and 35 upgrade switches are reachable. Their selections, reserve, master switch and offline preference survive reload and V8 save-code restore.
- A real five-minute buyer cycle matches the existing simulation. Ascension pauses buyers and clears locked choices.
- Navigation alone does not alter the gameplay save. Fresh saves show relevant tiers and disable locked controls. No horizontal page/submenu overflow or uncaught page errors occurred.
- Existing production, preview isolation, campaign timing/warps, V7 and V8 restore, offline-report accounting and damaged-save recovery checks passed.
- Screenshots were inspected for desktop and phone layouts. Selected screenshots are included in `qa/screenshots-2.4.2/`.

The production and milestone scripts are byte-identical to 2.4.1. All original artwork and the license are unchanged. Save schema remains 23 and exports remain NECRO-SAVE-8. This is a navigation and presentation update; no prices, growth curves, reserves or buyer priorities changed.

Testing used headless Chromium with desktop and mobile viewports. Live itch.io and native iPhone Safari were not tested. The 2.4.1 full-play results and earlier reports remain historical; their layout-specific test selectors refer to the older Automation page. Use `qa/run-242.cjs` for this layout.

Upload `Necropolis_2.4.2_upload.zip` with `index.html` at its root. This package has not been published to itch.io.
