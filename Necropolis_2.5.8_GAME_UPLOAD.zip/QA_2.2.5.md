# Necropolis 2.2.5 — fixes-to-ship follow-up

Source: QA handoff dated 2026-10-01, originally tested on v2.2.2. Patch applied to v2.2.4.

## Addressed

- **S1 Grave Seed top-bar visibility:** the Seed rate now shows an estimated net rate while automatic buyers are running. The detail/tooltip separates gross production, projected buyer spending, and estimated net production.
- **S2 Buyer drain safeguards:** retained the existing shared reserve, higher-tier-first buyer priority, prominent per-batch Seed costs, and over-spend warning already present in v2.2.4.
- **S3 Locked buyer state:** re-verified locked buyers render as disabled and say `Locked`; they cannot retain a misleading `On` display.
- **Campaign milestone toast:** current payout path checks milestones in the same progression tick before render. Milestone IDs remain session-deduplicated.
- **Dark Energy capacity:** retained exact-capacity detail/tooltip while compact headline notation remains readable.
- **Ascension shard copy:** core test verifies current shards plus projected award carry over exactly; the confirmation uses those live values.

## Design decisions closed

- **Deathlord pricing:** keep flat per-unit recipe pricing. The engine intentionally uses flat unit recipe costs across tiers; quantity purchases scale linearly. This is not treated as a Deathlord-specific bug.
- **Archlich → Deathlord wall:** keep the current wall. Seeds are intentionally the binding resource and the QA report found the pacing slow but healthy.
- **itch.io mobile saves:** keep the existing manual-save/export guidance prominent. No browser-storage behavior was changed.

## Verification

Passed locally:

- 40 core scenarios (`qa/verify.cjs`)
- 14 progression scenarios (`qa/progression.cjs`)
- 12 enduring-progression scenarios (`qa/enduring.cjs`)
- rendering/template regression checks (`qa/rendering.cjs`)
- 6 conquest-timing scenarios (`qa/conquest-timing.cjs`)

Browser automation suites could not be executed in this environment because the Playwright package is not installed. No artwork files were modified.
