const assert=require('assert'),C=require('./extract-core.cjs'),N=C.N;
const near=(a,b)=>{if(!N.of(a).m&&!N.of(b).m)return;assert(Math.abs(N.of(a).div(b).num()-1)<1e-8,`${a} != ${b}`);};
for(let i=0;i<5;i++){
 const id=C.TERRITORY_IDS[i],s=C.fresh();s.n.total_necromancers=N.of(5);if(i)s.n['total_'+C.TERRITORY_IDS[i-1]]=N.of(1);s.n.souls=N.of('1e30');s.n.graveSeeds=N.of(C.CONQUEST_SEED_COST[i]*3-1);
 assert.equal(C.conquestAffordable(s,id).num(),2);const before=s.n.graveSeeds;assert(C.buyConquest(s,id,2));near(s.n.graveSeeds,before.sub(C.CONQUEST_SEED_COST[i]*2));assert.equal(C.conquestAffordable(s,id).num(),0);near(C.conquestPrices(id,2).prev,C.CONQUEST_SEED_COST[i]*2);
 if(i){near(C.TERRITORY_RATES[i]/C.CONQUEST_SEED_COST[i]/(C.TERRITORY_RATES[i-1]/C.CONQUEST_SEED_COST[i-1]),4.5);near(C.TERRITORY_RATES[i]/C.TERRITORY_COST[i].num()/(C.TERRITORY_RATES[i-1]/C.TERRITORY_COST[i-1].num()),.1);}
}
for(const level of [0,1,10,30,100]){const s=C.fresh();s.upgrades.upgrades=level;near(C.graveSeedRate(s),1+level+.10*level*level);const old=C.graveSeedRate(s);s.upgrades.upgrades++;assert(C.graveSeedRate(s).cmp(old)>0);}
const s=C.fresh();s.empire.buildings.crypts=5;s.empire.campaigns.completed=['academy'];const old=C.perUnit(s,'necromancers');s.empire.campaigns.stages={academy:2};assert(C.perUnit(s,'necromancers').cmp(old)>0);assert(C.campaignReward(s,'academy').includes('Crypts'));assert(C.campaignReward(s,'academy').includes('→'));
// The estimate must track real purchases, with natural growth, army assignment and troops.
for(const mutation of [s=>C.buyUpgrade(s,'tier_necromancers',1),s=>C.buyConquest(s,'raiders',10000),s=>C.chooseDoctrine(s,'lich'),s=>C.develop(s,'crypts')]){
 const a=C.fresh();a.n.souls=N.of('1e15');a.n.territory=N.of('1e15');a.n.graveSeeds=N.of('1e6');a.n.totalTerritory=N.of('1e6');a.n.necromancers=N.of(100);a.n.total_necromancers=N.of(100);a.n.skeletons=N.of(1000);a.n.total_skeletons=N.of(1000);a.empire.conquest=20;a.empire.campaigns.completed=['cemetery'];a.empire.campaigns.stages={cemetery:3};C.startCampaign(a,'cemetery');
 const before=C.campaignCompletionForecast(a,'cemetery');assert(mutation(a));const after=C.campaignCompletionForecast(a,'cemetery');assert(after.seconds<before.seconds);
 const early=C.copyState(a),done=C.copyState(a);C.advance(early,after.seconds-.01);C.advance(done,after.seconds+.01);assert.equal(C.campaignLevel(early,'cemetery'),3);assert.equal(C.campaignLevel(done,'cemetery'),4);
}
console.log('PASS conquest Seed prices, efficiency tradeoffs, Cultivation curve, Academy production reward and post-purchase completion boundaries');
