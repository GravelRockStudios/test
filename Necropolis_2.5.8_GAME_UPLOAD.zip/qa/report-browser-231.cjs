const fs=require('fs'),path=require('path'),http=require('http'),assert=require('assert');
const {chromium}=require('playwright'),C=require('./extract-core.cjs'),N=C.N;
const root=path.resolve(__dirname,'..'),key='necropolis-v3-save';
const server=http.createServer((req,res)=>{const file=path.join(root,new URL(req.url,'http://localhost').pathname);if(!file.startsWith(root+path.sep)){res.statusCode=403;return res.end();}try{res.setHeader('Content-Type',file.endsWith('.png')?'image/png':file.endsWith('.svg')?'image/svg+xml':'text/html');res.end(fs.readFileSync(file));}catch{res.statusCode=404;res.end();}});
function near(a,b){a=N.of(a);b=N.of(b);if(!a.m&&!b.m)return;assert(Math.abs(a.div(b).num()-1)<1e-8,`${a} != ${b}`);}
(async()=>{
 await new Promise(r=>server.listen(0,'127.0.0.1',r));
 const browser=await chromium.launch({headless:true,executablePath:process.env.NECRO_CHROMIUM,args:['--no-sandbox','--disable-dev-shm-usage','--disable-gpu']});
 try{
  for(const width of [390,1440]){
   const errors=[];
   async function open(s){
    const ctx=await browser.newContext({viewport:{width,height:1000},hasTouch:width===390});
    await ctx.addInitScript(({raw,key,now})=>{window.__qaNow=now;Date.now=()=>window.__qaNow;window.__qaTicks=[];window.setInterval=(fn,ms)=>{if(ms===1000)window.__qaTicks.push(fn);return 0;};if(!localStorage.getItem(key))localStorage.setItem(key,raw);},{raw:C.serialize(s),key,now:s.last});
    const page=await ctx.newPage();page.on('pageerror',e=>errors.push(e.message));await page.goto(`http://127.0.0.1:${server.address().port}/index.html`);await page.locator('#tabs').waitFor();
    const tab=id=>page.locator(`#tabs [data-tab="${id}"]`).click();
    const read=async()=>C.unpack(await page.evaluate(key=>localStorage.getItem(key),key));
    const tick=seconds=>page.evaluate(seconds=>{window.__qaNow+=seconds*1000;for(const fn of window.__qaTicks)fn();},seconds);
    return {ctx,page,tab,read,tick};
   }
   const zero=C.fresh();zero.n.total_necromancers=N.of(5);zero.n.total_skeletons=N.of(10);
   let {ctx,page,tab}=await open(zero);
   await tab('territory');
   const chip=page.locator('#resources .resource').filter({has:page.locator('span', {hasText:/^Territory$/})});
   assert.equal(await chip.locator('b').innerText(),'0');
   assert.deepEqual(await page.locator('#content .summary-grid .kpi strong').allTextContents(),['0','0','+0/hr']);
   const zeroFacts=await page.locator('#content .conquest-detail .production-facts').innerText();assert(zeroFacts.includes('You own 0'));
   // Click the button, nested text and icon; also keyboard and actual touch input.
   for(const target of ['', ' .tab-label',' .tab-art']){
    await tab('options');await page.locator(`#tabs [data-tab="undead"]${target}`).click();assert.equal(await page.locator('#tabs [data-tab="undead"]').getAttribute('aria-current'),'page');assert(await page.locator('.tier-overview').isVisible());
   }
   for(let i=0;i<12;i++){await tab(i%2?'energy':'territory');await tab('undead');assert(await page.locator('.tier-overview').isVisible());}
   await tab('options');await page.locator('#tabs [data-tab="undead"]').focus();await page.keyboard.press('Enter');assert(await page.locator('.tier-overview').isVisible());
   if(width===390){await tab('options');await page.locator('#tabs [data-tab="undead"] .tab-label').tap();assert(await page.locator('.tier-overview').isVisible());}
   await page.locator('#mode').click();await tab('territory');assert.equal(await chip.locator('b').innerText(),'0');
   assert.deepEqual(await page.locator('.territory-tier-card').evaluateAll(rows=>rows.map(r=>({image:getComputedStyle(r).backgroundImage,color:getComputedStyle(r).backgroundColor}))),[{image:'none',color:'rgb(232, 217, 187)'},{image:'none',color:'rgb(228, 229, 230)'}]);
   assert(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));
   if(process.env.NECRO_SCREENSHOT_DIR)await page.screenshot({path:path.join(process.env.NECRO_SCREENSHOT_DIR,`zero-territory-${width}.png`),fullPage:true});
   await ctx.close();
   const unlock=C.fresh();unlock.n.souls=N.of('1e30');unlock.n.graveSeeds=N.of('1e8');unlock.n.territory=N.of(1000);unlock.n.totalTerritory=N.of(25);
   for(const [id,n]of [['skeletons',1000],['necromancers',5],['liches',1000],['deathlords',1e6],['sovereigns',96]]){unlock.n[id]=N.of(n);unlock.n['total_'+id]=N.of(n);}
   unlock.autoEnabled=true;unlock.autoConfig.units=['sovereigns'];unlock.autoConfig.offline=true;
   let read,tick;({ctx,page,tab,read,tick}=await open(unlock));
   await tab('automation');assert.equal(await page.locator('[data-auto-unit="sovereigns"]').innerText(),'Locked');
   assert.deepEqual((await read()).autoConfig.units,[]);
   await tab('undead');await page.locator('#unitList [data-unit="gravekings"]').click();await page.locator('[data-buy="gravekings"][data-count="1"]').click();
   await tab('automation');assert.equal(await page.locator('[data-auto-unit="sovereigns"]').innerText(),'Off');
   // Undoing the unlocking purchase must not hide and later resurrect an On choice.
   await page.locator('[data-auto-unit="sovereigns"]').click();await page.locator('[data-action="undoPurchase"]').click();
   assert.equal(await page.locator('[data-auto-unit="sovereigns"]').innerText(),'Locked');assert.deepEqual((await read()).autoConfig.units,[]);
   await tab('undead');await page.locator('#unitList [data-unit="gravekings"]').click();await page.locator('[data-buy="gravekings"][data-count="1"]').click();
   await tab('automation');assert.equal(await page.locator('[data-auto-unit="sovereigns"]').innerText(),'Off');
   const before=await read(),plain=C.copyState(before);C.advance(plain,300);await tick(300);
   // Force a save via a harmless reserve selection after the exact cycle.
   await page.locator('[data-auto-reserve="50"]').click();const after=await read();near(after.n.graveSeeds,plain.n.graveSeeds);assert.deepEqual(after.autoConfig.units,[]);
   await page.locator('[data-auto-unit="sovereigns"]').click();assert.deepEqual((await read()).autoConfig.units,['sovereigns']);await page.reload();await tab('automation');assert.equal(await page.locator('[data-auto-unit="sovereigns"]').innerText(),'On');
   await ctx.close();
   // Same bonuses, two owned counts: the real Each produces field must agree.
   const rates=[];
   for(const count of [1,47]){
    const s=C.copyState(unlock);s.autoConfig.units=[];s.autoEnabled=false;s.empire.doctrine='horde';s.n.sovereigns=N.of(count);s.n.total_sovereigns=N.of(count);s.blessings.summonBlessing=102;s.blessings.harvestBlessing=58;
    ({ctx,page,tab}=await open(s));await page.locator('#unitList [data-unit="sovereigns"]').click();
    rates.push(await page.locator('.tier-stat').filter({hasText:'Each produces'}).locator('strong').innerText());
    const total=await page.locator('.tier-stat').filter({hasText:'Total production'}).locator('strong').innerText();assert(total.endsWith('/hr'));
    await page.locator('#unitList [data-unit="deathlords"]').click();assert((await page.locator('[data-upgrade="tier_deathlords"]').first().locator('xpath=ancestor::div[contains(@class,"upgrade-card")]').innerText()).includes('Liches production from Archliches'));
    await ctx.close();
   }
   assert.equal(rates[0],rates[1]);
   // Complete a campaign via real elapsed production; not via preview rendering.
   const campaign=C.fresh();campaign.n.totalTerritory=N.of(25);campaign.n.total_necromancers=N.of(5);campaign.n.raiders=N.of(100);campaign.n.total_raiders=N.of(100);C.startCampaign(campaign,'cemetery');
   const wait=C.campaignSecondsRemaining(campaign,'cemetery');assert(wait>1);C.advance(campaign,wait-.5);campaign.last=Date.now();
   ({ctx,page,tab,read,tick}=await open(campaign));await tab('territory');assert.equal(await page.locator('#milestoneToast.visible').count(),0);
   assert.equal(C.campaignLevel(await read(),'cemetery'),0);await tick(1);
   assert(await page.locator('#milestoneToast.visible').isVisible());assert((await page.locator('#milestoneToast').innerText()).includes('Milestone'));
   await tab('automation');await page.locator('[data-auto-reserve="50"]').click();let won=await read();assert.equal(C.campaignLevel(won,'cemetery'),1);assert(won.achievements.includes('campaign_cemetery_1'));
   await page.evaluate(()=>document.querySelector('#milestoneToast').textContent='No new notification');await tick(1);assert.equal(await page.locator('#milestoneToast').innerText(),'No new notification');
   await ctx.close();
   // Accept the actual ascension dialog and verify kept + awarded shards.
   const asc=C.copyState(unlock);asc.autoConfig.units=[];asc.autoEnabled=false;asc.n.runSouls=N.of('1e12');asc.shards=N.of(15);const award=C.ascensionReward(asc);
   ({ctx,page,tab,read}=await open(asc));await tab('ritual');await page.locator('[data-action="ascend"]').click();assert((await page.locator('#confirmBody').innerText()).includes('keep your 15 current shards'));await page.locator('[data-confirm="accept"]').click();near((await read()).shards,N.of(15).add(award));await ctx.close();
   // The UI preview uses the same projected resources as the actual cast.
   const warp=C.copyState(unlock);warp.autoConfig.units=[];warp.autoEnabled=false;warp.energy=5000;warp.upgrades.warpMastery=2;warp.empire.conquest=20;
   ({ctx,page,tab,read}=await open(warp));await tab('energy');const expected=C.warpProjection(await read(),.25);
   for(const row of await page.locator('[data-warp-resource]').evaluateAll(rows=>rows.map(r=>({key:r.dataset.warpResource,gain:r.dataset.warpGain}))))near(row.gain,expected.gains[row.key]);
   await page.locator('[data-warp="0.25"]').click();const cast=await read();for(const key of Object.keys(cast.n))near(cast.n[key],expected.state.n[key]);assert.equal(cast.energy,3000);await ctx.close();
   assert.deepEqual(errors,[]);console.log(`PASS ${width}px: zero Territory, mouse/text/icon/keyboard/touch navigation, fresh buyer unlock and reload, 1 vs 47 Deathlord rate, conquest toast once, kept shards, warp preview/cast; no overflow or script errors`);
  }
 }finally{await browser.close();await new Promise(r=>server.close(r));}
})().catch(e=>{console.error(e);process.exitCode=1;server.close();});
