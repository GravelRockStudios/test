# Necropolis 2.4.6 — Local save continuity

This release hardens concurrent-tab saving without a server, account or cloud storage. It does not establish the cause of the reported historical loss or recover data that is no longer present.

## Changes

- Acquire an exclusive browser Web Lock before restoring, advancing or saving the game. Only the owning document can mutate progress and write game/recovery storage.
- Other tabs open read-only, with a visible explanation and reload button. Purchases, automation changes, resets and restores are blocked. Navigation and external backup exports remain available.
- Close the active tab, then reload the other tab to acquire ownership and restore the latest stored progress. No stale in-memory takeover is allowed.
- Normal page exit saves and refreshes a recovery checkpoint before releasing ownership. Browser back/forward restoration reloads from storage before playing again.
- Check for external changes before actions as well as before saves. Removed the exception that trusted an older save merely because its writer ID matched this tab; a rolled-back revision is now detected.
- Verify the primary write by reading it back. Tabs without usable coordination support remain read-only instead of attempting unsafe concurrent writes.

The Web Lock stays held while its owning page is alive, including when that tab is in the background. This avoids timers or an expiring lease allowing a suspended tab to overwrite another session. Technical reference: https://www.w3.org/TR/web-locks/ .

## Verification

Five suites passed:

- `save-tabs-246.cjs`: two tabs sharing real browser storage; idle-tab purchase/reset blocking; export without writing; owner closure and reload; close-time recovery after the primary key is removed; three simultaneous-launch races with exactly one writer; detection of an older same-writer save with storage events suppressed; simulated back/forward lifecycle; absent and rejected lock APIs. No page errors or horizontal overflow at phone/desktop widths. Read-only banners visually inspected.
- `reliability-browser-241.cjs`: offline production/spending reports, corrupt-primary recovery, preservation of damaged saves, valid backup restore and export while storage writes fail.
- `restore-browser-241.cjs`: original V7 code and V8 code/file restoration with offline buying enabled and disabled.
- `automation-browser-242.cjs`: all 50 switches, remembered settings, live buyer cycle, save-code restoration, ascension locks, keyboard/touch, dark/light and four viewport widths.
- `rendering.cjs`: template regressions and script syntax.

## Limits and rollout

Close all old-version game tabs before loading this build. Old code cannot be retroactively made to honor the new lock. Different browser profiles, devices and storage origins remain separate; this is not cloud synchronization. Clearing all browser storage can remove both the main save and local backups, so downloaded backups and save codes remain useful.

If browser coordination is unavailable or denied, the game explains that the tab is read-only and recommends opening the HTTPS game in an up-to-date browser. It does not silently fall back to competing writers.

Testing used headless Chromium, including an itch-style sandboxed iframe in existing suites. Browser back/forward lifecycle was simulated; native iPhone Safari, real tab crashes and live itch.io were not tested. No publication was performed.

Production and milestone scripts, save schema 23 / NECRO-SAVE-8, all original artwork and the license are unchanged from 2.4.5.
