# 2.4.9 balance investigation

The supplied V8 code passed its checksum and imported without changing resources,
upgrades, blessings, or buyer selections. It contains about 1.25Qa Skeletons,
73.9B Necromancers, 29.3M Liches, 45.1K Archliches, 2.34K Deathlords, and only
2 Dreadlords. The next Grave King purchase requires more Dreadlords.

The highest owned tier's Recruit and Multiplicity were gated behind ownership
of its producer. This prevents automating the very tier needed to advance.
Both now unlock with the first unit of their own tier. No future tier is
automatically enabled, and existing choices remain unchanged.

## Production and recipes

Necromancer base Skeleton output is 0.14/sec instead of 0.35/sec. All other
base production rates are unchanged. This reduces new Skeleton production by
60% for an identical army, slowing subsequent Soul and Territory growth.
Existing resources are not reduced. Lower tiers still accumulate faster than
higher tiers by design; this remains an uncapped incremental production chain.

| Tier | Old Soul cost | New Soul cost | Old previous-tier cost | New previous-tier cost |
| --- | ---: | ---: | ---: | ---: |
| Skeleton | 10 | 10 | 0 | 0 |
| Necromancer | 810 | 600 | 100 | 72 |
| Lich | 25,000 | 20,000 | 20 | 20 |
| Archlich | 1,500,000 | 1,000,000 | 72 | 60 |
| Deathlord | 150,000,000 | 100,000,000 | 72 | 60 |
| Dreadlord | 1e12 | 5e11 | 48 | 36 |
| Grave King | 1e17 | 5e16 | 48 | 36 |
| Eternal Sovereign | 1e22 | 5e21 | 60 | 48 |
| Void Regent | 2e27 | 1e27 | 60 | 48 |
| Endbringer | 1e33 | 5e32 | 60 | 60 |

Soul costs of related Empowerment and Multiplicity upgrades follow their tier's
recipe as before. Seed prices, cultivation, blessings, campaign rewards, and
the five-minute buyer cycle are unchanged. Unmodified base producer repayment
times still rise monotonically, ending at fourteen days for one Endbringer.

## Supplied-save checks

- With unchanged buyer selections, Dreadlords remain at 2 over a 48-hour
  no-intervention test in both builds: nothing above produces them.
- Enabling Dreadlord Recruit and Multiply is ineffective in 2.4.8 because the
  gates reject them. In 2.4.9, one five-minute cycle makes the first Grave King
  purchase affordable from the resources already earned in this save.
- With buyers paused for an eight-hour comparison, new Skeleton gains drop
  from 2.175Qa to 0.870Qa. Soul gains drop from 36.37Qi to 27.49Qi and Territory
  gains from 25.74Qa to 19.46Qa. Existing Skeletons continue contributing, so
  Soul and Territory gains do not immediately fall by 60%.
- The original portable code was restored through the actual browser UI at
  390px and 1440px. Tests enabled the two Dreadlord controls, advanced one cycle,
  bought a Grave King, and reloaded successfully. The new Grave King buyers
  remained Off until selected.

## Earned-resource pacing samples

| Policy | 2.4.8 first Endbringer | 2.4.9 first Endbringer |
| --- | ---: | ---: |
| Five-minute visits, earned warps | 6h 45m | 6h 15m |
| Hourly visits, no warps | 541h | 468h |
| Eight-hour visits, no warps | 664h | 592h |
| Daily visits, no warps | 984h | 864h |
| Eight-hour visits, selected buyers, no warps | 488h | 448h |

These are reproducible strategy samples, not promises for every player's
choices. The no-warp game retains weeks of progression. Actual fresh browser
playthroughs confirmed the five-minute and eight-hour manual policies, including
all campaign types, earned ascension, Grave Bloom, reload, and the next run.

Reproduce with `node qa/pacing-249.cjs` from the game directory. Browser checks
use `NECRO_CHROMIUM` pointing to a Chromium executable. No user save code is
included in this distribution.
