# Necropolis: Rise of the Undying

Necropolis is a free, text-based idle/incremental game about building an undead empire.

## How to play

Start in **Undead** by raising Skeletons to gather Souls. Use Souls to recruit Necromancers, then unlock stronger undead tiers. Each tier produces the tier beneath it, so your army continues growing on its own—even while you are away.

Use the navigation tabs to manage each part of the empire:

- **Undead** — buy units, inspect production, and unlock higher tiers.
- **Empire** — expand Territory and purchase production upgrades.
- **Energy** — collect Dark Energy and spend it on Time Warps.
- **Ritual** — sacrifice resources for temporary run bonuses.
- **Milestones** — track achievements and long-term goals.
- **Automation** — optionally enable automatic buyers for units and upgrades.
- **Options** — change display settings, export or restore a save backup, read **What's new**, and view the quiet **Credits** section.

## Reading the numbers

Production rates use **/hr** by default. You can switch the display to `/min` or `/s` in Options. Large values stay compact with suffixes such as **K**, **M**, **B**, **T**, and **Qa**; costs and other important values are rounded to a readable whole number unless a decimal is needed for accuracy.

## Growing faster

Keep production upgrades running, expand Territory when it becomes available, and use Dark Energy for well-timed Time Warps. When you are ready, **ascend**: ascending resets the current run but awards permanent blessings that make future runs stronger and faster. Ascension is crucial to keep your long-term growth accelerating.

## Saving and support

Your progress saves automatically in your browser. For safety, open **Options** and download a save backup before clearing browser data or changing devices.

Support and bug reports: [gravelrockstudios@gmail.com](mailto:gravelrockstudios@gmail.com)

**Special thanks: Evan Rosson**  

