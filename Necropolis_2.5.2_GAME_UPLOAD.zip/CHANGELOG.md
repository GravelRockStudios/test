# 2.5.2 — A guided beginning, room to breathe

- Replace the four-page introduction with seven goals that advance automatically when completed: raise a Skeleton, visit Milestones, raise a Necromancer, unlock and visit Dark Energy, visit Empire, visit Automation, and create a backup.
- Reveal menus gradually during the first-run intro. Skipping restores normal navigation immediately. Returning players and manual replay use normal gameplay unlocks.
- Isolate Replay, Next, Back and Close controls to the tutorial panel and navigation; they do not rebuild the gameplay screen or write gameplay saves. Replay remains manual so an advanced empire does not instantly skip the explanation.
- Preserve open/closed disclosure panels and focused summaries while the same screen refreshes. Production bonuses no longer closes each second.
- Place undead tier links inside Overview, Recruitment and Upgrades, instead of the global sidebar. Move objectives and suggested next actions to Milestones only.
- Use an open layout for resources, guidance, tier links and production summaries, with cards retained for actionable groups. Match the brighter Recruit and View upgrades buttons.

The reported immediate reset on Edge/itch.io was not reproduced in the supplied v2.5.1 build. Populated-save replay checks now verify live exported and stored state through every step and reload. The hosted itch.io build has not been inspected; this release does not claim to recover already-lost progress.

# 2.5.1 — Your first undead empire

- Add a four-step first-run introduction with Back, Next, Skip and replay from Options. Tour progress resumes after reload and stays separate from gameplay saves.
- Restore the visible objective panel and add a persistent suggested next action linking to the relevant recruitment, Territory or Ritual screen. Explain the Dark Energy unlock at three Necromancers.
- Give the mobile save reminder a direct Back up progress button and detect iPads using desktop browsing mode. Keep the reminder visible before the main content.
- Let descriptions and objective readouts wrap. Give mobile navigation tabs enough width for complete labels instead of squeezing them into a fixed box.
- Gameplay balance, artwork and portable save format remain unchanged.

# 2.5.0 — A clearer command interface

- Returning to a main menu opens Overview. Direct links still open their intended section; purchases and production ticks keep the current submenu.
- Undead Tiers remain visible across all pages in an independently scrollable rail. The desktop sidebar and compact mobile command area are sticky.
- Split Undead into Overview, Recruitment and Upgrades, with clear production summaries, a next-tier card and automatic recruitment controls.
- Apply a consistent visual system for spacing, cards, buttons, active states, focus outlines and scrollbars. Add Skip to game content and respect reduced motion.
- Fix P1 C1: every campaign victory, including Forgotten Cemetery, shows completion feedback. New milestone awards appear alongside victories. Existing 1/3/5/10 milestones remain awarded once and stay earned after ascension.
- Group multiple Time Warp victories into one readable notification. Offline victories appear in the return summary and are not re-announced on reload.
- Preserve all artwork, production, prices, rewards, save format and existing progress.

Validation: responsive navigation and actual purchases/Undo; 40 core scenarios; all three campaigns at milestone and non-milestone victories; exact warp resources; offline summaries; single-owner save recovery; fresh desktop/mobile UI progression, ascension and reload.

# 2.4.9 — Recover saving and keep the highest tier growing

- Fix P0 L1: sessions now renew a 60-second claim every 10 seconds. Read-only tabs can recover expired owners. The banner has Take over this save; responsive owners save before handing off, and older orphaned locks can be replaced explicitly.
- Check the ownership token before gameplay, saving, and recovery writes. A resumed old session pauses and cannot reclaim ownership by renewing an expired claim.
- Unlock Recruit automation and Grave Multiplicity after the first unit of their own tier. Your highest tier can now grow automatically. New switches remain Off until selected.
- Reduce Necromancer Skeleton output by 60%, slowing future Skeleton, Soul and Territory growth. Keep all existing resources and paid upgrades.
- Smooth Soul and previous-tier recruitment costs to compensate for gentler growth and reduce upper-tier stalls. Seed costs and the five-minute buyer cycle are unchanged.
- Validate the supplied save in mobile/desktop browsers, fresh UI playthroughs, AFK equivalence, and live/frozen/orphaned/racing session recovery.

For the supplied save: enable Dreadlords Recruit and Multiply in Automation → Undead to grow beyond the two currently owned. Existing selections are preserved.

# 2.4.8 — Focused Empire and Territory pages

- Territory now has Armies and Conquest Targets submenu pages with matching original emblems.
- Replace the separate Territory income breakdown with each army's combined production at the bottom of its summary.
- Give Empire Research and Grave Offerings their own submenu pages alongside Dominion.
- Remove rewardless repeatable goals; real milestones and challenge rewards remain.
- Improve the Seed output of Soul-funded Cultivation, with larger gains at higher levels. Existing levels benefit immediately; prices are unchanged.
- Verify fresh active/AFK play, new navigation, automatic buyers, offline progress and save protection. See QA_2.4.8.md.

# 2.4.7 — Matching emblems, smoother pacing and focused Ritual pages

- Match page-header emblems to the existing navigation artwork, including Dark Energy.
- Split Ritual into Ascension and Permanent Blessings, with matching submenu artwork and remembered selection.
- Keep Challenge Rewards in Milestones. Tuck Ascension History into a collapsed Options section.
- Protect one next-tier Grave Seed purchase from automatic spending, in addition to the chosen percentage reserve (the larger reserve applies).
- Smooth Dreadlord-to-Endbringer Soul prices and related Empowerment/Multiplicity costs while keeping Seed prices, army requirements and passive production intact.
- Verify earned-resource active/AFK progression, multi-tab protection, offline continuity and desktop/mobile navigation. See QA_2.4.7.md and BALANCE_AUDIT_2.4.7.md.

# 2.4.6 — Safer browser saves

- Only one tab can play and save; extra tabs are read-only with a clear reload instruction.
- Closing stale tabs cannot write their older state over the active save.
- Closing the active game refreshes a recovery checkpoint; reloading another tab restores the latest saved state.
- Detect externally rolled-back saves before actions, including older revisions from the same writer.
- Keep saving local, with existing downloadable backups and save codes. Close all older-version tabs before loading this update. See QA_2.4.6.md.

# 2.4.5 — Clearer custom purchases

- Custom batch labels explicitly count purchases and show the current units raised per purchase.
- Kept existing number, suffix and percentage behavior; clarified validation wording.
- Milestones explain that each award is earned once and retained after ascension.
- Verified all three campaign milestone paths, including Forgotten Cemetery, and retained consistent Multiply labels. See QA_2.4.5.md for the report findings and limits.

# 2.4.4 — Clearer automatic buying

- Separated Automatic upgrades labels and switches with a dedicated, spaced control row.
- Added brief Recruit, Empower and Multiply explanations to Undead and Conquest automation.
- Resource buyers now name the upgrade location and effect, including Chronomancy in Dark Energy.
- Clarified the five-minute buying cycle and shared reserve.

# 2.4.3 — Automation emblems

- Added matching artwork to Overview, Undead, Conquest and Resources in the Automation submenu and page headings.
- Reused the existing gear, undead banner, crossed swords and Grave Seed emblems.
- Kept labels visible and compact layouts on desktop and mobile.

# 2.4.2 — Automation submenu

- Split Automation into Overview, Undead, Conquest and Resources in the navigation bar.
- Group recruitment and upgrades in one compact row per unit; show relevant tiers as they become available.
- Put shared settings on Overview and detailed instructions in an optional help section.
- Remember the selected Automation page and keep the master buyer control on every page.
- Show the submenu beneath the mobile navigation; hide unrelated Undead tiers while using Automation.
- Preserve buyer selections, saved progress, balance and all artwork. See QA_2.4.2.md.

# 2.4.1 — Full play QA fixes

- Fixed V7 save codes being accepted by validation but rejected during restore.
- Backup and save-code restores now apply elapsed offline buying with the saved master, reserve and offline settings.
- Welcome-back reports count Grave Seeds produced and Territory captured before buyers and campaign commitments spend them.
- Completed fresh desktop and mobile progression to Endbringers using only earned resources, followed by ascension, a paid Grave Bloom upgrade, and reload.
- Verified seven-day live/offline/reload equivalence at every reserve, and 30-day offline production with buying disabled.
- Preserved all 2.4.0 balance curves, artwork, license and save schema. Detailed coverage: QA_2.4.1.md.

# 2.4.0 — Grave Bloom and automatic progression

- Added permanent Grave Bloom for Grave Seed production: +50% at the first Shard upgrade, with diminishing gains thereafter.
- Added all undead Empowerment/Multiplicity buyers, all eligible Seed/Energy and Conquest upgrade buyers, and final-tier/Conquest unit buyers.
- All selected buyers share one reserve; one-batch savings prevent cheaper buyers starving expensive recruits.
- Conquest can repeat its target or rotate campaigns automatically, including offline and Time Warp. Pausing stops continuation.
- Specialist troops command support from the growing Skeleton host. Conquest Empowerment is visible and preserves troops.
- Fixed tiny campaign-boundary precision and retained the state of Automation's collapsible sections.
- Added NECRO-SAVE-8 with exact new-feature preservation and older-format imports. Preserved all artwork and prior ascension curves.
- Astra reviewed the mechanics and saving; core, browser and save regressions passed. See QA_2.4.0.md.

# Necropolis v2.3.1 — 2026-10-04

- Fixed hidden buyer selections surviving a locked state and automatically spending on a later unlock. New buyers start Off, including active/offline unlocks and unlocks after ascension or Undo.
- Preserve explicit On choices for buyers already unlocked, the master toggle, reserve and offline preference. Ascension still pauses the master.
- Added an explicit zero guard for whole-number quantities. Zero Territory was already visible in browser reproduction; no Territory formula changed.
- Grave Empowerment descriptions name the produced resource, including Liches from Archliches.
- Fixed light-mode conquest tier cards retaining dark backgrounds behind dark text; they now use the same readable palette as the Undead rail.
- Verified Undead navigation and count-independent Deathlord per-unit output at phone/desktop widths; neither reported defect reproduced.
- Verified conquest milestone notification timing, retained + earned ascension shards, and actual Time Warp gains against the displayed preview. Added report-specific regression suites.
- Balance, flat recipes, unlimited offline production, save format, artwork and license unchanged. See QA_2.3.1.md for the finding-by-finding response and test scope.

# Necropolis v2.3.0 — 2026-10-01

- Fixed live campaign progress being changed by affordability previews. Previews now simulate an isolated save.
- Added old-build-fails/new-build-passes coverage for premature victories and browser checks for purchases, page changes and Undo.
- Rebalanced later Soul costs, Cultivation growth and conquest Seed costs using comparative progression simulations.
- Ruined Academy victories now strengthen Crypts as well as unlocking Grave Studies and improving Insight.
- Upgrade and development previews show actual output. Campaign rewards show current → next benefits in separate lines.
- Preserved 2.2.5's Seed economy display and fixed its negative net-spending sign.
- Existing units, paid upgrades, saves, artwork and license are preserved. See BALANCE_AUDIT_2.3.0.md for formulas, measured outcomes and limitations.

# v2.2.5

- Grave Seed header now reports estimated net production while buyers are active.
- Seed detail separates gross production from projected automatic-buyer spending.
- Kept the existing buyer reserve/priority safeguards, flat unit recipe pricing, Deathlord wall, and mobile backup guidance after QA review.

# Necropolis v2.2.4 - 2026-10-01

- Standardized Empire Research and Territory Development across Empire, Ritual, milestones, challenge rewards and notifications.
- Replaced vague challenge-reward references with exact starting research levels and development plots.
- Renamed Soul Harvesting to Grave Seed Cultivation, Expand Domain to Grave Seed Expansion, and Energy Storage to Dark Energy Storage; matching milestones and tips use the same names.
- Bonuses and costs name their affected resource, including Grave Seeds, Dark Energy and Time Warp.
- Corrected the displayed next-plot unlock threshold for multiple Claimed Ground ranks.
- Game formulas, save identifiers, historical changelogs, artwork and license remain unchanged.

# Necropolis v2.2.3 - 2026-10-01

- Removed Empire Blueprints, the saved-setup controls, its permanent upgrade chain and its milestones.
- Existing saves refund all Blueprint rank purchases in Lich Shards once; saved plans and Blueprint building discounts are retired.
- Existing buildings, army, campaign contributions, other permanent upgrades and earned achievement records remain intact. Older save formats still import.
- Artwork and license unchanged.

# Necropolis v2.2.2 - 2026-09-30

- Conquest completion estimates now follow actual auto-buyer cycles, including current timer phase, spending reserves and consumed units.
- Playing and Offline estimates appear separately when their buyer settings differ. Pausing buyers, purchases, allocations, Undo and Time Warp refresh the estimate.
- Distant automated targets show a proven lower bound when no completion is found within the forecast window. This does not cap gameplay or offline production.
- Target prices, progress, rewards, artwork, license and compact save format are retained.

# Necropolis v2.2.1 - 2026-09-30

- Fixed conquest countdowns to include the growing undead army. The estimate and actual completion now share the same integrated Territory calculation. Target costs and rewards are unchanged.
- Simplified Empire Blueprints instructions and buttons. Saved details are expandable, and the current resource cost appears separately.
- Added NECRO-SAVE-7 binary packing. The reported 936-character save becomes 685 characters with exact state preservation. Older codes still import; full SHA-256 protection remains.
- Preserved all artwork, saved progress, campaign investment and the All rights reserved license.

# Necropolis v2.2.0 - 2026-09-30

- Permanent cards refresh into newly named, higher-cost upgrades. Costs double per purchase; purchased benefits survive ascension.
- Claimed Ground adds plots per rank. Archive upgrades add starting teaching levels. Blueprint upgrades progressively reduce development prices for both manual construction and paid rebuilding.
- Dark Energy shows whole compact numbers, including suffix carryover. A live Time Warp charge bar shows remaining energy and time at the current regeneration rate.
- Conquest targets are repeatable. First goals are ten times larger; each victory raises that campaign's Territory target tenfold. Logarithmic rewards improve Gravefields, excavation, Obelisks and future warps with diminishing gains.
- Existing campaign victories retain their rewards; incomplete contributions retain their invested Territory. Completed stages stop diverting income until the player chooses another.
- Milestones cover campaigns, development, teachings, permanent paths, blueprints, offerings and higher-tier Empowerment. Added an Empire category and removed four duplicate visible thresholds without deleting saved achievement records.
- Save schema 22 preserves upgrade ranks and campaign stages. New NECRO-SAVE-6 codes compact progression data, milestone bits, timestamps and full history. Previous codes still import; frozen older dictionaries and full SHA-256 integrity checks remain unchanged.
- Reviewed progression against the original Math of Idle Games articles. Eight measured strategies reach the final tier; prestige modeling covers up to 120 ascensions. Exact assumptions and results are in BALANCE_REVIEW_2.2.0.md.
- Hourly defaults, artwork, credits, recruitment recipes and equal-time active/offline production are retained.
- Added LICENSE.txt with the selected All rights reserved terms for code and assets, free personal-play permission, and a quiet notice inside Options > Credits.

# Necropolis v2.1.0 - 2026-09-30

- Necromancers and Liches now produce 40% faster. Later base rates, recruitment recipes and the ten-tier chain are preserved.
- Endless Horde adds one unit to purchased batches, with faster Seeds/conquest and weaker natural production. Lich Dominion favors producers/energy; Soul Cult retains its harvesting and Grave Offering strengths.
- Added Forgotten Cemetery, Ruined Academy and Black Spire conquest targets. Commit 25%, 50% or 75% of incoming Territory to one target; switching and pausing preserve progress. Completed targets restore full income. Campaigns and rewards reset on ascension.
- Insight now supports Bonebinding, Warcraft, Night Studies and unlockable Grave Studies. Only the selected teaching receives the level bonus; switching after study costs Insight.
- Added one-time shard unlocks: Claimed Ground, Eternal Archive and Empire Blueprints. Blueprints save settings and desired buildings, then rebuild affordable buildings at their normal prices.
- Optional ascension challenges award one starting teaching level or immediate access to the first three development plots. Rewards do not stack through repeated completions.
- Consolidated future production research into tier Empowerment. Existing Bonebinding/Ancient Rites/Grave Command research ranks keep their bonuses until ascension.
- Vessel of Night starts at about +9.09% storage while retaining its ceiling below double capacity.
- Campaign completion is integrated consistently during active play, offline progress and Time Warps. Warp forecasts show campaign progress/completion and spendable gains.
- Save schema 21 protects the new fields. All prior supported save codes and JSON backups still import. Compact v5 dictionaries and full SHA-256 checks remain unchanged.
- Existing artwork, credits, default /hr displays and Grave Offering curves are preserved.

# Necropolis v2.0.5 - 2026-09-30

- Corrected singular tier shortages in locked navigation, Grave Seed buyer wording, and consistent capitalization of tier names in recipes and purchase messages.
- Replaced the skull within the Undead banner with a fortified banner emblem to distinguish it from Skeletons.
- Added explicit browser coverage for one-shard ascension accounting, retained buyer selections, deliberate post-ascension pause and manual restart.
- Retained the verified warp, capacity, milestone and shard fixes; no balance changes.

# Necropolis v2.0.4 - 2026-09-30

- Replaced Sacrificial Rites with Grave Offerings: bury Skeletons to increase Grave Seed production.
- Kept the existing logarithmic bonus curve, 10%/25%/50% choices, Soul Cult doubling, unlock requirement and Undo behavior.
- Removed the offering bonus from Soul harvesting, Necromancer production and Lich production. Existing buried totals carry over through saves; ascension still clears them.

# Necropolis v2.0.3 - 2026-09-29

- All Undead tiers now share a consistent summary: Owned, Each produces, Total production, recruitment source and Total bonuses.
- Replaced the long bonus paragraph with aligned source/value rows and a combined multiplier. Skeleton assignments have their own compact section.
- Removed repeated production advice and the verbose consumption/refill panel from the tier summary. Purchases, rates and bonuses are unchanged.
- Responsive summary layout supports desktop and mobile; existing artwork and compact save format are preserved.

# Necropolis v2.0.2 - 2026-09-29

- Removed the redundant Eternal Legion bonus/cost line highlighted in feedback; the tier breakdown remains visible.
- Introduced NECRO-SAVE-5: omit default fields, compact frozen field names, pack milestone flags, then gzip. Preserve exact quantities, Empire settings, automation, blessings, migration data and ascension history.
- Retained the complete SHA-256 checksum using 43 Base64URL characters instead of 64 hexadecimal characters. This is lossless encoding, not a shortened hash.
- Kept imports for save versions 1–4 and JSON backups. Generated codes now show their character count.
- Validation: 39 core tests, 23 browser scenarios, template checks and save-format round trips. Representative saves were 88% (fresh) and 33% (advanced with 60 history entries) shorter than v4. Actual savings depend on progress.

# Necropolis v2.0.1 - 2026-09-29

- Corrected indivisible shard accounting, including old saves with tiny decimal residue. Repeated purchases no longer make a remaining shard disappear from the displayed balance.
- Locked buyers now show Locked without active styling. Ascension and Automation explain how to resume saved buyer selections.
- Corrected singular purchase and recruitment wording; matched production bonus labels to their upgrade cards and added the combined multiplier.
- Added a distinct Undead army banner, preserving all existing PNG artwork.
- Corrected Vessel of Night's first-level description to approximately 0.99%; minute durations retain useful fractional precision.
- Expanded controlled Time Warp and shard accounting regression tests. Reported warp discrepancy remains unreproduced; no speculative production or offline balance changes.

# Necropolis v2.0.0 - 2026-09-29

## 2.0 readiness fixes and verification

- Promoted the in-game build and release package to v2.0.0 so the shipped version is unambiguous.
- Kept the Necromancer buyer's visible 25 Grave Seed cost and live five-minute income warning in the Automation tab; added regression coverage so seed drain cannot become silent again.
- Dark Energy capacity now keeps compact suffixes while showing useful precision in the header (for example, `30.297K` instead of `30K`). The full exact capacity remains available in the tooltip and Energy details.
- Corrected singular unit wording for Lich and Archlich so the game uses “a Lich” and “an Archlich.”
- Locked buyers remain visibly disabled and cannot appear functional before their producer tier is raised.
- Added QA coverage for Warp Lore duration and preview consistency, offline buying and reserves, Excavation → Insight → Teachings, all doctrine directions, and meaningful diminishing sacrifice bonuses.

## Feature coverage carried into 2.0

- Automation, optional offline buying, shared reserves, and five-minute buyer cycles.
- Ritual blessings, Time Warp duration scaling, Dark Conduits, Energy Storage, and Vessel of Night.
- Territory conquest, doctrines, Gravefields, Empire research, Excavation, Insight, and Teachings.
- Exact batch costs, Buy Max, compact number formatting, purchase Undo, milestone history, and portable save backups.

# Necropolis v1.5.9 - 2026-09-29

## Credits

- Added an in-game Credits section and a `CREDITS.txt` file in the downloadable package.
- Attribution: Developed by Apoped. Contact: gravelrockstudios@gmail.com. Special thanks to Evan Rosson.
- Added a clearer player-facing description covering the tab layout, compact number format, hourly defaults, saving, automation, and why ascension matters.

## Previous v1.5.8 changes

# Necropolis v1.5.8 - 2026-09-29

## Vessel and changelog history

- Vessel of Night now starts at a visible ~0.99% capacity increase at level 1. The curve is gentler later so the early upgrade is meaningful without making high levels explode.
- Options now keeps the release history in newest-first order. Future entries should be added at the top.
- Removed the remaining base wording from tier upgrade previews.

## Ascension copy

- Shortened the Ascend confirmation so it is easier to scan. It now clearly explains that ascending is essential for stronger bonuses and faster future growth.

## Previous v1.5.6 changes

## Symbol and rate cleanup

- Removed the stray "base" label from rate previews. Rates remain hourly by default and display as `/hr`.
- Swapped Skeleton and Necromancer symbols everywhere they appear.
- Rotated the Lich, Archlich and Deathlord symbols as requested: Deathlord art now marks Liches, Lich art marks Archliches, and Archlich art marks Deathlords.

## Previous v1.5.5 changes

## Layout, rates and Energy

- Every load starts with hourly production rates across resources, units, Empire and upgrade previews. Options can switch the current session to minutes or seconds. Small rate values omit trailing zeros.
- Changelog moved to the bottom of Options. Save/restore cards align beneath a full-width backup note. Options heading now uses the matching gear artwork.
- Removed buyer-spending qualifiers from wait estimates, production-loss paragraphs, consumed labels and the extra production disclaimer. Buyer note shortened; bonus list begins "Total bonuses".
- Dark Conduits now add 180 Energy/hour per level (0.05/sec). Level 18 reaches 3.6K/hour; level 38 reaches 7.2K/hour before bonuses. Equal-time active and offline regeneration remain identical. Existing upgrade levels immediately use the new curve.

## Previous v1.5.4 changes

## Fixes-to-ship update

- Removed the hidden 500 Dark Energy reward from Soul Harvesting and Domain Expansion purchases.
- Warp preview and execution share one projection; completion reports Territory and Souls gained. Preview explains growth during the warp and keeps resource labels explicit.
- Incoming recruitment is separate from each unit's output. Active-buyer ETAs state that they assume no spending.
- Buyer cards display Seed costs, full recipes and batch output. Shared spending preview warns when a cycle would exceed five minutes of Seed income.
- Milestone notifications are deduplicated by ID across undo and repeat purchases.
- Exact Energy capacity is available in the header tooltip and Energy page; Vessel previews its incremental capacity gain.
- Shared singular names and visible mid-game Eternal Legion bonuses clarify purchases.
- Report-by-report findings and B1/B2 balance decisions are recorded in FIXES_TO_SHIP_REVIEW.md. Offline, blessing and warp formulas are retained.

## Previous v1.5.3 changes

## Number display update

- Resource balances, costs, recipes and forecasts share compact K, M, B, T, Qa, Qi and higher suffixes. After Vg, letter suffixes continue aa, ab and onward. Scientific notation remains an optional setting.
- Purchase shortages round upward to whole resources: 6.766 missing Archliches displays as 7; a positive fractional shortage never displays as zero.
- Compact costs retain meaningful decimals such as 1.5K. Values that round across a suffix boundary display 1M instead of 1000K.
- The economy and saved fractional production are unchanged.

## Fixed

- Ascend, Reset and backup recovery now use accessible in-game confirmation dialogs. They work when the game is embedded without permission for native browser popups.
- Save writes carry a unique live-session writer ID and revision. Harmless formatting changes and the same writer's older echoes do not pause autosave. A genuinely different session's changed progress is still protected against stale overwrites.
- Upgrade prices are normalized before checking affordability and spending. Grave Command's 2,073,600,000,000.001 residue becomes 2,073,600,000,000. Legitimate fractional Territory prices remain, rounded to three decimals at their source.
- Unit, upgrade, development and teaching affordability use a shared small tolerance. Buy 1, Buy Max, deficits and ETA use compatible checks.
- Pausing the automation master switch also pauses offline buying, even if the offline preference remains enabled.
- Undo no longer creates a return-from-offline report or restores outdated buyer preferences. Automatic purchases clear the manual Undo snapshot. Failed actions cannot revive a snapshot invalidated by an automatic purchase.
- Automation unlock descriptions no longer use incorrect indefinite articles.

## Added and clarified

- One-batch ingredient progress with an explicit lower-tier consumption and production-loss warning.
- Sacrifice buttons preview the resulting bonus before spending Skeletons.
- Compact Time Warp gain display, using the same simulation as execution.
- Version number in the footer and a visible changelog under Options.
- The Automation emblem is used in both the tab and its page heading.
- Reset, Ascend and restore confirmations support Cancel and Escape; ordinary shortcuts are disabled while they are open.

## Kept

- All 22 PNG assets, including the new Automation emblem.
- Flat unit prices, all ten tiers, consumed-unit recipes, parallel Territory/Insight progression, logarithmic sacrifice, and diminishing production upgrades.
- Custom batch input, typing-safe keyboard shortcuts and milestone toasts from the preceding update.
- Unlimited offline production at the same rate as equal-time active play with matching buyer settings. No offline nerf or new random purchase multiplier.
- Save schema 20 and compatibility with existing portable saves.

This file can be used as the itch.io release note. The ZIP update itself does not publish a devlog or deploy the game.
