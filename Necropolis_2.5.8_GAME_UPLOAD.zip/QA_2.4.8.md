# Necropolis 2.4.8 QA and balance notes

## UI changes

- Territory has Armies and Conquest Targets submenu pages, sharing the established navigation style. Each submenu emblem matches its page header.
- Removed the separate Territory income breakdown. Each selected army now ends its production summary with “In total they produce X/hr Territory,” using that tier's combined troop and Skeleton-command production.
- Empire has Dominion, Empire Research and Grave Offerings pages. Research and offerings retain their existing costs, effects and Undo behavior.
- The new page choices are display preferences. Navigating never spends game resources. The Automation “Manage targets” shortcut opens Conquest Targets directly.
- Removed rewardless repeatable goal displays and their unused generator. They were derived from existing totals, not separately stored, so this does not materially shorten save codes. Actual milestones, challenge rewards and history remain.

## Seed balance

Grave Seed Cultivation remains purchased with Souls at the same prices. Its base output changes from `1 + L + 0.05 L²` to `1 + L + 0.10 L²` per second, before existing multipliers. Current paid levels immediately benefit. No new claim counters or save fields are required.

| Cultivation level | Previous base Seeds/sec | New base Seeds/sec | Increase |
|---|---:|---:|---:|
| 0 | 1 | 1 | 0% |
| 10 | 16 | 21 | 31.25% |
| 20 | 41 | 61 | 48.78% |
| 30 | 76 | 121 | 59.21% |
| 50 | 176 | 301 | 71.02% |

This gives stronger returns on Soul investment rather than paying a percentage of the much larger Soul balance in Seeds. Soul production itself is unchanged. Unit costs, upgrade costs, previous-tier army requirements and permanent blessing curves retain the 2.4.7 balance. The next-tier Seed protection introduced in 2.4.7 remains active.

Five earned-resource policies were compared against 2.4.7. The eight-hour, no-warp, offline-buyer sample reached Endbringers in 488 hours rather than 528 hours (20d 8h vs 22d). Its final-tier Seed-blocked observations fell from 152h to 120h. These observations overlap with other resource constraints and cannot be added together. The four manual-buying samples had unchanged completion times because other resources already constrained them. These are strategy samples, not universal player timings.

A fresh real-UI desktop playthrough reached all ten tiers at 6h 45m with earned warps; the phone/eight-hour-offline/no-warp playthrough reached them at 27d 16h. Both completed campaigns, ascended with earned resources, purchased Grave Bloom, reloaded and continued producing. No player save was supplied for the reported 1B Souls/hr and 250K Seeds/hr state, so an exact impact on that particular build cannot be claimed.

## Verification

- `navigation-248.cjs`: 320, 390, 900 and 1440px, dark/light themes; all main/unit/submenu artwork matches and loads; no horizontal overflow; new pages are separated, remember selections and support keyboard/touch. Research purchases, offerings and Undo, campaign rotation/pause, direct navigation from Automation, blessing purchases, ascension and collapsed history all passed. An additional 390px run with 18 troops of every Conquest tier checked nonzero combined production totals against the engine.
- `full-play-248.cjs`: both fresh browser playthroughs described above passed through the new navigation, with no page errors. Results: `qa/full-play-2.4.8.json`.
- `verify.cjs`: 40 core scenarios, including pricing, exact production, offline integration, migration and ascension.
- `progression-audit.cjs`: cultivation curve, Conquest costs/rewards and post-purchase campaign completion boundaries.
- `seed-reserve-247.cjs`: next-tier Seed protection across all nine upper-tier gates and four reserve settings; manual access and serialization.
- `afk-stress-240.cjs`: seven-day online/offline/reload equivalence at all reserve levels, thirty-day offline with buying disabled, buyer timing and ascension retention.
- `automation-browser-242.cjs`: all 50 switches, responsive navigation, actual buyer cycle, V8 save-code restore and post-ascension locks.
- `save-tabs-246.cjs`: simultaneous launch, stale-tab write prevention, owner handoff, recovery checkpoint, rollback detection and unavailable-coordination handling.
- `rendering.cjs`: template and script syntax checks.

Browser screenshots are only local QA material, not new release assets. Original artwork and license are retained. Saving remains local; existing save schema and portable formats are unchanged.
