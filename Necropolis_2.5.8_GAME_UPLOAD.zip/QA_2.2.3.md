# Necropolis 2.2.3 — Blueprints removal

Empire Blueprints is no longer a purchasable permanent upgrade or an Empire panel. Save/apply controls, building discounts, and Blueprint-specific milestones are removed. Historical changelog entries and frozen save-format dictionaries remain intentionally intact.

Old saves validate their retired fields, refund 6 × (2^rank − 1) Lich Shards, and discard Blueprint ranks and saved plans. Loading the migrated save again does not refund again. Buildings, other permanent upgrades, army and campaign progress are unchanged. Earned historical achievement IDs remain preserved without appearing as active milestones.

Regression coverage checks first and higher-rank refunds (including the supported rank limit), unchanged building counts, normal building costs, rejection of new Blueprint purchases, reload idempotence, and desktop/mobile absence of Blueprint controls.

Passed: 40 core scenarios, 14 progression scenarios, 12 enduring progression scenarios, 6 conquest-timing scenarios, rendering/script checks, 100 portable-save precision fixtures and retired-data imports through formats 4/6/7. Focused browser checks passed at 390px and 1440px, covering refunds, remaining permanent upgrades, removed controls, layout, portable restore and reload without a second refund.

The broad historical browser suite was also attempted but did not complete reliably: live-rendered elements detached during an existing scroll/screenshot check. Its completed assertions passed; the dedicated removal checks above are the verified browser results for this release.
