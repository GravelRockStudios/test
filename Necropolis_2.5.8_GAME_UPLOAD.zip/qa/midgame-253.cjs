const assert=require('assert/strict'),fs=require('fs'),path=require('path'),http=require('http'),{chromium}=require('playwright'),C=require('./extract-core.cjs');
const root=path.resolve(__dirname,'..'),key='necropolis-v3-save',errors=[];
const server=http.createServer((req,res)=>{try{const f=path.join(root,new URL(req.url,'http://localhost').pathname);res.setHeader('Content-Type',f.endsWith('.png')?'image/png':f.endsWith('.svg')?'image/svg+xml':'text/html');res.end(fs.readFileSync(f));}catch{res.statusCode=404;res.end();}});
function midgame(){const s=C.fresh();for(const [id,n] of Object.entries({souls:5e6,graveSeeds:100,territory:10000,totalTerritory:10000,skeletons:1000,total_skeletons:1000,necromancers:100,total_necromancers:100,liches:2,total_liches:2}))s.n[id]=C.N.of(n);s.energy=300;return s;}
(async()=>{await new Promise(r=>server.listen(0,'127.0.0.1',r));const browser=await chromium.launch({executablePath:process.env.NECRO_CHROMIUM,args:['--no-sandbox','--disable-dev-shm-usage']});
async function page(state,width=390,theme='dark',elapsed=0){
 const ctx=await browser.newContext({viewport:{width,height:900}});await ctx.addInitScript(({raw,key,theme,elapsed})=>{localStorage.setItem(key,raw);localStorage.setItem('necropolis-v3-preferences',JSON.stringify({theme,large:true,firstSteps:'done'}));let now=JSON.parse(raw).last+elapsed*1000;Date.now=()=>now;window.setInterval=(fn,ms)=>{if(ms===1000)window.__advance=seconds=>{now+=seconds*1000;fn();};return 0;};},{raw:C.serialize(state),key,theme,elapsed});
 const p=await ctx.newPage();p.on('pageerror',e=>errors.push(e.message));await p.goto(`http://127.0.0.1:${server.address().port}/index.html`);return {p,ctx};
}
try{
 for(const width of [320,390,900,1440])for(const theme of ['dark','light']){
 const {p,ctx}=await page(midgame(),width,theme);
 await p.locator('#tabs [data-tab="empire"]').click();assert.equal(await p.locator('.doctrine-downside').count(),3);
 for(const paragraph of await p.locator('.doctrine-downside').all()){
  await paragraph.scrollIntoViewIfNeeded();const bounds=await paragraph.evaluate(el=>{const r=document.createRange();r.selectNodeContents(el);const card=el.closest('.doctrine-card').getBoundingClientRect(),box=el.getBoundingClientRect();return {text:el.textContent,fits:[...r.getClientRects()].every(x=>x.left>=card.left&&x.right<=card.right&&x.top>=box.top&&x.bottom<=box.bottom+1),onScreen:card.left>=0&&card.right<=innerWidth,unclipped:el.scrollHeight<=el.clientHeight+1};});assert(bounds.fits&&bounds.onScreen&&bounds.unclipped,JSON.stringify({width,theme,...bounds}));assert.match(bounds.text,/Tradeoff: −(15% natural undead production|20% Grave Seeds|10% Grave Seeds)\./);
 }
 if(width===390&&theme==='dark'){await p.locator('.doctrine-card').first().screenshot({path:'/workspace/necro-review/253-doctrine.png'});}
 await p.locator('#tabs [data-tab="undead"]').click();await p.locator('#unitList [data-unit="liches"]').click();assert.match(await p.locator('.lich-bridge').innerText(),/2 \/ 24 Liches/);await p.locator('[data-action="lichMultiplicity"]').click();
 await p.locator('[data-upgrade="twin_liches"][data-count="1"]').click();assert.match(await p.locator('#status').innerText(),/Grave Multiplicity purchased.*Spent 200K Souls, 125 Territory/);
 assert.match(await p.locator('.lich-bridge').innerText(),/each Lich purchase raises 2/);
 await p.locator('#unitList [data-unit="skeletons"]').click();await p.locator('[data-undead-page="recruitment"]').click();
 const buy=p.locator('[data-buy="skeletons"][data-count="1"]');await buy.click();const first=await p.locator('#status').innerText();assert.match(first,/Raised 1 Skeleton.*Spent 10 Souls, 1 Grave Seeds/);await p.evaluate(()=>document.querySelector('#status').hidden=true);await buy.click();assert(await p.locator('#status').isVisible(),'identical purchase refreshes feedback');assert.equal(await p.locator('#status').innerText(),first);
 const before=await p.evaluate(key=>localStorage.getItem(key),key);await buy.evaluate(el=>{el.dataset.count='1e99';el.click();});assert.match(await p.locator('#status').innerText(),/Not enough resources/);assert.equal(await p.evaluate(key=>localStorage.getItem(key),key),before,'failed purchase preserves save');
 await p.locator('#tabs [data-tab="milestones"]').click();await p.locator('.spending-history summary').click();assert.match(await p.locator('.spending-history').innerText(),/Grave Multiplicity purchased/);await p.evaluate(()=>window.__advance(1));assert(await p.locator('.spending-history').evaluate(el=>el.open));
 await p.locator('#tabs [data-tab="energy"]').click();assert.match(await p.locator('.energy-page').innerText(),/300 Dark Energy/);await p.locator('[data-warp="0.25"]').click();assert.match(await p.locator('#status').innerText(),/Time Warp: advanced/);
 await ctx.close();console.log(`PASS ${width}px ${theme}: complete doctrine tradeoffs, intermediate goal, batch upgrade, repeated and failed purchases, spending disclosure and affordable warp`);
 }
 for(const offline of [false,true]){
 const s=C.fresh();s.n.souls=C.N.of(100000);s.n.graveSeeds=C.N.of(10000);s.n.total_skeletons=C.N.of(1);s.autoEnabled=true;s.autoConfig.units=['skeletons'];s.autoConfig.offline=offline;if(offline)s.last-=300000;
 const {p,ctx}=await page(s,390,'dark',offline?300:0);if(!offline)await p.evaluate(()=>window.__advance(300));
 await p.locator('#tabs [data-tab="milestones"]').click();await p.locator('.spending-history summary').click();const text=await p.locator('.spending-history').innerText();assert.match(text,/Automatic buyers(?: while away)?: 5K Skeletons\. Spent 50K Souls, 5K Grave Seeds/);
 await ctx.close();
 }
 assert.deepEqual(errors,[]);console.log('PASS automatic 50K Soul deduction has a matching receipt');
}finally{await browser.close();server.close();}})().catch(e=>{console.error(e);server.close();process.exitCode=1;});
