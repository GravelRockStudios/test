# Necropolis 2.2.1 — conquest estimates, Blueprints and saves

The reported Cemetery estimate divided the remaining Territory by the current
income. It ignored Skeletons produced by the undead chain. On the supplied
save, it displayed about 43,283 hours; the integrated army reaches the target
in about 17.6965 hours at the existing settings. Ruined Academy takes about
7.8908 hours. Campaign prices, invested Territory and rewards are unchanged.

The countdown now shares its growing-army solver with actual campaign
completion. Boundary checks verify completion just after the predicted time,
noncompletion just before it, changing allocation and upgrades, paused progress,
an initially empty Skeleton army with Necromancers, and a zero-production army.
No elapsed-time cap or production penalty is introduced.

NECRO-SAVE-7 uses lossless binary records inside the existing gzip envelope:
presence bits, variable-length integers, exact IEEE-754 values, integer quantity
shortcuts, repeated-string references, buyer IDs, and compact milestone bytes.
It omits a total only when it exactly equals the owned count; the existing
loader restores that same total. The V6 dictionary and all older dictionaries
remain unchanged. Full SHA-256 integrity protection remains.

The supplied valid save is **936 → 685 characters** (26.8% shorter). Every
resource, upgrade, campaign stage, partial contribution, permanent unlock,
buyer choice, milestone, timestamp and history entry survives the round trip.
The player's save is used for local verification and is not included in this ZIP.
Four representative synthetic fixtures also get smaller than V6, including
60-run history. Savings vary with the amount and precision of saved progress.

Verification includes 40 core scenarios, 14 progression scenarios, 12 permanent
path/campaign scenarios, 100 generated precision fixtures, V3–V6 format checks,
malformed binary/truncation rejection and script/template checks. Browser checks
passed 32 existing scenarios plus two focused cases at 390px and 1440px,
including restoration of the supplied V6 code, the corrected
countdown, Blueprints, V7 exports and checksum rejection.

Blueprints now uses short instructions and Save setup / Apply setup buttons.
Its saved assignments, doctrine, teaching and buildings are under Saved setup.
The current resource cost is shown separately. Applying still charges normal
costs, respects free plots, supports partial rebuilding and retains existing
buildings.

All 23 original art files and the previously selected license are preserved.
The ZIP has index.html at its root and passes archive integrity checks.
