// Compatibility entry point for the current reproducible progression model.
require('./balance-model.cjs').main();
