# Necropolis 2.3.0 — verification

## Confirmed defect and regression

Affordability projections shared the live Empire campaign object. Advancing a preview could award a real campaign victory. `projectionAt()` now uses a fully isolated state copy.

- The projection isolation test fails against 2.2.4 HTML and passes against 2.3.0.
- The browser reproduction also fails against 2.2.4 with “rendering awarded a victory.”
- At 390px and 1440px, a 48-hour campaign retains zero progress when screens and previews are visited at a frozen clock. A real Buy Max updates its ETA immediately; Undo restores the original ETA.
- The newer 2.2.5 Seed display is included. Negative buyer drain is shown correctly and previewing it cannot mutate the save.

## Passed checks

| Check | Result |
|---|---|
| `node qa/verify.cjs` | 40 core scenarios |
| `node qa/progression.cjs` | 14 progression scenarios |
| `node qa/enduring.cjs` | 12 persistent progression scenarios |
| `node qa/conquest-timing.cjs` | 6 automation/countdown scenarios |
| `node qa/progression-audit.cjs` | Price, efficiency, reward and post-purchase completion boundaries |
| `node qa/preview-isolation.cjs` | 9 campaign isolation fixtures and signed Seed-display cases |
| `node qa/save-code.cjs` | 100 precision fixtures, exact V7 round trips and older-format decoding |
| `node qa/rendering.cjs` | Template and script syntax checks |
| `node qa/preview-browser.cjs` | Mobile/desktop reproduction, Buy Max, Undo, overflow and page-error checks |
| `node qa/conquest-browser.cjs` | Mobile/desktop live/offline forecasts, buyer settings, allocation, Undo and Time Warp |
| `node qa/wording-browser.cjs` | Mobile/desktop names, research/development actions and reward wording |

Browser tests used headless Chromium with Playwright. Screenshots of the campaign, development and Cultivation sections were inspected at mobile and desktop widths. No claim is made that the separate broad `qa/browser.cjs` suite was run to completion during this audit.

The all-purchases Energy invariant fixture now supplies 1e60 resources instead of 1e30, so its five-level late-tier purchases remain affordable after the intentional price change. The invariant itself is unchanged.

## Balance evidence

The package contains the baseline economy, before/after progression results, four-way research comparisons and two automatic-buyer profiles. See BALANCE_AUDIT_2.3.0.md for assumptions, formulas, rejected tuning and limitations. These simulations establish feasibility under declared strategies; they do not prove optimal play or player retention.

## Preservation

Compared with the supplied 2.2.5 package, all 23 artwork files and LICENSE.txt are byte-identical. Embedded image data is unchanged. Existing unit counts, purchased ranks, campaign contributions and save schema remain compatible. No automatic rollback of old campaign wins is attempted because legitimate wins cannot be distinguished from preview-induced wins in stored saves.

This is an upload package. It has not been published to itch.io automatically.
