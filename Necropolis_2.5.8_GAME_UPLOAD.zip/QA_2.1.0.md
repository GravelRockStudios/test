# 2.1.0 release validation — September 30, 2026

- 40 existing core scenarios passed.
- 14 progression scenarios passed, covering teaching specialization, doctrine tradeoffs, campaign allocation/conservation, boundary rewards, one-time unlocks, partial paid blueprint rebuilding, challenge rewards, ascension and malformed saves.
- 30 browser scenarios passed. New feature flows ran at 390px and 1440px, including shard unlocks, teaching selection, blueprints, campaign-aware warp forecasts, actual warp delivery, portable save restoration and ascension.
- Save checks passed for fresh, advanced and all-feature fixtures, 60-run history, compressed backups, older compact formats, schema-20 v5 imports, future-schema rejection and damaged data.
- Script/template checks passed; no source appears outside the HTML document. New desktop and mobile layouts were visually inspected.
- Fresh portable backups measured about 152 characters; an all-feature example measured about 408 characters. Length varies with state and timestamps. Full SHA-256 integrity checks remain.
- Art is unchanged from 2.0.5. No license changes or automatic itch.io publication.

These checks establish functional behavior and elapsed-time consistency. They do not replace extended player feedback on pacing or strategic balance.
