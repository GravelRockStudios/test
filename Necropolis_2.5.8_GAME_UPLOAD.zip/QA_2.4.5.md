# Necropolis 2.4.5 — October 10 report review

Reviewed the supplied `necropolis-fixes-to-ship(2).pdf` against 2.4.4. Applied the confirmed presentation fix and clarified permanent milestone behavior. Production, campaign completion, milestones, prices, save schema and existing artwork are unchanged.

## Findings

| Report item | Result and action |
| --- | --- |
| C1: Forgotten Cemetery award/toast absent | Not reproduced. First-time awards and named toasts passed for all three campaigns at normal and very high production, on phone and desktop. Cemetery also passed third-victory, Time Warp, offline recording and reload checks. Its milestone uses the same award path as the other campaigns. An award already earned in an earlier run remains earned after ascension, so replaying that target correctly produces no new milestone or count increase. The tester's exact save was not supplied; prior ownership is a possible explanation, not a confirmed diagnosis of that session. No speculative milestone logic change was made. |
| U1: Custom batch counts purchases without saying so | Fixed. The label now says “Custom batch · purchases,” the hint states that numeric entries count purchases, and it shows the current number and type of units each purchase raises. Percentage semantics and parsing remain unchanged. The button reads “Buy batch.” |
| U2: Grave Kings button reads Multiply | Intentional and consistent. All ten Undead automation rows use Recruit / Empower / Multiply, with the existing brief definitions naming Grave Empowerment and Grave Multiplicity. The Grave Kings Multiply switch remained Off in the regression. Changing only that row would introduce an inconsistency. |
| D1: Flat Deathlord recipe | Retained intentionally: 150M Souls, 10K Seeds and 72 Archliches per purchase. Multiplicity increases output per purchase. Existing core checks verify flat pricing and recipe consumption; no economic retuning was justified by the report. |
| P5: Seed economy and production upgrades | The report conflates blessings. Endless Hunger boosts Souls, not Seeds. Grave Bloom, Cultivation, Expansion and Empire bonuses including Grave Offerings strengthen Seeds. Grave Empowerment on Archliches increases their Lich production; Grave Empowerment on Liches increases their Necromancer production. These upgrades are present. |
| D3: Mobile save guidance | Preserved. Mobile sessions retain the prominent export-to-Notes guidance and Options save-code controls. |
| D2b: Eternal Sovereign to Void Regent wall | Preserved as part of the AFK progression. No price or growth changes were made. |
| High-production campaign pacing | The test covered fast first-stage victories and ordinary-rate completion. No campaign-target or countdown formula was changed. |
| itch.io relative update time | Outside the game package; no change. |

Milestones now explicitly say each award is earned once and retained after ascension. This clarifies the existing behavior without changing earned progress.

## Verification

- `qa/verify.cjs`: all 40 core scenarios passed.
- `qa/rendering.cjs`: template regressions and script syntax passed.
- `qa/report-browser-245.cjs`: 26 targeted browser scenarios passed, with no page errors.
- Campaign tests at 390 and 1440 pixels covered all three campaigns, normal and very high production, single awards, reload suppression, already-earned Cemetery milestones, the third Cemetery victory, Time Warp and offline progress.
- Custom-batch and label checks at 320, 390 and 1440 pixels passed in dark and light themes with no horizontal overflow. `=10000` bought exactly 10,000 purchases / 20,000 Grave Raiders with Multiplicity at one upgrade, costing 7.5M Souls and 10K Seeds. A three-unit Skeleton purchase multiplier also produced the expected units and costs.
- Phone and desktop batch screenshots were visually inspected; selected images are in `qa/screenshots-2.4.5/`.
- Production and milestone scripts, all 23 original external art assets, the embedded image and license are byte-identical to 2.4.4. Save schema remains 23 and save codes remain NECRO-SAVE-8.

Browser testing used headless Chromium. The original tester save, native iPhone Safari and live itch.io were not tested. C1 remains unconfirmed for that specific save; this update does not claim a reproduced Cemetery logic fix. This ZIP has not been published.
