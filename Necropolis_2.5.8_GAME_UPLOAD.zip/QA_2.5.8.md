# QA 2.5.8

Recruitment and upgrades now share a page for every undead tier. The old upgrade destination opens Recruitment and scrolls to its upgrade section. There is no separate upgrade item in the navigation. Intro gates still apply.

Checks completed in Chromium:

- `qa/navigation-252.cjs`: all ten tiers at 320, 390, 900 and 1440px, in dark and light themes. Confirms production rates, recruitment before upgrades, same-tier upgrade controls, costs, purchases, Undo, jump focus and affordability styling. Navigation leaves game progress unchanged.
- `qa/first-steps.cjs`: all seven goals, hidden systems, skip, replay, reload and backup guidance.
- `qa/release-257.cjs`: 240 pointer/keyboard purchases with forced refresh timing, text bounds, presets, Starting Legion, actual automated warp purchases and audio controls. The audio assertion waits for asynchronous resume to finish.
- `qa/audio-options-257.cjs`: default effects, finite sound voices, persisted mute preference and Options number contrast/size.
- All inline scripts parse. Core and milestone scripts match 2.5.7 after normalizing prose dash punctuation. No gameplay formula or browser-storage schema change. Portable exports now use the V9 format described below.
- Desktop and mobile screenshots reviewed for spacing and column layout.

The README now describes the game and links to the current download. Current game text and documentation use ordinary hyphens instead of long dashes. Repository license wording uses a general ownership section while retaining copyright limitations and third-party rights. Existing release downloads and history are retained.

The ZIP has index.html at its root and is checked against the current source and for archive integrity. Hosted itch.io and physical Edge were not tested.

## Energy layout and shorter offline codes

Time Warp is directly below the Energy stats. Chronomancy, Dark Conduits and storage follow it. The warp button comes before its production forecast. Copy is shorter throughout this screen and the save workflow.

Portable codes use a frozen dictionary for selected upgrade buyers and raw DEFLATE with a two-byte marker. Browsers without raw DEFLATE support fall back to gzip. All values, selection order, run history, milestones and the full SHA-256 checksum are retained. No server or network storage is involved. Older codes remain readable; older game builds cannot read the new V9 exports.

Measured V8 to V9 code lengths (including the full checksum):

| Fixture | Previous | Current |
| --- | ---: | ---: |
| Fresh | 119 | 97 |
| Early, buyers selected | 304 | 179 |
| Mid, buyers selected | 621 | 349 |
| Late with 60 runs | 1508 | 1177 |

Savings depend on the save, especially buyer selections. These are reproducible fixtures, not a guaranteed percentage for every player.

Additional checks:

- `qa/save9.cjs`: 36 exact V9 round trips with all buyer IDs in reverse order, campaign combinations and large quantities; invalid IDs, truncated streams and gzip fallback. Measurements in `qa/save-code-sizes-2.5.8.json`.
- `qa/save-code.cjs`: 100 precision fixtures, Unicode, fractional timestamps, all progress fields, 60-run history, old V3 through V6 imports, malformed binary rejection and compressed round trips.
- `qa/portable-240.cjs`: 36 unchanged V8 round trips and validation cases.
- `qa/energy-save-258.cjs`: layout order and actual warp/upgrade purchases at four widths in both themes. Actual V9 browser export and import preserves all state; checksum damage leaves the current save unchanged. Also imports V1, V2, V4, V6, V7 and V8 codes through the real UI.
- `qa/intro-progress.cjs`: populated saves survive replay and V9 backup generation, standalone and embedded.
- `qa/first-steps.cjs`: first-run completion still recognizes successful backup creation.

The release remains 2.5.8. Save format version 9 is independent of the game release number.

Offline verification: the 390px dark case disables browser networking before generating and importing codes. Direct `file://` browser testing is blocked by the execution environment's administrator policy (`ERR_BLOCKED_BY_ADMINISTRATOR`), so that launch path is unverified here. Localhost and embedded exports/imports pass.
