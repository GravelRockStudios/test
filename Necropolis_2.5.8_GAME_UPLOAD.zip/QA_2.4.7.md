# Necropolis 2.4.7 QA

## Changes

- Territory, Ritual and Milestones headers use their original navigation artwork; Dark Energy gains its matching emblem. All 23 existing external artwork files and the license are byte-identical to 2.4.6.
- Ritual has Ascension and Permanent Blessings submenus. Permanent shard purchases are on the latter. The selected section persists as a display preference, separately from game progress.
- Challenge Rewards appear only in Milestones. Ascension History is a collapsed section in Options, not a navigation tab. Recorded history is retained.
- Buyers protect Seeds for the next unraised, revealed undead tier. Late Soul and related upgrade prices are smoother; see BALANCE_AUDIT_2.4.7.md.

## Verification

- `verify.cjs`: all 40 core scenarios passed, including pricing, production, automation, ascension, offline integration, migration and currency accounting.
- `review-240.cjs`: all 15 existing review regression groups passed. Three Seed-buying fixtures now include the newly protected next-tier budget; their original purchase assertions remain.
- `seed-reserve-247.cjs`: all nine upper-tier gates and all four reserve percentages retain the protected Seed budget; manual purchases can use it, save round-trips preserve the state, and slow-income buyer starvation is reproduced and prevented.
- `afk-stress-240.cjs`: all four groups passed. Seven-day live, offline and interrupted/reloaded results agree at all reserve settings for early and late fixtures. Thirty-day offline with spending disabled, buyer timing and ascension retention also passed.
- `pacing-247.cjs`: five earned-resource policies compared against 2.4.6. Results are in `qa/balance-2.4.7.json` and the baseline file. These are strategy samples, not universal time guarantees.
- `full-play-241.cjs`: fresh desktop and phone browser saves progressed through all ten tiers, all campaigns, earned ascension and Grave Bloom, then reloaded and produced in the next run. Results are in `qa/full-play-2.4.7.json`. This full progression was completed before the final Ritual layout change; the final navigation test separately exercises the relocated controls and their save behavior.
- `navigation-247.cjs`: 320, 390, 900 and 1440px in dark/light themes. Every main page and all ten unit headers use their matching artwork; four Automation and two Ritual submenu headers match their buttons. Images load, layouts do not overflow, navigation does not spend game resources, section preferences survive reload, keyboard/touch work, and responsive submenu placement remains correct. On the final layout, actual blessing/permanent-upgrade purchases, ascension, exact shard accounting and history persistence pass. Challenge Rewards occur once, in Milestones; history is collapsed under Options.
- `automation-browser-242.cjs`: all four widths/two themes, all 50 switches, actual buyer cycle, V8 restore, resize/reload and post-ascension behavior passed with the shared navigation changes.
- `save-tabs-246.cjs`: simultaneous launches, stale tabs, active-owner handoff, recovery checkpoint, external rollback, restored documents and unavailable coordination support passed.
- `rendering.cjs`: template regressions and script syntax passed.
- Desktop and phone screenshots were visually inspected locally; no new screenshots are part of this release.

## Limits and compatibility

No player late-game save was supplied, so pacing uses fresh earned-resource policies and explicit fixtures. Progress, owned units, paid ranks, history, save schema and portable save-code formats remain intact. Existing late-game prices change prospectively; no refund/reset is performed. Multi-tab protection remains local, and browser storage clearing can still remove local saves. Close older-version game tabs before loading the update and keep an exported backup.

Browser QA initially encountered a truncated local Chromium binary. Restoring the test runtime resolved it. One new UI assertion compared two equivalent floating-point string forms; the assertion now checks the actual whole-shard balance.
