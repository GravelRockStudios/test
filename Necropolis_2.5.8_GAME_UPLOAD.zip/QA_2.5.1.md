# 2.5.1 — First-run guidance and readability

## Changes

- Four-step, non-modal introduction for a fresh game. Players can follow links to the actual screens, move backward/forward, skip, and replay from Options. The current step is retained in browser display preferences, independently of portable gameplay saves.
- The objective panel was present in the source but hidden by CSS. It is visible above the main content again, with a persistent contextual next-action button. Objectives now include the first unraised, revealed tier. Hints cover Skeletons, Necromancers, the three-Necromancer Dark Energy unlock, Territory, and ascension.
- The mobile backup reminder links directly to the existing save-code tools and also detects iPads presenting as a desktop Mac. It appears before the main game content. It does not claim that generating or copying a code automatically stores an external backup.
- Descriptions and objective values can wrap. Mobile navigation tabs expand to fit their labels; labels no longer have to fit the previous fixed 125px width. The originally reported mid-description clipping from v2.4.9 was not reproduced in the supplied v2.5.0 main screens; these changes address remaining wrapping risks and the constrained navigation labels.

## Executed checks

- `node qa/verify.cjs`: all 40 core scenarios passed.
- `NECRO_CHROMIUM=/usr/bin/chromium node qa/first-steps.cjs`: passed at 320, 390 and 1440px, dark and light themes, with the large-text preference enabled. Covers real recruitment and Undo, tour resume/completion/skip/replay, direct destinations, save-code generation, label/description bounds, existing and ascended games, progression hints, Energy gating, iPad detection and browser errors.
- `NECRO_CHROMIUM=/usr/bin/chromium NECRO_QA_WIDTHS=320,390,1440 node qa/navigation-250.cjs`: passed. Covers navigation, keyboard controls, purchases/Undo, sticky rail, reload and horizontal overflow.
- `NECRO_CHROMIUM=/usr/bin/chromium node qa/save-tabs-250.cjs`: passed all multi-tab ownership and recovery checks.
- `node qa/portable-240.cjs`: passed 36 exact V8 round trips, gzip, and malformed-data rejection.

The first two script blocks (game core and milestones) and all artwork match the original archive byte-for-byte. The save schema and economy are unchanged. Browser checks used Chromium with mobile layouts and simulated device identification; physical iOS Safari and itch.io storage eviction were not tested. A reminder cannot prevent browser storage loss: players still need to keep an external backup.

## Run locally

The game is a static site: serve this directory with `python3 -m http.server 8000` and open `index.html` through that server. Browser QA scripts require Node.js, Playwright, and a Chromium executable (set `NECRO_CHROMIUM` to its path). No build is required for the uploaded game.
