// Reproductions for the October 10 fixes-to-ship report.
const fs=require('fs'),path=require('path'),http=require('http'),vm=require('vm'),assert=require('assert');
const {chromium}=require('playwright'),C=require('./extract-core.cjs'),N=C.N;
const root=path.resolve(__dirname,'..'),key='necropolis-v3-save',errors=[];
const scripts=[...fs.readFileSync(path.join(root,'index.html'),'utf8').matchAll(/<script[^>]*>([\s\S]*?)<\/script>/g)];
const sandbox={NecropolisCore:C};vm.runInNewContext(scripts[1][1],sandbox);const M=sandbox.NecropolisMilestones;
const server=http.createServer((req,res)=>{const file=path.join(root,new URL(req.url,'http://localhost').pathname);if(!file.startsWith(root+path.sep)){res.statusCode=403;return res.end();}try{res.setHeader('Content-Type',file.endsWith('.png')?'image/png':file.endsWith('.svg')?'image/svg+xml':'text/html');res.end(fs.readFileSync(file));}catch{res.statusCode=404;res.end();}});
function near(a,b){assert(Math.abs(N.of(a).div(b).num()-1)<1e-8,`${a} != ${b}`);}
function campaign(id,{fast=false,earned=false,stage=0}={}){
 const s=C.fresh();s.prestiges=4;s.n.souls=N.of('1e90');s.n.runSouls=N.of('1e90');s.n.allSouls=N.of('1e90');s.n.totalTerritory=N.of('1e90');s.n.total_necromancers=N.of(5);s.n.raiders=N.of(100);s.n.total_raiders=N.of(100);s.energy=5000;s.warpCount=1;
 if(earned)s.achievements.push(`campaign_${id}_1`);
 if(stage){s.empire.campaigns.completed=[id];s.empire.campaigns.stages={[id]:stage};s.achievements.push(`campaign_${id}_1`);}
 if(fast){s.n.skeletons=N.of('1e19');s.n.total_skeletons=s.n.skeletons;s.empire.conquest=20;}
 C.startCampaign(s,id);const remaining=C.campaignSecondsRemaining(s,id);
 if(!fast){assert(remaining>1);C.advance(s,remaining-.25);}
 assert.equal(C.campaignLevel(s,id),stage);s.last=Date.now();M.check(s);return s;
}
(async()=>{await new Promise(r=>server.listen(0,'127.0.0.1',r));const browser=await chromium.launch({headless:true,executablePath:process.env.NECRO_CHROMIUM,args:['--no-sandbox','--disable-dev-shm-usage','--disable-gpu']});try{
 async function open(s,width=390,theme='dark',awaySeconds=0){
  const ctx=await browser.newContext({viewport:{width,height:1000}});
  await ctx.addInitScript(({raw,key,now,theme})=>{window.__qaNow=now;Date.now=()=>window.__qaNow;window.__qaTicks=[];window.setInterval=(fn,ms)=>{if(ms===1000)window.__qaTicks.push(fn);return 0;};if(!localStorage.getItem(key))localStorage.setItem(key,raw);localStorage.setItem('necropolis-v3-preferences',JSON.stringify({theme}));},{raw:C.serialize(s),key,now:s.last+awaySeconds*1000,theme});
  const page=await ctx.newPage();page.on('pageerror',e=>errors.push(e.message));await page.goto(`http://127.0.0.1:${server.address().port}/index.html`);await page.locator('#tabs').waitFor();
  const tab=id=>page.locator(`#tabs [data-tab="${id}"]`).click();
  const read=async()=>C.unpack(await page.evaluate(key=>localStorage.getItem(key),key));
  const persist=async()=>{await tab('automation');await page.locator('[data-auto-page="overview"]').click();await page.locator('[data-auto-reserve="50"]').click();return read();};
  const tick=seconds=>page.evaluate(seconds=>{window.__qaNow+=seconds*1000;for(const fn of window.__qaTicks)fn();},seconds);
  return{ctx,page,tab,read,persist,tick};
 }
 for(const width of [390,1440]){
  for(const id of Object.keys(C.CAMPAIGNS))for(const fast of [false,true]){
   const s=campaign(id,{fast}),{ctx,page,tab,persist,tick}=await open(s,width);await tab('territory');
   assert.equal(await page.locator('#milestoneToast.visible').count(),0);await tick(1);
   const toast=await page.locator('#milestoneToast').innerText();assert(toast.includes(C.CAMPAIGNS[id].name+' · 1 victory'),toast);
   const won=await persist();assert.equal(C.campaignLevel(won,id),1);assert.equal(won.achievements.filter(a=>a===`campaign_${id}_1`).length,1);
   await page.evaluate(()=>document.querySelector('#milestoneToast').textContent='No new notification');await tick(1);assert.equal(await page.locator('#milestoneToast').innerText(),'No new notification');
   await page.reload();assert.equal(await page.locator('#milestoneToast.visible').count(),0);await ctx.close();
  }
  console.log(`PASS ${width}px: all three first campaign awards/toasts, normal and very high production, no duplicate after tick/reload`);
  for(const mode of ['earned','third','warp','offline']){
   const s=campaign('cemetery',{earned:mode==='earned',stage:mode==='third'?2:0});
   const {ctx,page,tab,persist,tick}=await open(s,width,'dark',mode==='offline'?60:0);
   if(mode==='warp'){await tab('energy');await page.locator('[data-warp="0.25"]').click();}
   else if(mode!=='offline')await tick(1);
   if(mode==='earned'||mode==='offline')assert.equal(await page.locator('#milestoneToast.visible').count(),0);
   else assert((await page.locator('#milestoneToast').innerText()).includes('Forgotten Cemetery'));
   const won=await persist();assert.equal(C.campaignLevel(won,'cemetery'),mode==='third'?3:1);assert(won.achievements.includes(mode==='third'?'campaign_cemetery_3':'campaign_cemetery_1'));
   if(mode==='earned')assert.equal(won.achievements.length,s.achievements.length);
   if(mode==='offline')assert((await page.locator('body').innerText()).includes('Forgotten Cemetery'));
   await ctx.close();
  }
  console.log(`PASS ${width}px: Cemetery already-earned suppression, third-victory award, Time Warp and offline recording`);
 }
 if(!process.env.NECRO_REPORT_CAMPAIGN_ONLY){
  for(const width of [320,390,1440])for(const theme of ['dark','light']){
   const s=C.fresh();for(const id of [...C.IDS,...C.TERRITORY_IDS]){s.n[id]=N.of(1000);s.n['total_'+id]=s.n[id];}s.n.souls=N.of('1e12');s.n.graveSeeds=N.of('1e8');s.n.totalTerritory=N.of('1e6');s.upgrades.twin_raiders=1;s.upgrades.twin_skeletons=2;M.check(s);
   const {ctx,page,tab,read,persist}=await open(s,width,theme);await tab('territory');
   assert((await page.locator('label[for="customBatch"]').innerText()).includes('purchases'));
   assert((await page.locator('#customBatchHelp').innerText()).includes('2 Grave Raiders'));
   const before=await read();await page.locator('#customBatch').fill('=10000');await page.locator('[data-batch-buy="conquest"]').click();const after=await read();
   near(after.n.raiders.sub(before.n.raiders),20000);near(before.n.souls.sub(after.n.souls),7500000);near(before.n.graveSeeds.sub(after.n.graveSeeds),10000);
   await tab('undead');assert((await page.locator('#customBatchHelp').innerText()).includes('3 Skeletons'));const beforeUnits=await read();await page.locator('#customBatch').fill('=10');await page.locator('[data-batch-buy="buy"]').click();const afterUnits=await read();near(afterUnits.n.skeletons.sub(beforeUnits.n.skeletons),30);near(beforeUnits.n.graveSeeds.sub(afterUnits.n.graveSeeds),10);
   assert(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));
   if(process.env.NECRO_SCREENSHOT_DIR&&theme==='dark'&&width!==320)await page.locator('.batch-buy').screenshot({path:path.join(process.env.NECRO_SCREENSHOT_DIR,`custom-batch-${width}.png`)});
   await tab('automation');await page.locator('[data-auto-page="undead"]').click();assert.equal(await page.locator('[data-auto-upgrade^="twin_"] .auto-control-label').count(),10);assert((await page.locator('[data-auto-upgrade^="twin_"] .auto-control-label').allTextContents()).every(t=>t==='Multiply'));
   assert.equal(await page.locator('[data-auto-upgrade="twin_tombtitans"] .auto-control-state').innerText(),'Off');
   await persist();await ctx.close();console.log(`PASS ${width}px ${theme}: custom purchases label, 10000 purchases = 20000 Raiders, undead multiplier, consistent Multiply and no overflow`);
  }
 }
 assert.deepEqual(errors,[]);console.log('PASS report checks with no page errors');
}finally{await browser.close();server.close();}})().catch(e=>{console.error(e);server.close();process.exitCode=1;});
