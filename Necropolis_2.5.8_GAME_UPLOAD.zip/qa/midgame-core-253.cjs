const assert=require('assert/strict'),C=require('./extract-core.cjs'),N=C.N;
const near=(a,b)=>assert(Math.abs(N.of(a).sub(b).num())<1e-6,`${a} != ${b}`);
// Existing paid ranks and inventories survive import, with the new rates applied.
const saved=C.fresh();saved.upgrades.upgrades=4;saved.upgrades.twin_liches=2;saved.n.liches=N.of(2);saved.n.total_liches=N.of(2);const raw=C.serialize(saved),loaded=C.unpack(raw);assert.equal(C.serialize(loaded),raw);near(C.graveSeedRate(loaded),17);near(C.batchSize(loaded,'liches'),3);
// The bridge is affordable at its stated costs, then raises two Liches for one recipe.
const s=C.fresh();s.n.souls=N.of(200000);s.n.territory=N.of(125);s.n.graveSeeds=N.of(250);s.n.necromancers=N.of(20);s.n.total_necromancers=N.of(20);s.n.totalTerritory=N.of(125);s.n.total_liches=N.of(1);assert.equal(C.buyUpgrade(s,'twin_liches',1),1);near(s.n.souls,0);near(s.n.territory,0);s.n.souls=N.of(20000);near(C.buy(s,'liches',1),2);near(s.n.necromancers,0);near(s.n.graveSeeds,0);s.n.liches=N.of(24);s.n.souls=N.of(1e6);s.n.graveSeeds=N.of(1500);assert(C.buy(s,'deathlords',1));near(s.n.liches,0);
// A fresh save can cast at 30 minutes; the warp itself never regenerates Energy.
const warp=C.fresh();C.advance(warp,1799);const before=C.serialize(warp);assert.equal(C.warp(warp,.25),false);assert.equal(C.serialize(warp),before);C.advance(warp,1);assert(C.warp(warp,.25));near(warp.energy,0);near(warp.n.graveSeeds,2710);
// Ledger enabled/disabled paths have identical state, and receipts balance gross production.
for(const offline of [false,true])for(const seconds of [300,3600]){
 const a=C.fresh();for(const k of ['souls','graveSeeds','territory','totalTerritory'])a.n[k]=N.of(100000);a.n.skeletons=N.of(100);a.n.total_skeletons=N.of(100);a.autoEnabled=true;a.autoConfig={...a.autoConfig,offline:true,units:['skeletons'],upgrades:['harvest','tier_skeletons']};const b=C.copyState(a),startSouls=a.n.souls,startSeeds=a.n.graveSeeds,startTerritory=a.n.territory,startHarvest=a.n.runSouls;
 const result=C.advanceWithAutomation(a,seconds,{offline,trackProduction:true,trackSpending:true});C.advanceWithAutomation(b,seconds,{offline});assert.equal(C.serialize(a),C.serialize(b));assert(result.purchases>0);assert(Object.keys(result.spending.items).length>0);near(startSouls.add(a.n.runSouls.sub(startHarvest)).sub(result.spending.spent.souls),a.n.souls);near(startSeeds.add(result.production.seeds).sub(result.spending.spent.graveSeeds),a.n.graveSeeds);near(startTerritory.sub(result.spending.spent.territory||0),a.n.territory);
}
console.log('PASS existing saves, paid ranks, bridge costs, first warp boundary, and exact active/offline spending ledger without simulation changes');
