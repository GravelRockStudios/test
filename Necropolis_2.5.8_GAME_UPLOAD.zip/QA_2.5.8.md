# QA 2.5.8

Recruitment and upgrades now share a page for every undead tier. The old upgrade destination opens Recruitment and scrolls to its upgrade section. There is no separate upgrade item in the navigation. Intro gates still apply.

Checks completed in Chromium:

- `qa/navigation-252.cjs`: all ten tiers at 320, 390, 900 and 1440px, in dark and light themes. Confirms production rates, recruitment before upgrades, same-tier upgrade controls, costs, purchases, Undo, jump focus and affordability styling. Navigation leaves game progress unchanged.
- `qa/first-steps.cjs`: all seven goals, hidden systems, skip, replay, reload and backup guidance.
- `qa/release-257.cjs`: 240 pointer/keyboard purchases with forced refresh timing, text bounds, presets, Starting Legion, actual automated warp purchases and audio controls. The audio assertion waits for asynchronous resume to finish.
- `qa/audio-options-257.cjs`: default effects, finite sound voices, persisted mute preference and Options number contrast/size.
- All inline scripts parse. Core and milestone scripts match 2.5.7 after normalizing prose dash punctuation. No gameplay formula or save-format change.
- Desktop and mobile screenshots reviewed for spacing and column layout.

The README now describes the game and links to the current download. Current game text and documentation use ordinary hyphens instead of long dashes. Repository license wording uses a general ownership section while retaining copyright limitations and third-party rights. Existing release downloads and history are retained.

The ZIP has index.html at its root and is checked against the current source and for archive integrity. Hosted itch.io and physical Edge were not tested.
