# 2.4.9 QA

## P0 L1: orphaned save ownership

Previously, a lifetime Web Lock had no stale-owner recovery or takeover
control. A retained lock could leave the only visible tab permanently
read-only despite repeated reloads.

The session now maintains a separate owner token and 60-second expiry,
renewed every 10 seconds. Waiting tabs retry ownership; expired claims can
be replaced with Web Locks' steal operation. A read-only banner provides
Take over this save. A responsive owner flushes its latest state and releases
ownership; older locks without heartbeat metadata can be replaced explicitly.
The new owner restores the latest stored game before advancing or saving.

The previous document checks its ownership token before mutation, catch-up,
saving and recovery writes. Expired claims cannot simply renew themselves.
Handed-off tabs stay read-only until the player asks to continue there.
Unavailable coordination remains read-only, with backup export available.

Browser regression results (`qa/save-recovery-249.cjs`):

- Live takeover saves and transfers the latest progress; old pagehide does not overwrite it.
- A frozen Chromium document cannot process storage events or unloading. After its claim expires, a waiting tab recovers automatically.
- Thawing that old document leaves it read-only; attempted purchases and pagehide cannot overwrite the newer save.
- Ownership checks also block stale actions when storage events are suppressed.
- A retained legacy lock with no heartbeat remains blocked after reload, then recovers through the takeover button.
- Simultaneous stale-owner recovery attempts settle on exactly one writer.

Existing multi-tab regressions also pass: idle-tab protection, simultaneous
startup races, external rollback detection, back/forward restoration,
latest-save recovery, and unavailable/rejected Web Locks.

## Balance and progression

- 40 core scenarios pass, including exact offline/online production,
  campaign forecasts, warp projections, migration, spending and ascension.
- All ten highest-tier frontiers permit Recruit and Multiplicity after their
  first unit, leave new choices Off, and preserve active/offline equivalence.
- Next-tier Seed protection passes at all nine gates and four reserve levels.
- Seven-day active, offline and interrupted/reloaded simulations agree;
  disabled offline buying, warp timing and ascension checks pass.
- The supplied V8 code imports unchanged in mobile and desktop browser tests.
- Automation UI checks pass at 320/390/900/1440px in dark and light themes,
  including all 50 switches, actual purchases, restore and post-ascension gates.
- Fresh browser UI playthroughs reach Endbringers, complete all campaign types,
  ascend, buy Grave Bloom, reload and continue the next run. Only time was
  accelerated; no resources were injected into these fresh playthroughs.
- Original artwork and license are retained. The portable save schema remains
  V8, and user progress is not packaged into the game.

See BALANCE_AUDIT_2.4.9.md for exact costs and before/after pacing. The developer
balance model and browser QA are representative policies, not exhaustive
proofs of every strategy or every browser vendor's lifecycle behavior.
