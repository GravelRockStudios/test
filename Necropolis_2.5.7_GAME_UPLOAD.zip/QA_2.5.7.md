# QA — 2.5.7

## Reproduced click failure

`qa/release-257.cjs` forces a production refresh after pointer-up and before the native click. With `NECRO_BASELINE_ONLY=1 NECRO_HTML=/tmp/necro-2.5.6-baseline.html`, v2.5.6 fails on the first purchase: no manual purchase is recorded. The new build passes 25 pointer purchases and 5 Space-key purchases per width/theme (320, 390, 900 and 1440px; dark and light): 240 successful forced-race purchases. This establishes and fixes one concrete cause of intermittent silent clicks; physical Edge and the hosted itch.io build were not tested.

The same suite verifies Overview B, Recruitment landing, presets with Undo, an actual Starting Legion purchase, prose bounds within elements and the viewport at large font size, and one native Web Audio context that runs when enabled and suspends when muted.

## Gameplay and saves

- `node qa/warp-257.cjs`: automated warps match one-second advancement in Off, Repeat and Rotate campaign modes. Confirms upgrade purchases, receipts, reserve behavior through the shared engine, fixed warp duration, no energy regeneration, unchanged real-time clock and manual purchase count; paused/insufficient-energy cases; starting-unit grants and persistent energy upgrades through ascension; save round-trip; gated army presets.
- `node qa/verify.cjs`: 40 core scenarios passed. Cycle-specific fixtures use the new interval; resource reserve checks remain in place.
- `node qa/portable-240.cjs`: 36 exact portable round-trips plus corrupt-save rejection.
- `node qa/midgame-core-253.cjs`: existing saves, paid ranks, bridge costs, first-warp boundary and spending conservation.
- `node qa/production-forecast-254.cjs`: 72 production-curve comparisons, immutable snapshots and large numbers.
- `qa/save-tabs-250.cjs`: writer ownership, simultaneous starts, stale revisions, back-forward recovery and absent coordination.
- `qa/intro-progress.cjs`: populated progress and backups survive replay and reload, standalone and embedded, at 390/1440px.
- `qa/first-steps.cjs`: all seven real-play goals, unlock gates, reload, skip, replay, backup and iPad reminder.
- `qa/navigation-252.cjs`: all ten tier links and production rates, cost bars, affordability styling, Undo and navigation at four widths and both themes. Landing assertion updated to Recruitment.
- `qa/disclosure-refresh.cjs`: open/closed details and focus survive repeated production ticks; test explicitly navigates to Overview now.

Browser tests use Playwright with `NECRO_CHROMIUM=/usr/bin/chromium`.

## Performance and presentation

`NECRO_PERF_OUTPUT=territory-performance-2.5.7.json` with `qa/territory-performance-254.cjs`: 12 width/army-size/campaign-mode cases, 100 ticks each. P95 refresh 10.5–28.8ms; retained post-GC heap growth approximately 150–188KB. Purchase wait previews call no full advancement. Results in `qa/territory-performance-2.5.7.json`.

One-shot automated 8.6-hour warps with 515 buyer cycles measured 80–94ms locally, including fixtures up to 1e1000. Automated warp forecasts are not recomputed each UI refresh.

Desktop Energy and Blessings screenshots were visually reviewed. All inline scripts parse. The uploaded ZIP is checked for root index.html, matching source bytes and archive integrity.

## Limits

The request to https://apoped.itch.io/necropolis-rise-of-the-undying was blocked by an HTTP CONNECT 403. The hosted description and hosted Edge behavior remain unverified; packaged ITCH_DESCRIPTION.md contains corrected copy. No external itch.io settings were changed. Audio context lifecycle was checked in Chromium; subjective sound quality and physical device playback were not tested. Shard/legacy prices and new energy sinks need a separate balance pass; this release explains the existing formula and doctrine-switch use.
