# 2.5.4 verification

## Reproduction and cause

A populated v2.5.3 fixture with 100 Necromancers, 2 Liches, 1 Death Host and rotating campaigns reproduced the reported slowdown. Selecting Death Hosts took about 868 ms; five refreshes took 662–773 ms, with 70 complete simulation calls each. Selecting Eternal War Councils took about 1,103 ms; five refreshes took 1,028–1,070 ms, with 82 complete simulation calls each. Leaving Territory took 7 ms.

The purchase ETA solver searched far into the future. Every probe copied the full state and advanced actual campaign simulation, including future campaign rewards and handoffs. Multiple expensive card estimates repeated this work every second. This explains sustained CPU usage and allocation churn on the affected screens. No independent unbounded memory leak was established.

## Change and estimate assumptions

The new read-only `productionForecast` constructs the triangular production polynomial once per screen refresh and evaluates only the required resources. Passive production from every higher undead tier is included, including its contribution to growing Skeleton, Soul and Territory production. Seed production uses current bonuses. Territory estimates include the current campaign share; a manual campaign stops committing after its current target, while automatic continuation assumes that share remains in use.

Purchase forecasts do not predict future campaign rewards or automatic buyer spending. They say “current bonuses”; purchases, victories, assignments and Time Warps can change a wait. Actual campaign countdowns, offline simulation and Time Warp projections retain their existing full-engine behavior.

Removing only the new forecast function and export from the first script reproduces the v2.5.3 engine script byte for byte. The milestone script is also byte-identical. This release changes no game simulation, balance, inventories, save schema or portable codec.

## Verification

- `qa/production-forecast-254.cjs`: 72 exact current-bonus comparisons against real production across four doctrines, quantities through 1e1000, and durations from fractions of a second to 1e11 seconds. Also checks immutable snapshots, Territory commitments, invalid input rejection and no live-state mutation.
- `qa/territory-performance-254.cjs`: twelve desktop/mobile combinations of ordinary and large-number saves, with campaigns Off/Repeat/Rotate. Checks repeated switching between Death Hosts and Eternal War Councils, 100 production refreshes, saved resource/campaign parity, at most one production curve per refresh, zero complete simulation calls from purchase estimates, responsiveness, page errors and retained heap after explicit garbage collection. Results are saved in `qa/territory-performance-2.5.4.json`.
- Direct before/after reproduction: the repaired Death Host click took 9.3 ms and refreshes 9.2–15.8 ms; Eternal War Council click took 9 ms and refreshes 5.9–13.3 ms. Every purchase forecast made zero complete simulation calls.
- `qa/verify.cjs`: all 40 core scenarios pass.
- `qa/first-steps.cjs`, `qa/intro-progress.cjs`, `qa/disclosure-refresh.cjs`, `qa/navigation-252.cjs`, `qa/midgame-253.cjs`, `qa/midgame-core-253.cjs` and `qa/save-tabs-250.cjs`: pass, covering onboarding, populated-save replay, panels staying open, navigation/Undo, purchases, spending feedback and save ownership.

Browser checks use Chromium via `NECRO_CHROMIUM=/usr/bin/chromium`. The user's actual Edge/itch.io session was not inspected. Performance timings describe this environment and fixture, not a guarantee for every device. Upload the new ZIP to itch.io to replace the hosted v2.5.3 build.
