/* Necropolis 1.5.8: Clearer Vessel bonus and complete changelog history; save schema 20. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;root.NecropolisCore=api;})(typeof globalThis!=='undefined'?globalThis:this,function(){
'use strict';
class N {
 constructor(m=0,e=0){if(!Number.isFinite(m)||!Number.isFinite(e)||!Number.isInteger(e)||Math.abs(e)>1e15)throw Error('Number outside supported exponent range');if(m<=0){this.m=0;this.e=0;return;}const parts=m.toExponential().split('e');this.m=Number(parts[0]);this.e=e+Number(parts[1]);if(!Number.isFinite(this.e)||Math.abs(this.e)>1e15)throw Error('Exponent range exceeded');}
 static of(v){if(v instanceof N)return v;if(v===null||v===undefined)return new N();if(typeof v==='object'&&typeof v.m==='number'&&typeof v.e==='number')return new N(v.m,v.e);if(typeof v==='string'){const t=v.trim();const match=t.match(/^(\d+(?:\.\d*)?|\.\d+)(?:e([+-]?\d+))?$/i);if(!match)throw Error('Invalid quantity');const mantissa=Number(match[1]),exp=match[2]?Number(match[2]):0;return new N(mantissa,exp);}if(typeof v==='number')return new N(v);throw Error('Invalid numeric input');}
 add(v){v=N.of(v);if(!this.m)return v;if(!v.m)return this;const d=this.e-v.e;if(d>17)return this;if(d< -17)return v;if(d>=0)return new N(this.m+v.m*Math.pow(10,-d),this.e);return new N(v.m+this.m*Math.pow(10,d),v.e);}
 sub(v){v=N.of(v);if(this.cmp(v)<=0)return new N();if(!v.m||this.e-v.e>17)return this;return new N(this.m-v.m*Math.pow(10,v.e-this.e),this.e);}
 mul(v){v=N.of(v);return this.m&&v.m?new N(this.m*v.m,this.e+v.e):new N();}
 div(v){v=N.of(v);if(!v.m)throw Error('Division by zero');return this.m?new N(this.m/v.m,this.e-v.e):new N();}
 pow(p){if(!Number.isFinite(p)||p<0)throw Error('Invalid exponent');if(p===0)return N.of(1);if(!this.m)return new N();const log=this.log10()*p,e=Math.floor(log);return new N(Math.pow(10,log-e),e);}
 log10(){return this.m?Math.log10(this.m)+this.e:-Infinity;}
 cmp(v){v=N.of(v);if(!this.m)return v.m?-1:0;if(!v.m)return 1;return this.e===v.e?Math.sign(this.m-v.m):Math.sign(this.e-v.e);}
 floor(){if(this.e<0){const n=this.num();return Math.abs(n-1)<=Number.EPSILON*2?N.of(1):new N();}if(this.e>=15)return this;const n=this.num(),nearest=Math.round(n);return N.of(Math.floor(Math.abs(n-nearest)<=Number.EPSILON*Math.max(1,n)*2?nearest:n));}
 num(){if(!this.m)return 0;if(this.e>308)return Infinity;if(this.e< -324)return 0;return this.m*Math.pow(10,this.e);}
 toString(){return this.m?`${this.m}e${this.e}`:'0';}
 toJSON(){return this.toString();}
}
const Z=()=>N.of(0),val=x=>N.of(x),plus=(a,b)=>val(a).add(b),times=(a,b)=>val(a).mul(b),min=(a,b)=>val(a).cmp(b)<=0?val(a):val(b);
// Clean prices once at their source; fractional Territory costs are intentional.
function cleanCost(value){const x=val(value),rounded=new N(Number(x.m.toPrecision(14)),x.e);return rounded.e<12?val(rounded.num().toFixed(3)):rounded;}
function canPay(have,cost){have=val(have);cost=val(cost);if(have.cmp(cost)>=0)return true;if(!have.m)return false;const gap=cost.sub(have);return gap.cmp(1e-9)<=0||gap.div(cost).num()<=32*Number.EPSILON;}
function affordableCount(have,cost){const q=val(have).div(cost).floor(),next=q.add(1);return canPay(have,next.mul(cost))?next:q;}
const IDS=["skeletons", "necromancers", "liches", "deathlords", "sovereigns", "gravekings", "tombtitans", "eternalmonarchs", "voidregents", "endbringers"];
const LABELS=["Skeletons", "Necromancers", "Liches", "Archliches", "Deathlords", "Dreadlords", "Grave Kings", "Eternal Sovereigns", "Void Regents", "Endbringers"];
const LORE=["The first servants harvest souls from forgotten graves.", "Bonebinders raise Skeletons while you tend the empire.", "Deathless scholars train circles of Necromancers.", "Ancient masters awaken new Liches.", "Undying warlords gather orders of Archliches.", "Dreadlords unite Deathlords beneath one banner.", "Monarchs of buried cities appoint new Dreadlords.", "Eternal Sovereigns raise Grave Kings to rule their provinces.", "Regents of the void call Eternal Sovereigns into being.", "The final servants of the Necropolis summon Void Regents."];
// Production chain: each unit produces tier-1 at a small, explicit
// per-unit rate; these are NOT multiplied by tier-specific astronomical bases.
// No unit-production ceiling, soft cap, or diminishing returns on owned units.
const RATES=[1,.35,.035,.02,.005,48/43200,48/86400,60/259200,60/604800,60/1209600];
// Soul costs preserve the later tier curve; early tiers and sacrifice costs are tuned for recruitment payoff.
// A purchase is one seed-funded batch. Multiplicity changes batch output only.
const SOUL_COST=[10,810,25000,1500000,150000000,2e10,5e12,2e15,1e18,1e21].map(val);
const PREV_COST=[0,100,20,72,72,48,48,60,60,60];
const SEED_COST=[1,25,250,1500,10000,100000,1000000,10000000,100000000,1000000000];
const UNLOCK=[0,10,5,...Array(7).fill(1)];
const TERRITORY_IDS=['raiders','bonelegions','dreadmarshals','deathhosts','warcouncils'];
const TERRITORY_LABELS=['Grave Raiders','Bone Legions','Dread Marshals','Death Hosts','Eternal War Councils'];
const TERRITORY_LORE=['The vanguard claims abandoned roads and restless borderlands.','Ranks of bones march together to capture broad stretches of Territory.','Undying marshals lead relentless campaigns across the frontier.','Vast hosts seize entire provinces for the Necropolis.','Ancient councils direct conquest across the wasteland.'];
// Military tiers follow the same rising AFK refill curve as undead.
const TERRITORY_RATES=[.07,3.15,141.75,6378.75,287043.75];
const TERRITORY_COST=[750,337500,151875000,68343750000,30754687500000].map(x=>val(x));
const TERRITORY_PREV=[0,0,0,0,0].map(x=>val(x));
const RKEYS=['souls','territory','graveSeeds',...TERRITORY_IDS,...IDS];
const BKEYS=['harvestBlessing','summonBlessing','startBlessing','stewardBlessing','crownBlessing','vesselBlessing','currentBlessing','warpBlessing','autoBlessing','harvesterPath','conquerorPath','eternalPath'];
const UPGRADES={harvest:{field:'upgrades',name:'Grave Seed Cultivation',base:300,growth:10,currency:'souls',mult:1,about:'Each upgrade adds 3,600 Grave Seeds/hr before bonuses.'},necro:{field:'necroBoost',name:'Bonebinding',base:20000,growth:12,currency:'souls',mult:2,about:'Makes each Necromancer produce Skeletons faster. Each additional upgrade gives a smaller increase.'},lich:{field:'lichBoost',name:'Ancient Rites',base:250000,growth:12,currency:'souls',mult:2,about:'Makes each Lich produce Necromancers faster. Each additional upgrade gives a smaller increase.'},command:{field:'commandBoost',name:'Grave Command',base:1e8,growth:12,currency:'souls',mult:2,about:'Makes each Archlich produce Liches faster. Each additional upgrade gives a smaller increase.'},expand:{field:'expansions',name:'Grave Seed Expansion',base:10,growth:2.45,currency:'territory',mult:1.1,about:'Each upgrade adds 10% to Grave Seed production.'},energyCap:{field:'energyCapLevel',name:'Dark Energy Storage',base:150,growth:1.75,currency:'territory',mult:1,about:'Dark Energy capacity +10,000'},energyFlow:{field:'energyFlow',name:'Dark Conduits',base:30,growth:2.45,currency:'territory',mult:1,about:'Improves Dark Energy regeneration. Check the next-level rate below.'},warpMastery:{field:'warpMastery',name:'Chronomancy',base:100,growth:4,currency:'territory',mult:1,about:'Makes each Time Warp advance more time. Further upgrades give smaller increases after upgrade 15.'}};
// Production research spends resources instead of consuming the army it improves.
for(let i=0;i<IDS.length;i++)UPGRADES['tier_'+IDS[i]]={field:'tier_'+IDS[i],name:'Grave Empowerment',base:30*Math.pow(5,i),growth:6,currency:'territory',secondCurrency:'souls',secondBase:SOUL_COST[i].mul(10).num(),secondGrowth:8,mult:1.5,about:'Increases this unit’s production. Each additional upgrade gives a smaller increase.'};
// Pay in this tier's units to double its Territory output.
for(const id of TERRITORY_IDS)UPGRADES['tier_'+id]={field:'tier_'+id,name:'Conquest Empowerment',base:66,growth:666,currency:id,mult:2,about:'Doubles this conquest tier’s Territory production'};
for(let i=0;i<IDS.length;i++)UPGRADES['twin_'+IDS[i]]={field:'twin_'+IDS[i],name:'Grave Multiplicity',base:SOUL_COST[i].mul(150).num(),growth:8,currency:'souls',secondCurrency:'territory',secondBase:25*Math.pow(5,i),secondGrowth:4,mult:2,about:'Each upgrade adds one more unit to every purchase.'};
for(const id of TERRITORY_IDS)UPGRADES['twin_'+id]={field:'twin_'+id,name:'Conquest Multiplicity',base:100,growth:500,currency:'souls',secondCurrency:'graveSeeds',secondBase:1,secondGrowth:50,mult:2,about:'Each upgrade adds one more troop to every purchase'};
const ukeys=Object.values(UPGRADES).map(x=>x.field);
function fmt(v,style='compact') {
 const x=val(v);if(!x.m)return '0';
 if(x.e<0){const a=x.num();return a<.000001?a.toExponential(2):a<.01?a.toPrecision(3):a.toLocaleString('en-US',{maximumFractionDigits:4});}
 if(x.e<3)return x.num().toLocaleString('en-US',{maximumFractionDigits:Math.max(0,Math.min(3,3-x.e))});
 if(style==='scientific')return `${Number(x.m.toPrecision(3))}e${x.e}`;
 const suffix=['K','M','B','T','Qa','Qi','Sx','Sp','Oc','No','Dc','Ud','Dd','Td','Qad','Qid','Sxd','Spd','Ocd','Nod','Vg'];
 let group=Math.floor(x.e/3),scaled=Number((x.m*Math.pow(10,x.e-group*3)).toPrecision(3));
 if(scaled>=1000){scaled=1;group++;}
 // Continue with letter suffixes after Vg: aa, ab, ... az, ba, ...
 let label=suffix[group-1];if(!label){let n=group-suffix.length+25;label='';do{label=String.fromCharCode(97+n%26)+label;n=Math.floor(n/26)-1;}while(n>=0);}
 return `${scaled}${label}`;
}
const formattedRate=(n,seconds,style)=>fmt(val(n).mul(seconds),style);
function fresh(time=Date.now()){const n={};for(const k of [...new Set([...RKEYS,'runSouls','allSouls','totalTerritory',...[...IDS,...TERRITORY_IDS].map(k=>'total_'+k)])])n[k]=Z();n.souls=val(80);n.graveSeeds=val(10);const upgrades={};for(const field of ukeys)upgrades[field]=0;const blessings={};for(const field of BKEYS)blessings[field]=0;return {v:22,migration:null,empire:freshEmpire(),legacy:{unlocks:[],plan:null},n,upgrades,blessings,prestiges:0,shards:Z(),energy:120,achievements:[],autoEnabled:false,autoConfig:{units:[],research:false,expansions:false,reserve:50,offline:false,protect:true,skipSupplied:true,limits:{},reserveSouls:'0',reserveTerritory:'0'},autoElapsed:0,lastUpgradeEnergyAt:0,warpCount:0,warp24Count:0,runWarpCount:0,runManualPurchases:0,runStarted:time,runHistory:[],cleanWarpAscensions:0,lightTouchAscensions:0,startConfig:{inheritance:true,legion:true,automation:'paused'},last:time,backupAt:time};}
// Empire choices are constant between actions, preserving exact offline integration.
const DOCTRINES={
 horde:{name:'Endless Horde',desc:'Every purchased batch raises 1 extra unit. +25% Grave Seeds and +30% Territory; −15% natural undead production.'},
 lich:{name:'Lich Dominion',desc:'+50% Necromancer and Lich production, +25% Archlich production and Dark Energy regeneration; −20% Grave Seeds.'},
 cult:{name:'Soul Cult',desc:'+20% Soul income and double the Grave Offerings bonus; −10% Grave Seeds.'}
};
const DEVELOPMENTS={gravefields:{name:'Gravefields',desc:'+20% Grave Seed production per developed plot.'},crypts:{name:'Crypts',desc:'+20% Necromancer and Lich production per developed plot.'},obelisks:{name:'Obelisks',desc:'+20% Dark Energy regeneration per developed plot.'}};
const TEACHINGS={binding:{name:'Bonebinding',desc:'+15% Necromancer and Lich production per level.'},warfare:{name:'Warcraft',desc:'+15% Territory production per level.'},night:{name:'Night Studies',desc:'+15% Dark Energy regeneration per level.'},seeds:{name:'Grave Studies',desc:'+15% Grave Seed production per level. Unlock through the Ruined Academy or Eternal Archive.'}};
const CAMPAIGNS={cemetery:{name:'Forgotten Cemetery',target:2500},academy:{name:'Ruined Academy',target:10000},spire:{name:'Black Spire',target:50000}};
const LEGACY_UNLOCKS={claimedGround:{name:'Claimed Ground',cost:5,desc:'Add 1 permanent plot to Territory Development in Empire.'},archive:{name:'Eternal Archive',cost:8,desc:'Unlock Grave Studies in Empire Research and keep your selected research after ascension.'}};
// Schema 20 retires five tiers. Counts and paid ranks are merged once, by name.
const TIER_MERGES={eclipseemperors:'eternalmonarchs',duskarchons:'voidregents',nightimperators:'voidregents',oblivionheralds:'endbringers',deathincarnates:'endbringers'};
function readMigration(raw){if(raw==null)return null;if(!raw||typeof raw!=='object'||!Array.isArray(raw.rows))throw Error('Invalid conversion record');return {from:sanitizeLevel(raw.from),dismissed:raw.dismissed===true,rows:raw.rows.slice(0,5).map(r=>{if(!r||!Object.hasOwn(TIER_MERGES,r.id))throw Error('Invalid converted tier');return {id:r.id,owned:validateQuantity(r.owned).toString(),empowerment:sanitizeLevel(r.empowerment),multiplicity:sanitizeLevel(r.multiplicity)};})};}
function migrateTenTiers(s,raw){const rows=[];for(const [id,target] of Object.entries(TIER_MERGES)){
 const owned=validateQuantity(raw.n?.[id]??'0'),total=validateQuantity(raw.n?.['total_'+id]??owned);
 s.n[target]=s.n[target].add(owned);s.n['total_'+target]=s.n['total_'+target].add(total.cmp(owned)<0?owned:total);
 const empowerment=sanitizeLevel(raw.upgrades?.['tier_'+id]??0),multiplicity=sanitizeLevel(raw.upgrades?.['twin_'+id]??0);
 for(const [prefix,rank] of [['tier_',empowerment],['twin_',multiplicity]]){const key=prefix+target;s.upgrades[key]=sanitizeLevel(s.upgrades[key]+rank);}
 if(owned.m||total.m||empowerment||multiplicity)rows.push({id,owned:owned.toString(),empowerment,multiplicity});
 }
 if(rows.length)s.migration={from:raw.v,dismissed:false,rows};
}
function migrateLegacyRemoved(s,raw){const totals={eclipseemperors:'totalEclipseEmperors',duskarchons:'totalDuskArchons',nightimperators:'totalNightImperators',oblivionheralds:'totalOblivionHeralds',deathincarnates:'totalDeathIncarnates'};for(const id of Object.keys(TIER_MERGES)){s.n[id]=validateQuantity(raw[id]??0);s.n['total_'+id]=validateQuantity(raw[totals[id]]??s.n[id]);for(const prefix of ['tier_','twin_'])s.upgrades[prefix+id]=sanitizeLevel(raw[prefix+id]??0);}}

function freshCampaigns(){return {active:null,share:50,progress:{cemetery:'0',academy:'0',spire:'0'},completed:[]};}
function freshEmpire(){return {doctrine:'none',conquest:0,excavation:0,buildings:{gravefields:0,crypts:0,obelisks:0},insight:'0',lore:0,sacrificed:'0',teaching:'binding',campaigns:freshCampaigns()};}
function legacy(s){return s.legacy||{unlocks:[],plan:null};}
function legacyRank(s,id){return legacy(s).ranks?.[id]||(legacy(s).unlocks.includes(id)?1:0);}
function hasUnlock(s,id){return legacyRank(s,id)>0;}
function legacyOffer(s,id){const d=LEGACY_UNLOCKS[id];if(!d)return null;const rank=legacyRank(s,id),next=rank+1,cost=val(d.cost).mul(val(2).pow(rank));
 const names={claimedGround:['Claimed Ground','Grave Estates','Bone Citadel','Undying Domain'],archive:['Eternal Archive','Preserved Knowledge','Immortal Scholarship','Undying Wisdom']};
 const name=names[id][Math.min(rank,3)]+(rank>3?' · '+next:'');
 const desc=rank===0?d.desc:id==='claimedGround'?`Add 1 plot to Territory Development in Empire. Permanent extra plots: ${rank} → ${next}.`:`Start each new run with ${rank} Empire Research ${rank===1?'level':'levels'}.`;
 return {name,desc,cost,rank,next};
}
function startingLore(s,patient=s.cleanWarpAscensions>0){return Math.max(0,legacyRank(s,'archive')-1)+(patient?1:0);}
function readLegacy(raw){
 const result={unlocks:[],plan:null};if(raw===undefined)return result;
 if(!raw||typeof raw!=='object'||!Array.isArray(raw.unlocks)||raw.unlocks.some(id=>!Object.hasOwn(LEGACY_UNLOCKS,id)&&id!=='blueprints'))throw Error('Invalid permanent unlocks');
 result.unlocks=[...new Set(raw.unlocks)];
 if(raw.ranks!==undefined){if(!raw.ranks||typeof raw.ranks!=='object'||Array.isArray(raw.ranks))throw Error('Invalid permanent ranks');for(const [id,rank]of Object.entries(raw.ranks)){if((!Object.hasOwn(LEGACY_UNLOCKS,id)&&id!=='blueprints')||!Number.isSafeInteger(rank)||rank<2||rank>1024||!result.unlocks.includes(id))throw Error('Invalid permanent rank');}if(Object.keys(raw.ranks).length)result.ranks={...raw.ranks};}
 if(raw.plan!=null){const p=raw.plan;if(!p||typeof p!=='object'||!Object.hasOwn(DOCTRINES,p.doctrine)&&p.doctrine!=='none'||!Object.hasOwn(TEACHINGS,p.teaching))throw Error('Invalid Empire plan');
  const e=readEmpire({...p,insight:'0',lore:0,sacrificed:'0'});if(Object.values(e.buildings).some(n=>n>1000))throw Error('Empire plan too large');
  result.plan={doctrine:e.doctrine,conquest:e.conquest,excavation:e.excavation,teaching:e.teaching,buildings:{...e.buildings}};
 }return result;
}
function readEmpire(raw,oldCampaigns=false){const e=freshEmpire();if(raw===undefined)return e;if(!raw||typeof raw!=='object'||Array.isArray(raw))throw Error('Invalid empire');
 if(!['none',...Object.keys(DOCTRINES)].includes(raw.doctrine))throw Error('Invalid doctrine');e.doctrine=raw.doctrine;
 for(const k of ['conquest','excavation']){e[k]=sanitizeLevel(raw[k]??0);if(e[k]>100||e[k]%10)throw Error('Invalid assignment');}if(e.conquest+e.excavation>100)throw Error('Assignments exceed army');
 for(const k of Object.keys(e.buildings))e.buildings[k]=sanitizeLevel(raw.buildings?.[k]??0);
 e.lore=sanitizeLevel(raw.lore===undefined?0:raw.lore);e.insight=validateQuantity(raw.insight??'0').toString();e.sacrificed=validateQuantity(raw.sacrificed??'0').toString();
 if(raw.teaching!==undefined){if(!Object.hasOwn(TEACHINGS,raw.teaching))throw Error('Invalid teaching');e.teaching=raw.teaching;}
 if(raw.campaigns!==undefined){const c=raw.campaigns;if(!c||typeof c!=='object'||c.active!==null&&!Object.hasOwn(CAMPAIGNS,c.active)||![25,50,75].includes(c.share)||!Array.isArray(c.completed)||c.completed.some(id=>!Object.hasOwn(CAMPAIGNS,id)))throw Error('Invalid conquest campaign');
  e.campaigns.active=c.active;e.campaigns.share=c.share;e.campaigns.completed=[...new Set(c.completed)];
  if(c.stages!==undefined){if(!c.stages||typeof c.stages!=='object'||Array.isArray(c.stages))throw Error('Invalid campaign stages');for(const [id,n]of Object.entries(c.stages)){if(!Object.hasOwn(CAMPAIGNS,id)||!Number.isSafeInteger(n)||n<2||n>1024||!e.campaigns.completed.includes(id))throw Error('Invalid campaign stage');}if(Object.keys(c.stages).length)e.campaigns.stages={...c.stages};}
  for(const [id,d]of Object.entries(CAMPAIGNS)){const q=validateQuantity(c.progress?.[id]??'0'),won=e.campaigns.completed.includes(id),target=oldCampaigns?val(d.target/10):campaignTarget({empire:e},id);if(q.cmp(target)>0)throw Error('Invalid campaign progress');
   if(oldCampaigns&&won){if(q.cmp(target)!==0||c.active===id)throw Error('Incomplete campaign reward');e.campaigns.progress[id]='0';}else e.campaigns.progress[id]=q.toString();
  }
 }return e;
}
function empireUnlocked(s){return s.n.total_skeletons.cmp(100)>=0||s.prestiges>0;}
function doctrineUnlocked(s){return s.n.total_necromancers.cmp(5)>=0||s.prestiges>0;}
function harvestShare(s){return (100-s.empire.conquest-s.empire.excavation)/100;}
function sacrificeBonus(s){return .15*val(s.empire.sacrificed).div(1000).add(1).log10()*(s.empire.doctrine==='cult'?2:1);}
function campaignWon(s,id){return s.empire.campaigns.completed.includes(id);}
function campaignLevel(s,id){return s.empire.campaigns.stages?.[id]||(campaignWon(s,id)?1:0);}
function campaignTarget(s,id){return val(CAMPAIGNS[id].target).mul(val(10).pow(campaignLevel(s,id)));}
function campaignPlotBonus(s,id){return .2+.1*Math.log2(1+campaignLevel(s,id));}
function campaignWarpFactor(s){return 1+.1*Math.log2(1+campaignLevel(s,'spire'));}
function campaignInsightFactor(s){return 1+.15*Math.log2(Math.max(1,campaignLevel(s,'academy')));}
function campaignReward(s,id,next=true){const level=campaignLevel(s,id)+(next?1:0),pct=x=>Number((x*100).toFixed(2));if(id==='cemetery')return `Gravefields: +${pct(.2+.1*Math.log2(1+level))}% Grave Seed production per developed plot.`;if(id==='academy')return level===1?'Unlock Grave Studies in Empire Research.':'Grave Studies unlocked in Empire Research; +'+pct(.15*Math.log2(Math.max(1,level)))+'% Insight from Excavation.';return `Obelisks: +${pct(.2+.1*Math.log2(1+level))}% Dark Energy regeneration per developed plot. Time Warp: +${pct(.1*Math.log2(1+level))}% duration.`;}
function teachingBonus(s,id){return s.empire.teaching===id?.15*s.empire.lore:0;}
function empireUnitFactor(s,id){const e=s.empire,i=IDS.indexOf(id);if(i===0)return 1+(e.doctrine==='cult'?.2:0);let b=e.doctrine==='horde'?-.15:0;if(i===1||i===2)b+=.2*e.buildings.crypts+teachingBonus(s,'binding')+(e.doctrine==='lich'?.5:0);if(i===3&&e.doctrine==='lich')b+=.25;return 1+b;}
function empireSeedFactor(s){const e=s.empire;return (1+sacrificeBonus(s))*(1+campaignPlotBonus(s,'cemetery')*e.buildings.gravefields+teachingBonus(s,'seeds'))*(e.doctrine==='horde'?1.25:e.doctrine==='lich'?.8:e.doctrine==='cult'?.9:1);}
function empireEnergyFactor(s){const e=s.empire;return 1+campaignPlotBonus(s,'spire')*e.buildings.obelisks+teachingBonus(s,'night')+(e.doctrine==='lich'?.25:0);}
function empireConquestFactor(s){return (s.empire.doctrine==='horde'?1.3:1)+teachingBonus(s,'warfare');}
function armyConquestEach(s){return .0007*s.empire.conquest/100*empireConquestFactor(s);}
function armyExcavationEach(s){return .0002*s.empire.excavation/100*campaignInsightFactor(s);}
function armyConquestRate(s){return s.n.skeletons.mul(armyConquestEach(s));}
function excavationRate(s){return s.n.skeletons.mul(armyExcavationEach(s));}
function totalConquestRate(s){return TERRITORY_IDS.reduce((sum,id)=>sum.add(conquestRate(s,id)),armyConquestRate(s));}
function plotCapacity(s){const base=s.n.totalTerritory.cmp(25)<0?(s.lightTouchAscensions>0?3:0):3+2*Math.max(0,Math.floor(s.n.totalTerritory.div(25).log10()+1e-12));return base+(base?legacyRank(s,'claimedGround'):0);}
function usedPlots(s){return Object.values(s.empire.buildings).reduce((a,b)=>a+b,0);}
function developmentCost(s){return cleanCost(val(25).mul(val(2).pow(usedPlots(s))));}
function loreCost(s){return cleanCost(val(10).mul(val(4).pow(s.empire.lore)));}
function assignArmy(s,job,delta){if(!empireUnlocked(s)||!['conquest','excavation'].includes(job)||![10,-10].includes(delta))return false;const next=s.empire[job]+delta;if(next<0||next>100||s.empire.conquest+s.empire.excavation+delta>100)return false;s.empire[job]=next;return true;}
function chooseDoctrine(s,id){if(!doctrineUnlocked(s)||!Object.hasOwn(DOCTRINES,id)||s.empire.doctrine===id)return false;const cost=s.empire.doctrine==='none'?0:250;if(!canPay(s.energy,cost))return false;s.energy=Math.max(0,s.energy-cost);s.empire.doctrine=id;return true;}
function develop(s,id){if(!Object.hasOwn(DEVELOPMENTS,id)||usedPlots(s)>=plotCapacity(s))return false;const cost=developmentCost(s);if(!canPay(s.n.territory,cost))return false;s.n.territory=s.n.territory.sub(cost);s.empire.buildings[id]++;return true;}
function dismantle(s,id){if(!Object.hasOwn(DEVELOPMENTS,id)||s.empire.buildings[id]<1)return false;s.empire.buildings[id]--;return true;}
function studyLore(s){const cost=loreCost(s);if(!empireUnlocked(s)||!canPay(s.empire.insight,cost))return false;s.empire.insight=val(s.empire.insight).sub(cost).toString();s.empire.lore++;return true;}
function teachingUnlocked(s,id){return Object.hasOwn(TEACHINGS,id)&&(id!=='seeds'||campaignWon(s,'academy')||hasUnlock(s,'archive'));}
function teachingSwitchCost(s){return s.empire.lore===0?Z():val(10).mul(1+s.empire.lore);}
function chooseTeaching(s,id){if(!empireUnlocked(s)||!teachingUnlocked(s,id)||s.empire.teaching===id)return false;const cost=teachingSwitchCost(s);if(!canPay(s.empire.insight,cost))return false;s.empire.insight=val(s.empire.insight).sub(cost).toString();s.empire.teaching=id;return true;}
function startCampaign(s,id){const c=s.empire.campaigns;if(!Object.hasOwn(CAMPAIGNS,id)||s.n.totalTerritory.cmp(25)<0||campaignLevel(s,id)>=1024||c.active===id)return false;c.active=id;return true;}
function setCampaignShare(s,share){if(![25,50,75].includes(share)||s.empire.campaigns.share===share)return false;s.empire.campaigns.share=share;return true;}
function pauseCampaign(s){if(!s.empire.campaigns.active)return false;s.empire.campaigns.active=null;return true;}
function retainedConquestRate(s){return totalConquestRate(s).mul(s.empire.campaigns.active?1-s.empire.campaigns.share/100:1);}
function buyLegacyUnlock(s,id){const d=legacyOffer(s,id);if(!d||d.rank>=1024||!canPay(s.shards,d.cost))return false;s.legacy=readLegacy(legacy(s));s.shards=wholeShards(wholeShards(s.shards).sub(d.cost));if(d.rank===0)s.legacy.unlocks.push(id);else{s.legacy.ranks??={};s.legacy.ranks[id]=d.next;}return true;}
// Retired Blueprints are read for compatibility, refunded once, then discarded.
function retireBlueprints(s){const rank=legacyRank(s,'blueprints');if(rank)s.shards=wholeShards(s.shards.add(val(6).mul(val(2).pow(rank).sub(1))));s.legacy.unlocks=s.legacy.unlocks.filter(id=>id!=='blueprints');if(s.legacy.ranks){delete s.legacy.ranks.blueprints;if(!Object.keys(s.legacy.ranks).length)delete s.legacy.ranks;}s.legacy.plan=null;}
function sacrifice(s,pct){if(!doctrineUnlocked(s)||![10,25,50].includes(pct))return false;const q=s.n.skeletons.mul(pct/100).floor();if(q.cmp(1)<0)return false;s.n.skeletons=s.n.skeletons.sub(q);s.empire.sacrificed=val(s.empire.sacrificed).add(q).toString();return q;}

function blessingRefund(level){const early=Math.min(101,level);let amount=Z();for(let i=0;i<early;i++)amount=amount.add(3+4*i);if(level>101)amount=amount.add(val(403).mul(1.08).mul(val(1.08).pow(level-101).sub(1)).div(.08));return amount;}
function copyState(raw){const s=fresh(raw.last);s.migration=readMigration(raw.migration);s.empire=readEmpire(raw.empire,(raw.v??22)<22);s.legacy=readLegacy(raw.legacy);for(const k of Object.keys(s.n))s.n[k]=val(raw.n?.[k]??(k==='graveSeeds'?10:0));for(const id of [...IDS,...TERRITORY_IDS]){const key='total_'+id;if(s.n[key].cmp(s.n[id])<0)s.n[key]=s.n[id];}for(const k of ukeys)s.upgrades[k]=sanitizeLevel(raw.upgrades?.[k]??0);for(const k of BKEYS)s.blessings[k]=sanitizeLevel(raw.blessings?.[k]??0);s.prestiges=sanitizeLevel(raw.prestiges);s.shards=wholeShards(raw.shards??0);retireBlueprints(s);s.energy=Math.max(0,Math.min(1e12,Number(raw.energy??120)));s.achievements=Array.isArray(raw.achievements)?raw.achievements.filter(k=>typeof k==='string'&&k.length<120).slice(0,10000):[];s.autoEnabled=raw.autoEnabled===true;const cfg=raw.autoConfig&&typeof raw.autoConfig==='object'?raw.autoConfig:{};s.autoConfig={units:Array.isArray(cfg.units)?[...new Set(cfg.units.filter(id=>IDS.includes(id)||TERRITORY_IDS.includes(id)))].slice(0,20):[],research:cfg.research===true,expansions:cfg.expansions===true,reserve:[0,25,50,75].includes(cfg.reserve)?cfg.reserve:50,offline:cfg.offline===true,protect:cfg.protect!==false,skipSupplied:cfg.skipSupplied!==false,limits:{},reserveSouls:'0',reserveTerritory:'0'};
 // Existing 3.1 users retain their selected unit toggles but receive safer defaults.
 for(const id of [...IDS,...TERRITORY_IDS]){const str=cfg.limits?.[id];if(typeof str==='string'&&/^(none|\d+(?:\.\d+)?(?:e\+?\d+)?)$/i.test(str)&&str.length<48)s.autoConfig.limits[id]=str;}
 for(const [field,key] of [['reserveSouls','souls'],['reserveTerritory','territory']]){try{const rawValue=String(cfg[field]??'0');const amount=val(rawValue);if(amount.cmp(0)>=0&&rawValue.length<48)s.autoConfig[field]=rawValue;}catch(e){}}
 s.lastUpgradeEnergyAt=Number.isFinite(raw.lastUpgradeEnergyAt)?Math.max(0,Math.min(raw.lastUpgradeEnergyAt,Date.now())):Date.now();s.autoElapsed=Number.isFinite(raw.autoElapsed)?Math.max(0,raw.autoElapsed)%AUTO_INTERVAL:0;s.warpCount=sanitizeLevel(raw.warpCount??0);s.warp24Count=sanitizeLevel(raw.warp24Count??0);s.runWarpCount=sanitizeLevel(raw.runWarpCount??0);s.runManualPurchases=sanitizeLevel(raw.runManualPurchases??0);s.runStarted=Number.isFinite(raw.runStarted)&&raw.runStarted>=0?Math.min(raw.runStarted,Date.now()):Number.isFinite(raw.last)?Math.min(raw.last,Date.now()):Date.now();s.runHistory=Array.isArray(raw.runHistory)?raw.runHistory.slice(-60).filter(r=>r&&typeof r==='object'&&Number.isSafeInteger(r.number)&&r.number>0&&typeof r.shards==='string'&&r.shards.length<100).map(r=>({number:r.number,shards:r.shards,depth:Math.max(0,Math.min(15,Number(r.depth)||0)),duration:Math.max(0,Math.min(1e14,Number(r.duration)||0)),manual:Math.max(0,Math.floor(Number(r.manual)||0)),warps:Math.max(0,Math.floor(Number(r.warps)||0)),at:Math.max(0,Number(r.at)||0)})):[];s.cleanWarpAscensions=sanitizeLevel(raw.cleanWarpAscensions??s.runHistory.filter(r=>r.warps===0).length);s.lightTouchAscensions=sanitizeLevel(raw.lightTouchAscensions??s.runHistory.filter(r=>r.manual<=10).length);const st=raw.startConfig&&typeof raw.startConfig==='object'?raw.startConfig:{};s.startConfig={inheritance:st.inheritance!==false,legion:st.legion!==false,automation:st.automation==='resume'?'resume':'paused'};s.last=Number.isFinite(raw.last)?Math.max(0,raw.last):Date.now();if((raw.v??0)<16){for(const retired of ['conquerorPath','autoBlessing']){const level=s.blessings[retired];if(level>0){s.shards=s.shards.add(blessingRefund(level));s.blessings[retired]=0;}}}
 s.backupAt=Number.isFinite(raw.backupAt)?Math.max(0,Math.min(raw.backupAt,Date.now())):s.last;s.energy=Math.min(s.energy,energyCapacity(s));return s;}
function sanitizeLevel(x){if(typeof x!=='number'||!Number.isSafeInteger(x)||x<0)throw Error('Invalid level in save');return x;}
function loadLegacy(old){if(!old||typeof old!=='object'||old.v<2||old.v>9)throw Error('Unsupported legacy save');const s=fresh(old.last);const legacyTotals=['totalSkeletons','totalNecromancers','totalLiches','totalDeathlords','totalSovereigns','totalGraveKings','totalTombTitans','totalEclipseEmperors','totalEternalMonarchs','totalDuskArchons','totalVoidRegents','totalNightImperators','totalOblivionHeralds','totalDeathIncarnates','totalEndbringers'];const totalNames=Object.fromEntries(IDS.map((id,i)=>['total_'+id,legacyTotals[i]]));for(const k of Object.keys(s.n)){const legacyKey=totalNames[k]||k;const source=Object.hasOwn(old,k)?old[k]:old[legacyKey];if(typeof source==='number'&&Number.isFinite(source)&&source>=0)s.n[k]=val(source);}
 for(const k of ukeys){const a=old[k];if(typeof a==='number'&&Number.isFinite(a)&&a>=0)s.upgrades[k]=Math.min(Number.MAX_SAFE_INTEGER,Math.floor(a));}for(const k of BKEYS){const a=old[k];if(typeof a==='number'&&Number.isFinite(a)&&a>=0)s.blessings[k]=Math.min(Number.MAX_SAFE_INTEGER,Math.floor(a));}
 s.prestiges=Math.max(0,Math.floor(old.prestiges||0));s.shards=val(Math.max(0,old.shards||0));s.energy=typeof old.energy==='number'&&Number.isFinite(old.energy)?Math.max(0,old.energy):120;s.achievements=Array.isArray(old.achievements)?old.achievements.filter(k=>typeof k==='string'):[];s.last=typeof old.last==='number'&&Number.isFinite(old.last)?old.last:Date.now();for(const id of IDS){const total='total_'+id;s.n[total]=s.n[total].cmp(s.n[id])>=0?s.n[total]:s.n[id];}if((old.v??0)<16){for(const retired of ['conquerorPath','autoBlessing']){const level=s.blessings[retired];if(level>0){s.shards=s.shards.add(blessingRefund(level));s.blessings[retired]=0;}}}
 s.autoEnabled=false;s.energy=Math.min(s.energy,energyCapacity(s));return s;}
function serialize(s){const n={};for(const [k,v] of Object.entries(s.n))n[k]=v.toString();return JSON.stringify({...s,n,shards:s.shards.toString()});}
// Validate before replacing a live game. Old saves may omit new fields, but
// a version number alone is never a valid save. Corrupt optional history is skipped.
function validateQuantity(value){
 if(value===null||value===undefined)throw Error('Missing quantity');
 if(typeof value==='number'&&(!Number.isFinite(value)||value<0))throw Error('Invalid quantity');
 if(typeof value==='object'&&(!Number.isFinite(value.m)||value.m<0||!Number.isInteger(value.e)))throw Error('Invalid quantity');
 const n=val(value);if(!Number.isFinite(n.m)||!Number.isInteger(n.e))throw Error('Invalid quantity');return n;
}
function unpack(raw){
 if(typeof raw==='string'&&raw.length>3000000)throw Error('Save is too large');
 const x=typeof raw==='string'?JSON.parse(raw):raw;
 if(!x||typeof x!=='object'||Array.isArray(x)||!Number.isInteger(x.v))throw Error('Invalid save');
 if(x.v>=10&&x.v<=22){
  if(!x.n||typeof x.n!=='object'||Array.isArray(x.n)||!Object.hasOwn(x.n,'souls')||!Object.hasOwn(x.n,'skeletons'))throw Error('Incomplete save');
  for(const key of [...new Set([...Object.keys(fresh().n),...Object.keys(TIER_MERGES).flatMap(id=>[id,"total_"+id])])])if(Object.hasOwn(x.n,key))validateQuantity(x.n[key]);
  if(x.shards!==undefined)validateQuantity(x.shards);
  for(const field of ['energy','last','runStarted'])if(x[field]!==undefined&&(typeof x[field]!=='number'||!Number.isFinite(x[field])||x[field]<0))throw Error('Invalid '+field);
  if(x.last>8640000000000000||x.runStarted>8640000000000000)throw Error('Invalid timestamp');
  for(const obj of ['upgrades','blessings'])if(x[obj]!==undefined&&(!x[obj]||typeof x[obj]!=='object'||Array.isArray(x[obj])))throw Error('Invalid '+obj);
  const out=copyState(x);if(x.v<20)migrateTenTiers(out,x);
  out.runHistory=out.runHistory.filter(r=>{try{validateQuantity(r.shards);return Number.isFinite(r.at)&&Number.isFinite(r.manual)&&Number.isFinite(r.warps);}catch(e){return false;}});
  // Convert paid, retired production research into the active tier upgrades once.
  if(x.v<18){
   for(const id of TERRITORY_IDS){out.upgrades['twin_'+id]=Math.max(out.upgrades['twin_'+id],out.upgrades['tier_'+id]);out.upgrades['tier_'+id]=0;}
   // Old global research survives as historical ranks, not hidden multipliers.

  }
  // Ensure every formula needed by rendering and offline catch-up is supported.
  for(const id of IDS)perUnit(out,id);
  for(const id of TERRITORY_IDS)conquestPerUnit(out,id);
  for(const id of Object.keys(UPGRADES))priceAt(out,id);
  for(const id of BKEYS)blessingPrice(out,id,1);
  graveSeedRate(out);out.last=Math.min(out.last,Date.now());return out;
 }
 if(x.v>=2&&x.v<=9){
  if(typeof x.souls!=='number'||typeof x.skeletons!=='number'||x.souls<0||x.skeletons<0||!Number.isFinite(x.souls)||!Number.isFinite(x.skeletons))throw Error('Incomplete legacy save');
  const migrated=loadLegacy(x);migrateLegacyRemoved(migrated,x);migrated.v=17;return unpack(migrated);
 }
 throw Error('Unsupported save version');
}
// Bonus curves use finite rank counts; production uses large quantities.
function logBonus(level,weight=1,scale=1){return 1+weight*Math.log10(1+scale*Math.max(0,level)/10);}
function capacityBonus(s){const n=Math.max(0,s.blessings.vesselBlessing);return 1+n*.1/(1+n*.1);}
function energyCapacity(s){return Math.min(1e12,10000*(1+s.upgrades.energyCapLevel)*capacityBonus(s));}
function energyRate(s){const n=Math.max(0,s.blessings.currentBlessing);return (.1+.05*s.upgrades.energyFlow)*(1+n*.0005/(1+n*.0005))*empireEnergyFactor(s);}
function rankFactor(base,level){return val(base).pow(level);}
function milestoneFactor(s,id){return 1;}
function permanentBonus(s,id){
 const i=IDS.indexOf(id);
 const level=i===0?s.blessings.harvestBlessing+s.blessings.harvesterPath:s.blessings.summonBlessing+s.blessings.crownBlessing+s.blessings.eternalPath;
 return 1+(.25/(i+1))*Math.log10(1+Math.max(0,level));
}
function empowermentFactor(level){return val(1+.2*Math.sqrt(level));}
function researchFactor(s,id){const i=IDS.indexOf(id),field=i===1?'necroBoost':i===2?'lichBoost':i===3?'commandBoost':null;return val(1+.12*Math.sqrt(field?s.upgrades[field]:0));}
function bonus(s,id){return val(empowermentFactor(s.upgrades['tier_'+id]||0).num()+researchFactor(s,id).num()+permanentBonus(s,id)+empireUnitFactor(s,id)-3);}
function batchSize(s,id){return val(1+(s.upgrades['twin_'+id]||0)+(s.empire.doctrine==='horde'?1:0));}
function perUnit(s,id){if(TERRITORY_IDS.includes(id))return conquestPerUnit(s,id);return val(RATES[IDS.indexOf(id)]).mul(bonus(s,id)).mul(id==='skeletons'?harvestShare(s):1);}
function production(s,id){return s.n[id].mul(perUnit(s,id));}
// Production of any previous tier is automatic as soon as its immediate
// superior has been obtained. Refill is the time needed to replace the units
// spent on one more purchase of that superior (not the time to afford souls).
const SUPPLY_WINDOW=86400;
function supplyStatus(s,id){
 const idx=IDS.indexOf(id);
 if(idx<0||idx===IDS.length-1)return {growing:false,selfSustaining:false,seconds:null};
 const superior=IDS[idx+1],quantity=s.n[superior],rate=production(s,superior);
 if(quantity.cmp(1)<0||rate.cmp(0)<=0)return {growing:false,selfSustaining:false,seconds:null,superior};
 const seconds=val(PREV_COST[idx+1]).div(rate).num();
 return {growing:true,selfSustaining:rate.cmp(graveSeedRate(s).mul(batchSize(s,id)).div(SEED_COST[idx]))>=0,seconds,superior,rate};
}

function unlockRequirement(idx){return val(UNLOCK[idx]);}
function unlockStatus(s,idx){
 if(!Number.isInteger(idx)||idx<0||idx>=IDS.length)return {unlocked:false,requirements:[],missing:[]};
 const requirements=[];
 if(idx>0){requirements.push({key:'total_'+IDS[idx-1],label:LABELS[idx-1]+' raised this run',have:s.n['total_'+IDS[idx-1]],need:unlockRequirement(idx)});
 if(idx===2&&s.prestiges===0)requirements.push({key:'totalTerritory',label:'Territory captured this run',have:s.n.totalTerritory,need:val(1)});}
 for(const r of requirements)r.met=r.have.cmp(r.need)>=0;
 const missing=requirements.filter(r=>!r.met);
 return {unlocked:idx===0||s.n[IDS[idx]].cmp(1)>=0||s.n['total_'+IDS[idx]].cmp(1)>=0||missing.length===0,requirements,missing};
}
function revealed(s,idx){return unlockStatus(s,idx).unlocked;}
function visibleIds(s){const indices=IDS.map((_,i)=>i).filter(i=>i===0||revealed(s,i)||revealed(s,i-1));return indices.slice(0,Math.max(3,indices.length));}
// Higher-tier batches require more seeds. Passive recruitment never spends seeds.
// Seed generation is uncapped; it is an investment budget, not a passive upkeep tax.
// The separate input prevents unlimited, instant soul -> skeleton reinvestment.
function affordable(s,id){const idx=IDS.indexOf(id);if(idx<0)return Z();let q=min(affordableCount(s.n.graveSeeds,SEED_COST[idx]),affordableCount(s.n.souls,SOUL_COST[idx]));if(idx>0)q=min(q,affordableCount(s.n[IDS[idx-1]],PREV_COST[idx]));return q;}
function buy(s,id,quantity){if(!IDS.includes(id))return false;const idx=IDS.indexOf(id);if(!revealed(s,idx))return false;let qty=quantity==='max'?affordable(s,id):val(quantity);qty=qty.floor();if(qty.cmp(1)<0||qty.cmp(affordable(s,id))>0)return false;s.n.graveSeeds=s.n.graveSeeds.sub(qty.mul(SEED_COST[idx]));s.n.souls=s.n.souls.sub(qty.mul(SOUL_COST[idx]));if(idx>0)s.n[IDS[idx-1]]=s.n[IDS[idx-1]].sub(qty.mul(PREV_COST[idx]));const raised=qty.mul(batchSize(s,id));s.n[id]=s.n[id].add(raised);s.n['total_'+id]=s.n['total_'+id].add(raised);return raised;}
function conquestPerUnit(s,id){const i=TERRITORY_IDS.indexOf(id);if(i<0)throw Error('Unknown conquest unit');return val(TERRITORY_RATES[i]).mul(1+.001*Math.pow(s.blessings.conquerorPath,.2)).mul(val(2).pow(s.upgrades['tier_'+id]||0)).mul(empireConquestFactor(s));}
function conquestRate(s,id){return s.n[id].mul(conquestPerUnit(s,id));}
function conquestSupplyStatus(s,id){return {growing:false,selfSustaining:false,seconds:null};}

function conquestRevealed(s,idx){if(!Number.isInteger(idx)||idx<0||idx>=TERRITORY_IDS.length)return false;if(s.n[TERRITORY_IDS[idx]].cmp(1)>=0)return true;if(idx===0)return raiderAvailable(s);return s.n['total_'+TERRITORY_IDS[idx-1]].cmp(1)>=0||s.n['total_'+TERRITORY_IDS[idx]].cmp(1)>=0;}
function conquestAffordable(s,id){const i=TERRITORY_IDS.indexOf(id);if(i<0)return Z();return min(affordableCount(s.n.graveSeeds,1),affordableCount(s.n.souls,TERRITORY_COST[i]));}
function buyConquest(s,id,amount){const i=TERRITORY_IDS.indexOf(id);if(i<0||!conquestRevealed(s,i))return false;const q=amount==='max'?conquestAffordable(s,id):val(amount).floor();if(q.cmp(1)<0||q.cmp(conquestAffordable(s,id))>0)return false;s.n.souls=s.n.souls.sub(q.mul(TERRITORY_COST[i]));s.n.graveSeeds=s.n.graveSeeds.sub(q);const raised=q.mul(batchSize(s,id));s.n[id]=s.n[id].add(raised);s.n['total_'+id]=s.n['total_'+id].add(raised);return raised;}
function conquestPrices(id,q){const i=TERRITORY_IDS.indexOf(id);return {souls:val(q).mul(TERRITORY_COST[i]),prev:val(q),prevId:'graveSeeds'};}
function raiderAvailable(s){return s.n.total_necromancers.cmp(5)>=0||s.n.total_raiders.cmp(1)>=0;}
function buyRaider(s,quantity){return buyConquest(s,'raiders',quantity);}
// Exact continuous integrated production for a triangular automatic production chain.
// Unlike per-second looping, runtime depends on the tier count, not seconds absent.
function graveSeedRate(s){return val(1+s.upgrades.upgrades).mul(1+.1*s.upgrades.expansions).mul(empireSeedFactor(s));}
function integrateSegment(s,seconds,withEnergy=true){if(!Number.isFinite(seconds)||seconds<0)throw Error('Invalid elapsed time');if(seconds===0)return;const campaignStart=s.empire.campaigns.active?val(s.empire.campaigns.progress[s.empire.campaigns.active]):Z();const dt=val(seconds),before=IDS.map(k=>s.n[k]);const rates=IDS.map(k=>perUnit(s,k));const gain=IDS.map(()=>Z());let exposure=before[0].mul(dt);
 for(let higher=1;higher<IDS.length;higher++){if(!before[higher].m)continue;let term=before[higher];for(let lower=higher-1;lower>=0;lower--){const steps=higher-lower;term=term.mul(rates[lower+1]).mul(dt).div(steps);gain[lower]=gain[lower].add(term);if(lower===0) exposure=exposure.add(term.mul(dt).div(steps+1));}}
 for(let i=0;i<IDS.length;i++){s.n[IDS[i]]=s.n[IDS[i]].add(gain[i]);s.n['total_'+IDS[i]]=s.n['total_'+IDS[i]].add(gain[i]);}
 const souls=exposure.mul(rates[0]);s.empire.insight=val(s.empire.insight).add(exposure.mul(armyExcavationEach(s))).toString();
 s.n.souls=s.n.souls.add(souls);s.n.runSouls=s.n.runSouls.add(souls);s.n.allSouls=s.n.allSouls.add(souls);let territory=exposure.mul(armyConquestEach(s));for(const id of TERRITORY_IDS)territory=territory.add(s.n[id].mul(conquestPerUnit(s,id)).mul(dt));const c=s.empire.campaigns;if(c.active){const remaining=campaignTarget(s,c.active).sub(c.progress[c.active]),diverted=min(territory.mul(c.share/100),remaining);c.progress[c.active]=val(c.progress[c.active]).add(diverted).toString();territory=territory.sub(diverted);}s.n.territory=s.n.territory.add(territory);s.n.totalTerritory=s.n.totalTerritory.add(territory).add(c.active?val(c.progress[c.active]).sub(campaignStart):0);s.n.graveSeeds=s.n.graveSeeds.add(dt.mul(graveSeedRate(s)));
 if(withEnergy)s.energy=Math.min(energyCapacity(s),s.energy+seconds*energyRate(s));}
function campaignTerritoryGain(s,seconds){
 const dt=val(seconds);let exposure=s.n.skeletons.mul(dt);
 for(let higher=1;higher<IDS.length;higher++){if(!s.n[IDS[higher]].m)continue;let term=s.n[IDS[higher]];for(let lower=higher-1;lower>=0;lower--){term=term.mul(perUnit(s,IDS[lower+1])).mul(dt).div(higher-lower);if(lower===0)exposure=exposure.add(term.mul(dt).div(higher+1));}}
 let result=exposure.mul(armyConquestEach(s));for(const id of TERRITORY_IDS)result=result.add(conquestRate(s,id).mul(dt));return result;
}
// The countdown and simulation use the same growing-army Territory integral.
function campaignSecondsRemaining(s,id,limit=Infinity){
 if(!Object.hasOwn(CAMPAIGNS,id)||!(limit>0))return Infinity;
 const target=campaignTarget(s,id).sub(s.empire.campaigns.progress[id]),share=s.empire.campaigns.share/100;
 if(!target.m)return 0;
 const reaches=seconds=>campaignTerritoryGain(s,seconds).mul(share).cmp(target)>=0;
 let high=Number.isFinite(limit)?limit:1,low=0;
 if(Number.isFinite(limit)){if(!reaches(high))return Infinity;}
 else{if(!campaignTerritoryGain(s,1).m)return Infinity;while(!reaches(high)){if(high===Number.MAX_VALUE)return Infinity;high=high>Number.MAX_VALUE/2?Number.MAX_VALUE:high*2;}}
 for(let i=0;i<64;i++){const middle=low+(high-low)/2;if(middle===low||middle===high)break;if(reaches(middle))high=middle;else low=middle;}
 return high;
}
function integrate(s,seconds,withEnergy=true){
 if(!Number.isFinite(seconds)||seconds<0)throw Error('Invalid elapsed time');if(!seconds)return;
 const c=s.empire.campaigns,id=c.active;
 if(!id){integrateSegment(s,seconds,withEnergy);return;}
 const completion=campaignSecondsRemaining(s,id,seconds);
 if(!Number.isFinite(completion)){integrateSegment(s,seconds,withEnergy);return;}
 // Rewards apply only after the exact completion boundary.
 integrateSegment(s,completion,withEnergy);const level=campaignLevel(s,id)+1;c.progress[id]='0';if(!c.completed.includes(id))c.completed.push(id);if(level>1){c.stages??={};c.stages[id]=level;}c.active=null;
 if(seconds>completion)integrateSegment(s,seconds-completion,withEnergy);
}
function advance(s,seconds,withEnergy=true){integrate(s,seconds,withEnergy);}
// Levels 0–35 preserve the previous costs. Beyond that, gentle exponential
// growth avoids the old polynomial pricing bug that allowed Buy Max to consume
// trillions of levels in one purchase at high resource quantities.
function priceAt(s,id,level=s.upgrades[UPGRADES[id].field]){const d=UPGRADES[id];return cleanCost(val(d.base).mul(val(d.growth).pow(level)));}
function seriesCost(base,growth,first,q){let result=Z(),count=Math.min(q,Math.max(0,64-first));for(let i=0;i<count;i++)result=result.add(cleanCost(val(base).mul(val(growth).pow(first+i))));const n=q-count;if(n>0)result=result.add(val(base).mul(val(growth).pow(first+count)).mul(val(growth).pow(n).sub(1)).div(growth-1));return cleanCost(result);}
function bundlePrice(s,id,q){if(q<1||!Number.isSafeInteger(q)||q>Number.MAX_SAFE_INTEGER-s.upgrades[UPGRADES[id].field])throw Error('Invalid bundle');const d=UPGRADES[id];return seriesCost(d.base,d.growth,s.upgrades[d.field],q);}
function upgradeCosts(s,id,count=1){
 const d=UPGRADES[id],costs={[d.currency]:bundlePrice(s,id,count)};
 if(d.secondCurrency)costs[d.secondCurrency]=seriesCost(d.secondBase,d.secondGrowth,s.upgrades[d.field],count);
 return costs;
}
function maxLevelPurchase(s,id){
 if(!UPGRADES[id]||['necro','lich','command'].includes(id))return 0;
 const d=UPGRADES[id],remaining=Number.MAX_SAFE_INTEGER-s.upgrades[d.field];
 if(id.startsWith('twin_')){const unit=id.slice(5),i=IDS.indexOf(unit);if(i>=0&&s.upgrades[d.field]===0&&s.n['total_'+(IDS[i+1]||unit)].cmp(1)<0)return 0;if(TERRITORY_IDS.includes(unit)&&!conquestRevealed(s,TERRITORY_IDS.indexOf(unit)))return 0;}
 const fits=count=>{try{return Object.entries(upgradeCosts(s,id,count)).every(([currency,price])=>canPay(s.n[currency],price));}catch(e){return false;}};
 if(remaining<1||!fits(1))return 0;
 let low=1,high=1;while(high<remaining&&fits(high)){low=high;high=Math.min(remaining,high*2);}
 if(fits(high))return high;
 while(low+1<high){const middle=low+Math.floor((high-low)/2);if(fits(middle))low=middle;else high=middle;}return low;
}
function buyUpgrade(s,id,q){
 if(!UPGRADES[id])return false;const max=maxLevelPurchase(s,id),count=q==='max'?max:Number(q);
 if(!Number.isSafeInteger(count)||count<1||count>max)return false;
 for(const [currency,price] of Object.entries(upgradeCosts(s,id,count)))s.n[currency]=s.n[currency].sub(price);
 s.upgrades[UPGRADES[id].field]+=count;
 // Ordinary purchases never grant Dark Energy; regeneration is time-based.
 return count;
}
// Each repeatable blessing rank costs one Lich Shard.
// Shards are indivisible; normalize decimal residue before accounting.
function wholeShards(value){const x=val(value),n=x.num(),nearest=Math.round(n);return Number.isSafeInteger(nearest)&&Math.abs(n-nearest)<=1e-8?val(nearest):x.floor();}
function blessingPrice(s,id,count){if(!BKEYS.includes(id)||!Number.isSafeInteger(count)||count<1)throw Error('Invalid blessing');return val(count);}
function maxBlessing(s,id){if(!BKEYS.includes(id))return 0;const q=affordableCount(wholeShards(s.shards),1),whole=q.e<15?Math.round(q.num()):Math.floor(q.num());return Math.max(0,Math.min(Number.MAX_SAFE_INTEGER-s.blessings[id],whole));}
function buyBlessing(s,id,q){let max=maxBlessing(s,id),n=q==='max'?max:Number(q);if(!Number.isSafeInteger(n)||n<1||n>max)return false;const price=blessingPrice(s,id,n);s.shards=wholeShards(wholeShards(s.shards).sub(price));s.blessings[id]+=n;s.energy=Math.min(s.energy,energyCapacity(s));return n;}
function ascensionRequirements(s){let p=s.prestiges,soft=Math.max(0,p-80),sc=val(1+soft/8).pow(4);return {souls:val(5e5).mul(val(2.2).pow(Math.min(p,80))).mul(sc),lords:val(1+Math.floor(p/4))};}
function canAscend(s){let r=ascensionRequirements(s);return canPay(s.n.total_deathlords,r.lords)&&canPay(s.n.runSouls,r.souls);}
function depth(s){let found=0;for(let i=0;i<IDS.length;i++)if(s.n['total_'+IDS[i]].cmp(1)>=0)found=i+1;return found;}
function ascensionReward(s){let raw=2+3*Math.max(0,s.n.runSouls.div(5e5).add(1).log10())+Math.max(0,s.n.total_deathlords.add(1).log10()/Math.log10(2))+Math.max(0,depth(s)-4);return val(Math.max(1,Math.floor(raw)));}
function ascend(s){
 if(!canAscend(s))return false;
 const award=ascensionReward(s),at=Date.now(),n=fresh(s.last);
 const entry={number:s.prestiges+1,shards:award.toString(),depth:depth(s),duration:Math.max(0,(at-(s.runStarted||at))/1000),manual:s.runManualPurchases||0,warps:s.runWarpCount||0,at};
 n.lastUpgradeEnergyAt=s.lastUpgradeEnergyAt||0;n.prestiges=s.prestiges+1;n.shards=wholeShards(wholeShards(s.shards).add(award));n.blessings={...s.blessings};n.upgrades.energyCapLevel=s.upgrades.energyCapLevel;n.energy=Math.min(s.energy,energyCapacity(n));n.achievements=[...s.achievements];n.n.allSouls=s.n.allSouls;
 n.startConfig={...s.startConfig};n.migration=s.migration;n.legacy=readLegacy(legacy(s));
 const inheritance=n.startConfig.inheritance!==false||n.prestiges<3,legion=n.startConfig.legion!==false||n.prestiges<3;
 n.n.souls=val(80+(inheritance?250*Math.sqrt(n.blessings.startBlessing):0)+40*Math.sqrt(n.prestiges));
 n.n.skeletons=val(legion?5*n.blessings.stewardBlessing:0);n.n.total_skeletons=n.n.skeletons;
 n.n.necromancers=val(legion?Math.floor(n.blessings.stewardBlessing/10):0);n.n.total_necromancers=n.n.necromancers;
 n.autoConfig={...s.autoConfig,units:[...(s.autoConfig.units||[])],limits:{...(s.autoConfig.limits||{})}};
 n.autoEnabled=false;
 n.autoElapsed=0;n.warpCount=s.warpCount||0;n.warp24Count=s.warp24Count||0;
 n.runHistory=[...(s.runHistory||[]),entry].slice(-60);n.cleanWarpAscensions=(s.cleanWarpAscensions||0)+(entry.warps===0?1:0);n.lightTouchAscensions=(s.lightTouchAscensions||0)+(entry.manual<=10?1:0);n.runStarted=at;
 n.empire.lore=startingLore(n);
 if(hasUnlock(n,'archive'))n.empire.teaching=s.empire.teaching;
 Object.assign(s,n);return award;
}
const WARP={0.25:2000};
function warpDuration(s,hours){if(!Object.hasOwn(WARP,String(hours)))return 0;const chronomancy=Math.max(0,s.upgrades.warpMastery||0);const lore=Math.max(0,s.blessings.warpBlessing||0);const curve=chronomancy<=15?1+.3*chronomancy+.08*chronomancy*chronomancy:23.5+6*Math.log2(1+(chronomancy-15)/10);return hours*3600*curve*logBonus(lore,2,1)*campaignWarpFactor(s);}
function warpProjection(s,hours){const seconds=warpDuration(s,hours),state=copyState(s);advance(state,seconds,false);const gains={};for(const key of ['souls','territory','graveSeeds',...IDS])gains[key]=state.n[key].sub(s.n[key]);gains.insight=val(state.empire.insight).sub(s.empire.insight);return {seconds,state,gains};}
function warp(s,hours){if(!Object.hasOwn(WARP,String(hours))||s.energy<WARP[hours])return false;const projected=warpProjection(s,hours);if(!projected.seconds)return false;s.energy-=WARP[hours];s.n=projected.state.n;s.empire=projected.state.empire;s.warpCount=(s.warpCount||0)+1;s.runWarpCount=(s.runWarpCount||0)+1;if(projected.seconds>=86400)s.warp24Count=(s.warp24Count||0)+1;return true;}
// Automated buyers unlock one tier below their producer. Higher tiers spend
// first, and each cycle shares one reserve budget across all selected buyers.
const AUTO_INTERVAL=300;
function autoBuyerUnlocked(s,id){const i=IDS.indexOf(id);if(i<0||i===IDS.length-1)return false;return s.n['total_'+IDS[i+1]].cmp(1)>=0;}
function autoBuy(s){
 const selected=[...new Set(s.autoConfig?.units||[])].filter(id=>IDS.includes(id)&&autoBuyerUnlocked(s,id)).sort((a,b)=>IDS.indexOf(b)-IDS.indexOf(a));
 const reserve=Math.max(0,Math.min(75,Number(s.autoConfig?.reserve??50)))/100;
 const budget={souls:s.n.souls.mul(1-reserve),graveSeeds:s.n.graveSeeds.mul(1-reserve)};
 for(const id of IDS)budget[id]=s.n[id].mul(1-reserve);
 let purchases=0;
 for(const id of selected){
  const i=IDS.indexOf(id),costs={souls:SOUL_COST[i],graveSeeds:val(SEED_COST[i])};
  if(i>0)costs[IDS[i-1]]=val(PREV_COST[i]);
  let q=affordable(s,id);
  for(const [currency,cost] of Object.entries(costs))q=min(q,affordableCount(currency in budget?budget[currency]:s.n[currency],cost));
  if(q.cmp(1)<0)continue;
  const raised=buy(s,id,q);if(!raised)continue;purchases++;
  for(const [currency,cost] of Object.entries(costs))if(currency in budget)budget[currency]=budget[currency].sub(q.mul(cost));
 }
 return purchases;
}
function advanceWithAutomation(s,seconds,options={}){
 if(!Number.isFinite(seconds)||seconds<0)throw Error('Invalid elapsed time');
 const away=options===true||options?.offline===true;
 const active=autoBuyingActive(s,away);
 if(!active){integrate(s,seconds,true);return {cycles:0,purchases:0};}
 let remaining=seconds,cycles=0,purchases=0;
 while(remaining>1e-9){const until=AUTO_INTERVAL-(s.autoElapsed||0),step=Math.min(remaining,until);integrate(s,step,true);remaining-=step;s.autoElapsed=(s.autoElapsed||0)+step;
  if(s.autoElapsed>=AUTO_INTERVAL-1e-8){s.autoElapsed=0;cycles++;purchases+=autoBuy(s);}
 }
 return {cycles,purchases};
}

function autoBuyingActive(s,offline=false){return !!(s.autoEnabled&&(!offline||s.autoConfig?.offline===true)&&s.autoConfig?.units?.some(id=>IDS.includes(id)));}
// Predict each actual buyer cycle on a private copy. The analytic integral
// remains the completion solver within a cycle; purchases use the live engine.
function campaignCompletionForecast(s,id,options={}){
 if(!Object.hasOwn(CAMPAIGNS,id))return {seconds:Infinity,exact:true,automated:false};
 const offline=options.offline===true,automated=autoBuyingActive(s,offline);
 if(!automated)return {seconds:campaignSecondsRemaining(s,id),exact:true,automated:false};
 const cycles=options.maxCycles??512;if(!Number.isSafeInteger(cycles)||cycles<1||cycles>4096)throw Error('Invalid forecast budget');
 const preview=copyState(s);preview.empire.campaigns.active=id;let elapsed=0;
 for(let i=0;i<cycles;i++){
  const step=AUTO_INTERVAL-preview.autoElapsed;
  // Cross a due cycle using the same live-engine time tolerance.
  if(step<=1e-9){const level=campaignLevel(preview,id);advanceWithAutomation(preview,1e-8,{offline});elapsed+=1e-8;if(campaignLevel(preview,id)>level)return {seconds:elapsed,exact:true,automated:true};continue;}
  const completion=campaignSecondsRemaining(preview,id,step);
  if(Number.isFinite(completion))return {seconds:elapsed+completion,exact:true,automated:true};
  advanceWithAutomation(preview,step,{offline});elapsed+=step;
 }
 // This bounds display work, not gameplay or offline progress. If the target
 // is still unfinished, report a proven lower bound instead of an exact ETA.
 return {seconds:elapsed,exact:false,automated:true};
}

return {autoBuyingActive,campaignCompletionForecast,campaignTerritoryGain,campaignSecondsRemaining,TEACHINGS,CAMPAIGNS,LEGACY_UNLOCKS,legacyRank,legacyOffer,startingLore,hasUnlock,legacy,campaignWon,campaignLevel,campaignTarget,campaignReward,campaignPlotBonus,campaignWarpFactor,campaignInsightFactor,chooseTeaching,teachingUnlocked,teachingSwitchCost,startCampaign,setCampaignShare,pauseCampaign,retainedConquestRate,buyLegacyUnlock,warpProjection,canPay,cleanCost,affordableCount,TIER_MERGES,empireUnitFactor,DOCTRINES,DEVELOPMENTS,empireUnlocked,doctrineUnlocked,harvestShare,sacrificeBonus,armyConquestRate,excavationRate,totalConquestRate,plotCapacity,usedPlots,developmentCost,loreCost,assignArmy,chooseDoctrine,develop,dismantle,studyLore,sacrifice,unlockStatus,SEED_COST,empowermentFactor,researchFactor,logBonus,permanentBonus,batchSize,capacityBonus,upgradeCosts,AUTO_INTERVAL,autoBuyerUnlocked,autoBuy,advanceWithAutomation,N,fmt,IDS,LABELS,LORE,RATES,supplyStatus,TERRITORY_IDS,TERRITORY_LABELS,TERRITORY_LORE,TERRITORY_COST,TERRITORY_PREV,TERRITORY_RATES,conquestPerUnit,conquestRate,conquestSupplyStatus,conquestRevealed,conquestAffordable,buyConquest,conquestPrices,milestoneFactor,SOUL_COST,PREV_COST,UNLOCK,UPGRADES,BKEYS,fresh,copyState,serialize,unpack,energyCapacity,energyRate,rankFactor,perUnit,production,graveSeedRate,unlockRequirement,revealed,visibleIds,affordable,buy,raiderAvailable,buyRaider,advance,priceAt,bundlePrice,maxLevelPurchase,buyUpgrade,blessingPrice,maxBlessing,buyBlessing,ascensionRequirements,canAscend,depth,ascensionReward,ascend,warp,warpDuration,WARP,formattedRate};
});
