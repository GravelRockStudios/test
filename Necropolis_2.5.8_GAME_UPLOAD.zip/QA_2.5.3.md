# 2.5.3 verification

## Balance and save compatibility

The first Archlich consumes 24 rather than 60 Liches. Lich Grave Multiplicity's first rank costs 200K Souls / 125 Territory (formerly 3M / 625); its growth factors remain 8 / 4. Cultivation's base Seed rate is now `1 + 2r + 0.5r²`. At rank 4 that is 17/sec versus 6.6/sec before Empire, expansion and blessing bonuses. Time Warp costs 300 Energy rather than 2,000, with its existing duration curve and exact production preview. Starting Energy 120 and base regeneration 0.1/sec give a first cast after 30 minutes, then a 50-minute unupgraded recharge.

`qa/midgame-core-253.cjs` verifies exact costs, the first-warp affordability boundary, no Energy generation during warps, preservation of saved inventories and paid ranks, and gross spending conservation for active and offline automatic buyers. Enabling the optional receipt ledger produces exactly the same serialized game state as disabling it. Save schema 23 and portable codec V8 remain unchanged. The milestone catalog is unchanged.

`qa/verify.cjs`: all 40 scenarios pass, including monotonic producer repayment horizons, integrated/offline parity, affordability tolerance, all doctrines, ascensions, migrations, and warp projections. Recipe-boundary and warp-cost assertions were updated to use the intentionally changed constants.

## Pacing samples

`qa/balance-253.cjs` compares the actual old/new engines with the same existing strategy: five-minute check-ins, earned resources only, no reset or free resources. Run with `NECRO_BASELINE_HTML=/path/to/2.5.2/index.html node qa/balance-253.cjs`. Results are in `qa/balance-2.5.3.json`.

| Doctrine | First Archlich, no warps: before → after | Earned warps: before → after |
|---|---|---|
| None | 90 → 70 minutes | 90 → 65 minutes |
| Endless Horde | 65 → 60 minutes | 65 → 55 minutes |
| Lich Dominion | 80 → 65 minutes | 80 → 60 minutes |

These are strategy samples, not promised player completion times. The model purchases Cultivation, developments and batch upgrades when affordable under its budget policy; players choosing other investments will differ.

The broader `qa/pacing-249.cjs` sweep, with its output redirected to `qa/pacing-2.5.3.json`, checks through Endbringer. Five-minute earned-warp play changes from 6h15 to 5h20. Hourly/no-warp: 468 → 469 hours; eight-hour/no-warp: 592 → 576; daily/no-warp: 864 → 864; eight-hour automated play: 448 → 400. Later tiers retain their long passive progression. The one-hour variation reflects discrete purchase/campaign choices; this change does not promise faster completion under every policy.

## Browser checks

`qa/midgame-253.cjs` passes at 320, 390, 900 and 1440px in dark/light themes with large text enabled. It checks complete doctrine tradeoff text and range bounds; the Lich goal and paid batch upgrade; repeated identical purchase confirmations; failed purchases preserving the save; spending history staying open over refresh; and an affordable warp. Active and offline automatic purchases of 5,000 Skeletons produce explicit receipts for 50K Souls / 5K Seeds. No browser script errors.

The original doctrine clipping was not reproduced in the local 2.5.2 baseline at 320px. Tradeoffs are now separated and tested for full visibility rather than claiming a confirmed hosted CSS diagnosis. The unexplained one-off Soul loss likewise remains unconfirmed; automatic buyers are one verified spending source, now traceable.

Existing suites also pass:

- `qa/first-steps.cjs`: seven real goals, progressive menus, reload, skip, backup and returning players.
- `qa/intro-progress.cjs`: populated saves and actual portable exports survive replay, all steps, Back, Close, completion and reload in standalone and same-origin sandboxed embeds.
- `qa/disclosure-refresh.cjs`: menus remain open while production changes; summary focus and button contrast remain correct.
- `qa/navigation-252.cjs`: page-local tiers, Milestones-only suggestions, purchases/Undo, shortcuts and responsive layout.
- `qa/save-tabs-250.cjs`: writer ownership, races, stale-writer fencing and recovery.
- `qa/portable-240.cjs`: 36 exact round trips, gzip and invalid-data rejection.

Browser checks use Chromium via `NECRO_CHROMIUM=/usr/bin/chromium`. Actual Microsoft Edge and the deployed itch.io page have not been tested here. The earlier hosted replay reset remains unreproduced; the update does not claim to recover a lost save.
