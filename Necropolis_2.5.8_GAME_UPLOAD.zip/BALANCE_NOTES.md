Current 2.5.3 adjustments: Archlich recipe 24 Liches / 1M Souls / 1,500 Seeds; Lich Multiplicity starts at 200K Souls + 125 Territory; Time Warp costs 300 Energy. See QA_2.5.3.md and qa/balance-2.5.3.json for before/after strategy samples. Existing rank counts and saves are retained.

Current balance: see BALANCE_AUDIT_2.4.9.md for the player-save investigation and before/after pacing.

# 2.4.8 Seed balance update

See QA_2.4.8.md for stronger Soul-funded Cultivation and before/after AFK results. The 2.4.7 prices and Seed reserve protection remain. Earlier notes below are historical.

# 2.4.7 balance update

See BALANCE_AUDIT_2.4.7.md for the current cost changes, Seed reserve protection and before/after pacing results. Earlier notes below are historical.

Current QA patch: see QA_2.4.1.md. Version 2.4.1 fixes restore and reporting behavior without changing the 2.4.0 economy.

Current release: see QA_2.4.0.md for Grave Bloom, complete buyers, automatic campaigns and command support. Historical formulas below document earlier releases.

# Necropolis 2.2.0 — current balance notes

See BALANCE_REVIEW_2.2.0.md for the current campaign/permanent upgrade formulas, progression measurements and compatibility details. PROGRESSION_2.1.0.md records the preceding release.

## Production chain

Each tier produces the tier beneath it. Units and elapsed production have no fixed cap. Soul harvesting also uses the Skeleton harvesting assignment percentage.

| Producer | Output per hour | Supporting units required per batch | Supporting-unit replacement time |
|---|---:|---:|---|
| Skeleton | 3,600 Souls | 0 | — |
| Necromancer | 1,260 Skeletons | 100 | 4.76 minutes |
| Lich | 126 Necromancers | 20 | 9.52 minutes |
| Archlich | 72 Liches | 72 | 1 hour |
| Deathlord | 18 Archliches | 72 | 4 hours |
| Dreadlord | 4 Deathlords | 48 | 12 hours |
| Grave King | 2 Dreadlords | 48 | 1 day |
| Eternal Sovereign | 0.8333 Grave Kings | 60 | 3 days |
| Void Regent | 0.3571 Eternal Sovereigns | 60 | 7 days |
| Endbringer | 0.1786 Void Regents | 60 | 14 days |

These values exclude bonuses and purchased batch improvements. Replacement times cover supporting units only, not Soul or Seed costs. Compared with 2.0.5, two early links gain 40% each; with all other bonuses fixed, the top-origin Soul contribution gains a coefficient of 1.96. Later base rates and recruitment prices are unchanged.

## Bonus rules

- Undead rate = tier rate × (1 + Empowerment bonus + retained research bonus + blessing bonus + Empire bonus).
- Empowerment = 0.20 × sqrt(rank). Retired shared research remains 0.12 × sqrt(saved rank); new ranks cannot be purchased.
- Permanent production bonus = [0.25 / tier number] × log10(1 + allocated blessing ranks), retaining existing allocation rules.
- Multiplicity = 1 + upgrade rank units per purchase, plus 1 while using Endless Horde. Naturally produced units receive no batch bonus.
- Empire bonuses use current doctrine, buildings and selected teaching; inactive teaching specialties never stack.
- Grave Offerings = 0.15 × log10(1 + total buried / 1,000), doubled under Soul Cult. The offering curve and burial percentages are unchanged.
- Grave Seed income = (1 + 2 × cultivation rank + 0.5 × cultivation rank²) × (1 + 0.1 × expansion rank) × (1 + offering bonus) × (1 + Gravefield bonus + selected Grave Studies bonus) × doctrine Seed factor.
- Doctrine Seed factors: Horde 1.25, Dominion 0.8, Cult 0.9, no doctrine 1.
- Dark Energy = (0.1 + 0.05 × Conduit rank) per second, before existing permanent and Empire factors. Level 18 gives 1/sec; level 38 gives 2/sec before bonuses.
- Vessel capacity factor = 1 + 0.1n/(1 + 0.1n), with a first-level gain of about 9.09% and a total factor below 2.
- Time Warp starts at 900 seconds. Through Chronomancy rank 15 its factor is 1 + 0.3r + 0.08r²; afterward it is 23.5 + 6 × log2(1 + (r − 15)/10). Existing Warp Lore applies. Black Spire adds a factor of 1 + 0.1 × log2(1 + Spire victories) to subsequent casts.

## Campaign and prestige limits

Campaigns divert part of incoming Territory rather than charging stored land or adding a separate timer. First targets are 2.5K/10K/50K; each victory opens a target ten times larger. Rewards grow logarithmically. Completion restores full Territory income until the player selects another campaign. Campaign levels, progress and rewards reset on ascension. Existing completions preserve their first rewards during migration.

Three permanent upgrade paths start at 5, 8 and 6 shards; each next offer doubles its cost. Claimed Ground adds plots; later Archive ranks add starting teaching levels; later Blueprint ranks discount development by another 10% of its prior price. Manual building and plan rebuilding use the same costs and plot limits. The two ascension challenges retain their fixed free teaching level or immediate first-plot access.

## What the checks establish

The same elapsed time and settings give equivalent active and offline results, including mid-period campaign completion. Time Warps use that same production model without generating Dark Energy. Results are validated with individual steps, large offline intervals, old and new saves, and real browser interactions.

Controlled strategy comparisons give Horde the purchased-batch advantage, Dominion the stronger natural chain, and Cult the stronger Seed bonus at sufficiently large Grave Offering totals. This does not establish long-term optimality for every combination. Longer player runs are still needed to judge pacing and enjoyment.
