# Necropolis 2.1.0 — progression changes

## Purpose

Make investment, specialization and ascension more meaningful while keeping a text-based idle game. Extend existing pages and resources rather than adding another currency, timer or required daily activity.

## Producers and research

Necromancers produce 1,260 Skeletons/hour instead of 900; Liches produce 126 Necromancers/hour instead of 90. At neutral bonuses they replace the supporting units consumed by one recruitment batch in about 4.76 and 9.52 minutes. These are supporting-unit repayment times, not full Soul/Seed return estimates. Later rates and recipes are unchanged.

Future production purchases use Grave Empowerment. The three overlapping shared research purchases are retired; saved ranks still provide their existing additive production bonus. Multiplicity continues to improve purchased batches rather than natural production.

## Doctrines

| Doctrine | Strength | Tradeoff |
|---|---|---|
| Endless Horde | +1 unit per purchased batch; +25% Seeds; +30% Territory | −15 percentage points of natural undead production bonus |
| Lich Dominion | +50% Necromancer/Lich production; +25% Archlich production and energy regeneration | −20% Seeds |
| Soul Cult | +20% Soul income; double Grave Offering bonus | −10% Seeds |

Horde's purchased-batch bonus also applies to conquest troops. Natural recruitment never receives this batch bonus. Production bonuses remain additive; seed and energy factors follow their existing formulas.

Controlled comparisons show different strengths: Horde gives more purchased units for the same batch cost; Dominion gives the strongest natural chain from the same initial army; Cult exceeds Horde's seed bonus at sufficiently large Grave Offering totals. These are controlled comparisons, not a claim that every strategy is balanced over many ascensions.

## Campaigns

Capture 25 total Territory to choose a target. Commit 25%, 50% or 75% of new Territory income to the target and keep the rest to spend. Total captured includes both portions. Switching or pausing never discards progress. Completing a target stops diversion; choose another manually.

| Target | Territory committed | Reward for the current run |
|---|---:|---|
| Forgotten Cemetery | 250 | Gravefields provide +30% Seeds per plot instead of +20%. |
| Ruined Academy | 1,000 | Unlock Grave Studies. |
| Black Spire | 5,000 | Obelisks provide +30% regeneration per plot instead of +20%; Time Warps last 10% longer. |

Campaigns use the same integrated income calculation online, offline and during Time Warps. Simulation splits at completion so a reward affects only the remaining elapsed time. Time Warp duration is fixed when casting; conquering the Spire during a warp improves the next warp, not the one already in progress.

## Insight and teachings

Select one specialty: Bonebinding (+15% Necromancer/Lich production per level), Warcraft (+15% Territory), Night Studies (+15% energy regeneration), or Grave Studies (+15% Seeds). Grave Studies requires the Academy reward or permanent Eternal Archive.

Existing teaching levels apply to the selected specialty only. Choosing at level zero is free. Later switching costs 10 × (1 + teaching level) Insight; studying retains its existing 10 × 4^level price. Saved old teaching levels remain Bonebinding by default.

## Permanent abilities and challenges

| Unlock | One-time shard cost | Effect |
|---|---:|---|
| Claimed Ground | 5 | +1 development plot after plots unlock. |
| Eternal Archive | 8 | Grave Studies stays unlocked; retain teaching selection after ascension. Teaching levels still reset. |
| Empire Blueprints | 6 | Save assignments, doctrine, teaching and desired buildings; reapply affordable parts with one click. |

Blueprints retain existing buildings. New buildings require current Territory and available plots. Doctrine and teaching switches still pay their normal costs, shown before applying the plan. Blueprints never spend automatically after ascension.

Complete an ascension without Time Warp to start future runs with one free teaching level. Complete one with no more than 10 manual unit purchases to unlock the first three plots immediately in future runs. Each benefit unlocks once and remains fixed. Prior qualifying ascension history is recognized.

Vessel of Night now gives 1 + 0.1n/(1 + 0.1n) capacity factor: about +9.09% at its first rank, always below +100% total. Other repeatable blessing curves are retained.

## Compatibility and verification

State schema 21 imports all previously supported state versions. Existing v5 field dictionaries stay frozen; optional feature fields use literal keys and omit defaults. Full SHA-256 checksums, legacy save-code readers, Undo and paused buyers after ascension remain. Earlier game builds reject the new schema rather than silently discarding progression choices.

Validation covers 40 existing core scenarios, 14 new progression scenarios, desktop/mobile browser flows, legacy and new-feature save round trips, campaign conservation, boundary rewards, finite challenge rewards, and paid/partial blueprint rebuilding. Long-run pacing still benefits from player feedback.
