# Necropolis 2.4.1 — full play QA

This patch follows the player-feedback update and preserves its AFK incremental design. Testing used the actual HTML game, isolated browser storage, and accelerated wall-clock time. No live player save was modified and nothing was published to itch.io.

## Bugs found and fixed

1. **V7 codes failed at the restore screen.** The interface accepted their prefix and checksum but omitted V7 from the compact-format expansion list. Added it, then restored a code produced by the untouched 2.3.1 encoder through the real player controls. The earlier 2.4.0 codec-only tests did not catch this interface defect.
2. **Restoring a backup skipped offline buyers.** Restore used passive production instead of the same offline simulation used when returning to the game. Code and JSON restores now honor the saved master switch, offline preference, selected buyers, reserve, and partial five-minute cycle. Both offline-On and offline-Off restores match a normal 30-minute absence. Astra independently reproduced this defect and the V7 issue.
3. **Return summaries understated production after spending.** A ten-minute fixture produced 600 Seeds but showed zero because buyers had spent more than the starting balance. An optional, temporary production ledger now counts Seeds before buyer spending. Territory uses total captured, including campaign commitments. The report explains these totals; the ledger does not change gameplay or enter the save.

## Fresh-save playthroughs

Both runs began with an empty browser save. Purchases, upgrades, assignments, doctrine, research, development, campaign settings, Time Warp and ascension went through the rendered UI's event handlers. Only the clock was accelerated: no currencies or units were granted and no direct purchase API was called.

| Profile | Check-ins | First ascension available | First Endbringer | Result |
| --- | --- | --- | --- | --- |
| Desktop, 1440px; up to one affordable warp per visit | Every 5 minutes | 65 minutes | 8 hours 5 minutes | All ten undead tiers; all three campaign types; earned ascension and Grave Bloom; reload and next run |
| Mobile, 390px; offline returns; no warps | Every 8 hours | 48 hours | 896 hours / 37 days 8 hours | Same progression and persistence checks |

These are scripted strategy samples, not promised completion times. They deliberately continue the first run to Endbringers before ascending. Earlier ascension or different spending changes the result. The desktop run casts 70 earned warps; the mobile run casts none. Detailed checkpoints are in `qa/full-play-2.4.1.json`.

## AFK and regression coverage

- Seven-day simulations from early and advanced states agree between one offline catch-up and interrupted live simulation with reloads, at 0%, 25%, 50% and 75% reserves. Both campaign repetition and rotation are exercised.
- Thirty days with offline buying disabled preserves upgrade levels and the buyer timer while passive production and campaign continuation proceed.
- Pausing/resuming buyers preserves the cycle phase. Warps preserve buyer timing and do not generate Dark Energy. Ascension preserves paid permanent power, Energy storage, and eligible preferences, pauses buyers, and clears locked choices.
- All 35 upgrade switches and all 15 recruit switches, their cycle purchases, reload persistence, and save-code round-trips are checked at mobile and desktop widths.
- The historic broad browser suite now completes all 32 scenarios. It covers confirmations, reset/cancel, multi-tab save conflicts, custom batches, Undo, previews, fractional affordability, milestones, all ten tier layouts, offerings, permanent upgrades, campaign replays, and legacy save imports.
- Additional browser suites cover mouse, keyboard and touch navigation, light-mode readability, exact warp previews, campaign forecasts after purchases/Undo, stale-state isolation, feature wording and automatic continuation.
- Corrupt saves recover from a valid slot while retaining the damaged original. With no recovery, storage stays protected until a confirmed import. Unavailable browser storage still permits play and save-code export/manual selection.
- Return reports are checked against independently accumulated pre-spending production with both fixed income and changing upgrades/campaign rewards. Tracking the report leaves gameplay state identical to a simulation without tracking.
- Core tests cover purchase boundaries, production, ascension, save precision, malformed inputs, frozen legacy dictionaries and original 2.3.1 V7 imports.

**All 22 suites passed on the final 2.4.1 build** (13 core/simulation suites and 9 browser suites), with no uncaught page errors in the passing browser scenarios. The final suite results and logs are in `qa/results-2.4.1/`. Run `node qa/run-241.cjs core` and `node qa/run-241.cjs browser` from the extracted release. Browser tests require Playwright and a Chromium executable; set `NECRO_CHROMIUM` if needed. Original-encoder checks can use `NECRO_ORIGINAL_HTML` pointing to the untouched 2.3.1 HTML.

Historic test assertions were updated for the current displayed version, V8 export prefix, revised buyer-cost wording and clearing locked selections after ascension. The synthetic V5 fixture now uses a schema supported by that frozen format. These were test maintenance changes, not changes to purchase, reserve or save-validation behavior.

## Scope and preserved behavior

This patch changes no prices, production coefficients, Seed blessing curve, ascension requirements, rewards, campaign scaling or offline limits. Grave Seeds remain a spending constraint. All original PNG/SVG artwork, the embedded header image, credits and license are preserved. Save schema remains 23 and exports remain NECRO-SAVE-8.

Browser testing used headless Chromium 153 in sandboxed iframes at 390px and 1440px, with additional touch and keyboard interactions. This is automated browser play and simulation, not weeks of unattended real-time observation. Live itch.io hosting, native iPhone Safari, and browsers other than Chromium were not tested.

Upload `Necropolis_2.4.1_upload.zip` as the itch.io HTML game; `index.html` is at its root. Prior release notes and QA reports remain as history.
