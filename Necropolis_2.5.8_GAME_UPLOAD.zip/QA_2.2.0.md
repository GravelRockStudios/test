# Necropolis 2.2.0 — verification

- 40 existing engine scenarios passed, including equal elapsed active/offline production, buyer behavior, compact costs, Energy, Undo-related state and prestige accounting.
- 14 progression scenarios passed for doctrines, teachings, paid blueprints, campaign boundary splitting and retained benefits.
- 9 new scenarios passed for refreshed permanent paths, exact escalating prices, repeated campaigns, diminishing rewards, schema 21 migration, new milestones, save rejection and the analytic ten-tier income formula.
- 32 real-browser scenarios passed, including the new flows at 390px and 1440px. New cards replace purchased offers, costs and state persist, the Energy header uses whole suffix values, the bar switches between charging and ready, repeated campaign previews match execution, and the Empire milestone filter works.
- Save-code fixtures preserve rank/stage fields, blueprints, achievements, campaign allocation, fractional resources and history exactly. Supported v1–v5 codes still import, including a v5 browser restore with its full base64 SHA-256 checksum. Future schemas, corrupted checksums and malformed progression fields reject before replacing the current save.
- Representative NECRO-SAVE-6 lengths: fresh about 127 characters (v5: 152), advanced about 1,469 (v5: 1,844), all new-feature fixture about 264 (v5: 484). Exact length varies slightly with timestamps. Frozen older dictionaries and the full SHA-256 checksum remain unchanged. New encoding stores rank/stage ownership once, packs new milestones into trimmed bits, groups full history by field and uses lossless timestamp differences with absolute fallbacks.
- Template checks cover script syntax, document boundaries, tier grammar, costs and energy suffix rounding/carryover.
- A fixture containing every historical/current milestone plus an unknown future ID also round-trips; its code drops from about 843 to 288 characters. Unusual fractional old timestamps retain exact values through absolute fallbacks.
- Reviewed the new Energy and permanent-card layouts and campaign displays. No horizontal document overflow at either tested width.
- The selected All rights reserved notice is included in LICENSE.txt and Credits. Two focused browser checks verify that Credits starts collapsed, the license downloads correctly from the sandboxed game at 390px and 1440px, and the layout does not overflow. Apoped's attribution, contact email and Evan Rosson's thanks are preserved.
- The progression model reaches the final tier in all eight tested strategies. See BALANCE_REVIEW_2.2.0.md for assumptions, comparison results and the remaining light-interaction prestige concern.

All 23 original PNG/SVG artwork files match the 2.1.0 upload byte for byte. The ZIP has index.html at its root and passes archive integrity checks. No live itch.io deployment was performed.
