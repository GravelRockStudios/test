# Necropolis 2.4.4 — Clearer automatic buying

Automatic upgrade switches now use a dedicated row with at least 20 pixels between the label and button. This fixes a generic upgrade-card style that previously placed the label and toggle directly beside one another.

Undead and Conquest automation have a short guide explaining Recruit, Empower and Multiply, including the upgrade names. A brief note explains that enabled buyers run every five minutes while the master is running and respect the shared reserve. Each resource buyer identifies its manual upgrade location and effect; Chronomancy points to Dark Energy and longer Time Warps. No additional navigation or controls were introduced.

Verification completed:

- Existing template and Automation browser suites passed.
- Automation navigation and interactions passed at 320, 390, 900 and 1440 pixels in dark and light themes, including all 50 switches, settings persistence, a buyer cycle, V8 restore and ascension locks.
- Additional browser inspection checked upgrade-card spacing on Undead, Territory and Dark Energy at 320, 390 and 1440 pixels in both themes. Every label/button gap was at least 20 pixels and toggle height at least 40 pixels.
- All five resource explanations and their accessible descriptions were present. The three buyer definitions appeared on both troop pages. Images loaded, no page errors occurred, and no horizontal overflow appeared.
- Phone and desktop screenshots were inspected. Selected images are in `qa/screenshots-2.4.4/`.
- The production and milestone scripts, original artwork, embedded logo and license are unchanged from 2.4.3. Save schema and buying behavior are unchanged.

Testing used headless Chromium. Native iPhone Safari and live itch.io were not tested. This package has not been published.
