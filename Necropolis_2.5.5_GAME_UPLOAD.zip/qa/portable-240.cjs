const fs=require('fs'),path=require('path'),assert=require('assert'),vm=require('vm'),zlib=require('zlib'),C=require('./extract-core.cjs');
const html=fs.readFileSync(path.join(__dirname,'../index.html'),'utf8'),originalHtml=process.env.NECRO_ORIGINAL_HTML?fs.readFileSync(process.env.NECRO_ORIGINAL_HTML,'utf8'):null;
function context(source,core){const ctx={C:core,console,TextEncoder,TextDecoder,Uint8Array,Blob,Response,CompressionStream,DecompressionStream,structuredClone,crypto:require('crypto').webcrypto,btoa,atob};vm.createContext(ctx);vm.runInContext(source.slice(source.indexOf('// Portable v5'),source.indexOf('// Short instructions that rotate')),ctx);return ctx;}
const ctx=context(html,C),canonical=s=>JSON.parse(C.serialize(s));let groups=0;
(async()=>{
 for(const mode of ['off','repeat','rotate'])for(const focus of Object.keys(C.CAMPAIGNS))for(const active of [null,'cemetery','academy','spire']){
  const s=C.fresh();for(const id of [...C.IDS,...C.TERRITORY_IDS]){s.n[id]=C.N.of(100);s.n['total_'+id]=C.N.of(100);}s.blessings.seedBlessing=16;s.autoConfig.units=[...C.IDS,...C.TERRITORY_IDS];s.autoConfig.upgrades=[...C.AUTO_UPGRADES];s.autoConfig.offline=true;s.autoEnabled=true;s.empire.campaigns.auto=mode;s.empire.campaigns.focus=focus;s.empire.campaigns.active=active;s.empire.campaigns.progress.academy='1.23e2';s.empire.campaigns.completed=['spire'];s.empire.campaigns.stages={spire:7};
  const raw=ctx.packPortable(s);assert.equal(JSON.parse(raw)[0],8);assert.deepEqual(canonical(C.unpack(ctx.unpackPortable(raw))),canonical(s));assert.equal(await ctx.decompressSave(await ctx.compressSave(raw)),raw);groups++;
 }
 console.log('PASS 36 V8 exact round-trips across campaign modes/focus/active, all35 upgrade selections/all15 units, Grave Bloom and gzip');
 const s=C.fresh(),raw=JSON.parse(ctx.packPortable(s));for(const [index,value]of [[4,3],[5,-1],[5,3],[4,.5]]){const bad=structuredClone(raw),keys=vm.runInContext('V6_KEYS',ctx),e=String(keys.indexOf('empire')),c=String(keys.indexOf('campaigns'));bad[1][e]??={};bad[1][e][c]=[0,50,[],[],0,0];bad[1][e][c][index]=value;assert.throws(()=>ctx.unpackPortable(JSON.stringify(bad)));}
 for(const level of [-1,.1,'16']){const bad=structuredClone(raw),keys=vm.runInContext('V6_KEYS',ctx),b=String(keys.indexOf('blessings'));bad[1][b]??={};bad[1][b][vm.runInContext('V8_SEED_KEY',ctx)]=level;assert.throws(()=>ctx.unpackPortable(JSON.stringify(bad)));}
 console.log('PASS damaged V8 campaign metadata and invalid Seed blessing levels reject');
 if(originalHtml){const m={exports:{}};new Function('module','exports',originalHtml.match(/<script[^>]*>([\s\S]*?)<\/script>/)[1])(m,m.exports);const old=m.exports,legacy=context(originalHtml,old);
  for(const make of [s=>s,s=>{s.n.souls=old.N.of('1.2345e200');s.n.graveSeeds=old.N.of(5432.125);s.n.total_necromancers=old.N.of(1);s.autoEnabled=true;s.autoConfig.units=['skeletons'];s.empire.campaigns.active='academy';s.empire.campaigns.progress.academy='1234';return s;}]){const previous=make(old.fresh()),text=legacy.packPortable(previous),bytes=await legacy.compressSave(text);assert.equal(JSON.parse(text)[0],7);assert.equal(await ctx.decompressSave(bytes),text);assert.deepEqual(canonical(C.unpack(ctx.unpackPortable(text))),canonical(C.unpack(old.serialize(previous))));}
  console.log('PASS actual untouched 2.3.1 V7 binary codes import with exact old progress and new buyers Off');
 }
 console.log('PASS portable save extension checks');
})().catch(e=>{console.error(e);process.exitCode=1;});
