// Astra's review regressions. Runs against release HTML, or NECRO_REVIEW_CORE.
const assert=require('assert'),C=require(process.env.NECRO_REVIEW_CORE||'./extract-core.cjs'),N=C.N;
let checks=0;
function test(name,fn){fn();checks++;console.log('PASS '+name);}
function near(a,b,tol=1e-8){a=N.of(a);b=N.of(b);if(!a.m&&!b.m)return;assert(b.m&&Math.abs(a.div(b).num()-1)<tol,`${a} != ${b}`);}
function put(s,id,n){s.n[id]=N.of(n);if('total_'+id in s.n)s.n['total_'+id]=N.of(n);}
function funded(){const s=C.fresh();for(const id of ['souls','territory','graveSeeds',...C.IDS,...C.TERRITORY_IDS])put(s,id,'1e80');s.n.totalTerritory=N.of('1e80');return s;}
function army(){const s=C.fresh();for(const [id,n]of [['skeletons',1e5],['necromancers',50],['liches',8],['deathlords',2],['raiders',100],['bonelegions',75],['dreadmarshals',50],['deathhosts',25],['warcouncils',10]])put(s,id,n);s.empire.conquest=20;s.empire.excavation=10;s.empire.doctrine='horde';s.empire.buildings={gravefields:4,crypts:3,obelisks:2};s.empire.lore=5;s.empire.teaching='seeds';s.n.totalTerritory=N.of(25);return s;}
function compare(a,b){for(const k of Object.keys(a.n))near(a.n[k],b.n[k]);near(a.empire.insight,b.empire.insight);near(a.energy,b.energy);for(const id of Object.keys(C.CAMPAIGNS)){assert.equal(C.campaignLevel(a,id),C.campaignLevel(b,id));near(a.empire.campaigns.progress[id],b.empire.campaigns.progress[id]);}assert.equal(a.empire.campaigns.active,b.empire.campaigns.active);}
test('Grave Bloom is a permanent, uncapped seed-only bonus with exact integration',()=>{
 const s=army(),base=C.graveSeedRate(s),souls=C.perUnit(s,'skeletons');s.shards=N.of(100);assert.equal(C.buyBlessing(s,'seedBlessing',16),16);near(C.graveSeedRate(s),base.mul(5));near(C.perUnit(s,'skeletons'),souls);const before=s.n.graveSeeds;C.advance(s,120);near(s.n.graveSeeds.sub(before),base.mul(600));put(s,'deathlords',10);s.n.runSouls=N.of('1e12');assert(C.ascend(s));assert.equal(s.blessings.seedBlessing,16);near(C.graveSeedRate(s),5);assert.equal(C.unpack(C.serialize(s)).blessings.seedBlessing,16);
});
test('All 35 supported upgrades buy independently, including every undead and troop tier',()=>{
 assert.equal(C.AUTO_UPGRADES.length,35);for(const id of C.AUTO_UPGRADES){const s=funded();s.autoConfig.upgrades=[id];assert(C.autoUpgradeUnlocked(s,id),id);const field=C.UPGRADES[id].field;assert.equal(C.autoBuy(s),1,id);assert(s.upgrades[field]>0,id);}
});
test('Every unlocked unit, including Endbringers and all Conquest tiers, can automate',()=>{
 for(const id of [...C.IDS,...C.TERRITORY_IDS]){const s=funded();s.autoConfig.units=[id];put(s,id,1);assert(C.autoBuyerUnlocked(s,id),id);const before=s.n[id];assert.equal(C.autoBuy(s),1,id);assert(s.n[id].cmp(before)>0,id);}
});
test('All selected buyers share one reserve across Souls, Territory, Seeds and prerequisites',()=>{
 for(const reserve of [25,50,75]){const s=funded(),before=C.copyState(s);s.autoConfig.units=[...C.IDS,...C.TERRITORY_IDS];s.autoConfig.upgrades=[...C.AUTO_UPGRADES];s.autoConfig.reserve=reserve;assert(C.autoBuy(s)>0);for(const id of ['souls','territory','graveSeeds',...C.IDS,...C.TERRITORY_IDS])assert(C.canPay(s.n[id],before.n[id].mul(reserve/100)),`${reserve}% ${id}`);}
});
test('Selected high-tier batches accumulate Seeds instead of starving behind cheap buyers',()=>{
 for(const reserve of [0,50,75]){const s=C.fresh();put(s,'skeletons',10000);put(s,'necromancers',100);put(s,'liches',1);s.n.souls=N.of('1e20');s.n.graveSeeds=N.of(0);s.autoConfig.units=['skeletons','necromancers'];s.autoConfig.reserve=reserve;for(let i=0;i<1601;i++){s.n.graveSeeds=s.n.graveSeeds.add(1);C.autoBuy(s);}assert(s.n.graveSeeds.cmp(1500)>=0);assert(s.n.total_necromancers.cmp(100)>0,`reserve ${reserve}`);}
});
test('Selected troop buyers likewise save for their next batch',()=>{
 const s=C.fresh();put(s,'raiders',1);put(s,'warcouncils',1);s.n.souls=N.of('1e30');s.n.graveSeeds=C.nextTierSeedReserve(s);s.autoConfig.units=['raiders','warcouncils'];s.autoConfig.reserve=0;for(let i=0;i<100;i++){s.n.graveSeeds=s.n.graveSeeds.add(100);C.autoBuy(s);}assert.equal(s.n.total_warcouncils.num(),2);assert.equal(s.n.total_raiders.num(),1);
});
test('Upgrade automation protects the highest selected batch without blocking Seed research',()=>{
 const s=C.fresh();put(s,'skeletons',10000);put(s,'necromancers',100);put(s,'liches',1);s.n.souls=N.of(1110);s.n.graveSeeds=N.of(1525);s.autoConfig.reserve=0;s.autoConfig.units=['necromancers'];s.autoConfig.upgrades=['harvest'];assert.equal(C.autoBuy(s),2);assert.equal(s.upgrades.upgrades,1);assert.equal(s.n.total_necromancers.num(),101);near(s.n.souls,0);
});
test('New and locked buyers stay Off through load, passive unlock, and ascension',()=>{
 const fresh=C.fresh();assert.deepEqual(fresh.autoConfig.upgrades,[]);assert.deepEqual(fresh.autoConfig.units,[]);fresh.autoEnabled=true;fresh.autoConfig.offline=true;fresh.autoConfig.upgrades=['tier_skeletons','twin_skeletons'];fresh.autoConfig.units=['skeletons'];put(fresh,'liches',1);C.advanceWithAutomation(fresh,600,{offline:true});assert.deepEqual(fresh.autoConfig.upgrades,[]);assert.deepEqual(fresh.autoConfig.units,[]);const s=funded();s.autoConfig.upgrades=[...C.AUTO_UPGRADES];s.autoConfig.units=[...C.IDS];s.autoEnabled=true;s.n.runSouls=N.of('1e80');assert(C.ascend(s));assert(!s.autoEnabled);assert.deepEqual(s.autoConfig.units,[]);assert.deepEqual(s.autoConfig.upgrades,['expand','energyCap','energyFlow','warpMastery']);
});
test('Command support keeps all five troop types relevant to growing late-game armies',()=>{
 const s=C.fresh();s.empire.conquest=100;put(s,'skeletons','1e30');for(let i=0;i<C.TERRITORY_IDS.length;i++){const id=C.TERRITORY_IDS[i];put(s,id,C.CONQUEST_COMMAND_SCALE[i]);near(C.conquestRate(s,id).div(C.armyConquestRate(s)),C.CONQUEST_COMMAND_SHARE[i]/2);const per=C.conquestPerUnit(s,id);near(per.mul(s.n[id]),C.conquestRate(s,id));const before=C.conquestRate(s,id);s.upgrades['tier_'+id]=1;assert(C.conquestRate(s,id).cmp(before)>0);assert(C.buyUpgrade(Object.assign(funded(),{autoConfig:s.autoConfig}),'tier_'+id,1));}near(C.armyConquestRate(s),N.of('1e30').mul(.0007));
});
test('Conquest Empowerment spends resources while preserving owned troops',()=>{
 for(const id of C.TERRITORY_IDS){const s=funded(),before=s.n[id];assert(C.buyUpgrade(s,'tier_'+id,1));near(s.n[id],before);assert.deepEqual(Object.keys(C.upgradeCosts(s,'tier_'+id)).sort(),['souls','territory']);}
});
test('Repeat and rotating campaigns give chunk-independent rewards and resource integrals',()=>{
 for(const mode of ['repeat','rotate'])for(const share of [25,50,75]){const s=army();C.setCampaignShare(s,share);C.setCampaignAuto(s,mode);const bulk=C.copyState(s),fine=C.copyState(s);C.advance(bulk,36000);for(let i=0;i<360;i++)C.advance(fine,100);compare(bulk,fine);assert(C.campaignLevel(bulk,'cemetery')>1);if(mode==='rotate')for(const id of Object.keys(C.CAMPAIGNS))assert(C.campaignLevel(bulk,id)>1);}
});
test('Automatic campaigns start exactly at the Territory unlock and can be fully paused',()=>{
 const s=C.fresh();s.empire.conquest=100;put(s,'skeletons',1000);C.setCampaignAuto(s,'rotate');const bulk=C.copyState(s),fine=C.copyState(s);C.advance(bulk,100);for(let i=0;i<100;i++)C.advance(fine,1);compare(bulk,fine);near(bulk.empire.campaigns.progress.cemetery,(70-25)*.5);assert(C.pauseCampaign(bulk));const before=bulk.empire.campaigns.progress.cemetery;C.advance(bulk,10000);assert.equal(bulk.empire.campaigns.progress.cemetery,before);assert.equal(bulk.empire.campaigns.auto,'off');
});
test('Campaign solving resolves tiny late-game and zero-Skeleton growing-army boundaries',()=>{
 const s=C.fresh();put(s,'skeletons','1e100');s.empire.conquest=100;s.n.totalTerritory=N.of(25);const expected=N.of(5000).div(C.totalConquestRate(s)).num();near(C.campaignSecondsRemaining(s,'cemetery',86400),expected);const growing=C.fresh();put(growing,'endbringers','1e200');growing.empire.conquest=100;const time=C.campaignSecondsRemaining(growing,'cemetery',86400);assert(time<1e-10&&time>0);near(C.campaignTerritoryGain(growing,time),5000);const bulk=C.copyState(s),fine=C.copyState(s);C.setCampaignAuto(bulk,'rotate');C.setCampaignAuto(fine,'rotate');C.advance(bulk,100);for(let i=0;i<100;i++)C.advance(fine,1);compare(bulk,fine);
});
test('Automation, forecasts, save round-trips and Warp previews keep live state isolated',()=>{
 const s=army();s.n.souls=N.of('1e12');s.n.graveSeeds=N.of('1e8');s.n.territory=N.of('1e8');s.autoEnabled=true;s.autoConfig.units=['necromancers'];s.autoConfig.upgrades=['harvest','expand','tier_raiders'];s.autoConfig.offline=true;C.setCampaignAuto(s,'rotate');const before=C.serialize(s),forecast=C.campaignCompletionForecast(s,'cemetery'),projection=C.warpProjection(s,.25);assert(forecast.exact);assert.equal(C.serialize(s),before);const live=C.copyState(s);C.advanceWithAutomation(live,forecast.seconds+1e-5);assert(C.campaignLevel(live,'cemetery')>=1);const restored=C.unpack(before);assert.deepEqual(restored.autoConfig.upgrades,s.autoConfig.upgrades);assert.equal(restored.empire.campaigns.auto,'rotate');s.energy=2000;assert(C.warp(s,.25));projection.state.energy=0;compare(s,projection.state);const bulk=C.copyState(restored),fine=C.copyState(restored);C.advanceWithAutomation(bulk,3600,{offline:true});for(let i=0;i<36;i++)C.advanceWithAutomation(fine,100,{offline:true});compare(bulk,fine);
});
test('Campaign automation exhausts the save-safe stage range without creating invalid saves',()=>{
 const s=C.fresh();s.n.totalTerritory=N.of(25);put(s,'skeletons','1e1040');s.empire.conquest=100;const c=s.empire.campaigns;c.completed=Object.keys(C.CAMPAIGNS);c.stages={cemetery:1023,academy:1023,spire:1023};C.setCampaignAuto(s,'rotate');C.advance(s,1);for(const id of Object.keys(C.CAMPAIGNS))assert.equal(C.campaignLevel(s,id),1024);assert.equal(c.active,null);C.unpack(C.serialize(s));c.active='cemetery';C.advance(s,1);assert.equal(C.campaignLevel(s,'cemetery'),1024);assert.equal(c.active,null);
});
console.log(checks+' Astra review regression groups passed');
console.log('Seed multipliers at 1/4/16/100 shards:',[1,4,16,100].map(level=>{const s=C.fresh();s.blessings.seedBlessing=level;return C.seedBlessingFactor(s);}));
