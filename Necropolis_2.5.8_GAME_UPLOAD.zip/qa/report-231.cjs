// Regressions for the October 4 final QA report. No real player save is changed.
const assert=require('assert'),C=require('./extract-core.cjs'),N=C.N;
let checks=0;
function test(name,fn){fn();checks++;console.log('PASS '+name);}
function near(a,b){a=N.of(a);b=N.of(b);if(!a.m&&!b.m)return;assert(Math.abs(a.div(b).num()-1)<1e-8,`${a} != ${b}`);}
function funded(){const s=C.fresh();s.n.souls=N.of('1e100');s.n.graveSeeds=N.of('1e100');s.n.territory=N.of('1e100');s.n.totalTerritory=N.of('1e100');return s;}
test('B1: every manual buyer unlock stays Off through a real buyer cycle',()=>{
 for(let i=0;i<C.IDS.length-1;i++){
  const s=funded(),id=C.IDS[i],producer=C.IDS[i+1];
  s.n[id]=N.of(C.PREV_COST[i+1]*2);s.n['total_'+id]=s.n[id];s.autoEnabled=true;
  assert(!C.autoBuyerUnlocked(s,id));assert(C.buy(s,producer,1));assert(C.autoBuyerUnlocked(s,id));
  assert(!s.autoConfig.units.includes(id));assert.equal(C.advanceWithAutomation(s,300).purchases,0);
  if(i>0){s.n[C.IDS[i-1]]=N.of('1e30');s.n['total_'+C.IDS[i-1]]=s.n[C.IDS[i-1]];}
  s.autoConfig.units=[id];const restored=C.unpack(C.serialize(s));assert.deepEqual(restored.autoConfig.units,[id]);
  assert(C.advanceWithAutomation(restored,300).purchases>0,'Explicit On must still buy '+id);
 }
});
test('B1: old hidden selections are cleared without changing enabled unlocked buyers',()=>{
 const s=funded();s.n.necromancers=N.of(1);s.n.total_necromancers=N.of(1);
 s.autoConfig.units=['skeletons','sovereigns'];s.autoEnabled=true;s.autoConfig.offline=true;
 const loaded=C.unpack(C.serialize(s));assert.deepEqual(loaded.autoConfig.units,['skeletons']);
 assert(loaded.autoEnabled&&loaded.autoConfig.offline);assert.deepEqual(s.autoConfig.units,['skeletons','sovereigns']);
});
test('B1: dormant preferences cannot turn on during passive active/offline unlocks',()=>{
 for(const offline of [false,true])for(let i=0;i<C.IDS.length-2;i++){
  const s=funded(),id=C.IDS[i];s.n[C.IDS[i+2]]=N.of('1e6');s.n['total_'+C.IDS[i+2]]=s.n[C.IDS[i+2]];
  s.autoConfig.units=[id];s.autoConfig.offline=true;s.autoEnabled=true;
  assert(!C.autoBuyerUnlocked(s,id));const plain=C.copyState(s);C.advance(plain,600);
  const result=C.advanceWithAutomation(s,600,{offline});assert(C.autoBuyerUnlocked(s,id));
  assert.deepEqual(s.autoConfig.units,[]);assert.equal(result.purchases,0);
  for(const key of Object.keys(s.n))near(s.n[key],plain.n[key]);
 }
});
test('B1: ascension drops locked selections but preserves a buyer unlocked by starting units',()=>{
 for(const rank of [0,10]){
  const s=funded();s.n.total_deathlords=N.of(10);s.n.runSouls=N.of('1e12');s.blessings.stewardBlessing=rank;
  s.autoConfig.units=['skeletons','sovereigns'];s.autoConfig.offline=true;
  assert(C.ascend(s));assert.deepEqual(s.autoConfig.units,rank?['skeletons']:[]);assert(!s.autoEnabled);
  assert(s.autoConfig.offline);assert(!C.autoBuyerUnlocked(s,'sovereigns'));
 }
});
test('B2: core zero quantities are explicit zeros',()=>{for(const value of [0,'0',N.of(0)])assert.equal(C.fmt(value),'0');});
test('B4: Deathlord per-unit production is independent of count, total scales exactly',()=>{
 for(const doctrine of ['none','horde','lich','cult'])for(const empowerment of [0,1,8]){
  const s=C.fresh();s.empire.doctrine=doctrine;s.upgrades.tier_sovereigns=empowerment;s.blessings.summonBlessing=102;s.blessings.harvestBlessing=58;
  s.n.sovereigns=N.of(1);const each=C.perUnit(s,'sovereigns'),one=C.production(s,'sovereigns');s.n.sovereigns=N.of(47);
  near(C.perUnit(s,'sovereigns'),each);near(C.production(s,'sovereigns'),one.mul(47));
 }
});
test('P5: Archlich Empowerment improves Lich output; Hunger is not a Seed bonus',()=>{
 const s=C.fresh(),lich=C.perUnit(s,'deathlords');s.upgrades.tier_deathlords=1;
 assert(C.perUnit(s,'deathlords').cmp(lich)>0);assert(C.UPGRADES.tier_deathlords.about.includes('Liches'));
 const seed=C.graveSeedRate(s),souls=C.perUnit(s,'skeletons');s.blessings.harvestBlessing=58;near(C.graveSeedRate(s),seed);assert(C.perUnit(s,'skeletons').cmp(souls)>0);
});
console.log(checks+' report regression groups passed');
