# 2.5.6 verification

Every unlocked Undead upgrades page has a compact Recruitment button, returning to the same selected tier's recruitment page. The reciprocal View upgrades button is compact and neutral unless a displayed tier upgrade is affordable. Its brass state includes Grave Empowerment, unlocked Grave Multiplicity and Skeleton Grave Seed Cultivation. Buttons have borders, hover feedback and keyboard focus styling. The first-run upgrade gate remains active.

`qa/navigation-252.cjs` passes at 320/390/900/1440px in dark/light themes. Its all-ten-tier check now uses the reciprocal shortcut to return from upgrades. Added checks verify button height below 40px, neutral Recruitment, brass View upgrades while affordable, a real maximum upgrade purchase turning it neutral, and Undo restoring its brass state. Existing production, cost-bar, navigation, purchase and overflow checks also pass.

`qa/first-steps.cjs` passes at 320/390/1440px in both themes, including progressive menus, real purchases, replay, skip and creating a backup.

The engine and milestone scripts are byte-identical to v2.5.5. No game balance, saved progress or codec changes. Tests use Chromium via `NECRO_CHROMIUM=/usr/bin/chromium`.
