const assert=require('assert/strict'),C=require('./extract-core.cjs'),N=C.N;
function near(a,b){a=N.of(a);b=N.of(b);if(a.cmp(0)===0&&b.cmp(0)===0)return;assert(Math.abs(a.div(b).num()-1)<1e-9,`${a} != ${b}`);}
let cases=0;
for(const doctrine of ['none','horde','lich','cult'])for(const scale of ['1','1e20','1e1000']){
 const s=C.fresh();for(const [i,id] of C.IDS.entries()){s.n[id]=N.of(scale).mul(i+1);s.n['total_'+id]=s.n[id];s.upgrades['tier_'+id]=i*2;}for(const [i,id] of C.TERRITORY_IDS.entries()){s.n[id]=N.of(scale).mul(i+1);s.n['total_'+id]=s.n[id];s.upgrades['tier_'+id]=i;}
 s.empire.doctrine=doctrine;s.empire.conquest=20;s.empire.excavation=10;s.empire.buildings={gravefields:2,crypts:3,obelisks:1};s.upgrades.upgrades=4;s.upgrades.expansions=3;s.blessings.seedBlessing=2;s.blessings.summonBlessing=5;
 const raw=C.serialize(s),curve=C.productionForecast(s);
 for(const seconds of [0,.125,1,900,86400,1e11]){const actual=C.copyState(s);C.advance(actual,seconds,false);for(const key of ['souls','graveSeeds','territory',...C.IDS])near(curve.at(key,seconds),actual.n[key]);cases++;}
 assert.equal(C.serialize(s),raw,'forecasts cannot alter the live game');
 const before=curve.at('souls',900);s.n.souls=N.of('1e2000');s.n.skeletons=N.of('1e2000');s.empire.doctrine='none';near(curve.at('souls',900),before);assert.throws(()=>curve.at('souls',Infinity));assert.throws(()=>curve.at('souls',-1));
}
// Spending commitments are snapshot assumptions; do not award future victories.
for(const mode of ['off','repeat','rotate']){
 const s=C.fresh();s.n.totalTerritory=N.of(25);s.n.raiders=N.of(10);s.n.total_raiders=N.of(10);s.n.territory=N.of(5);C.setCampaignAuto(s,mode);if(mode==='off')C.startCampaign(s,'cemetery');const before=C.serialize(s),curve=C.productionForecast(s);
 for(const seconds of [10,100000]){const gross=C.totalConquestRate(s).mul(seconds),spent=mode==='off'?(gross.mul(.5).cmp(2500)<0?gross.mul(.5):N.of(2500)):gross.mul(.5);near(curve.at('territory',seconds),gross.sub(spent).add(5));}assert.equal(C.serialize(s),before);
}
console.log(`PASS ${cases} exact current-bonus production samples, quantities through 1e1000, immutable snapshots, campaign commitments and invalid-time rejection`);
