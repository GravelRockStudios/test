# 2.5.0 release verification

## P1 report closure

Source: the owner's attached `necropolis-fixes-to-ship(3).pdf`, reviewed against
the current source. Its open P1 is **C1**, Forgotten Cemetery victory feedback.
The old conquest-toast timing entry in Closed is superseded by C1. T1 is marked
P2 and subsequently verified fixed in the same report; U2 is also marked P2.

The code already defines 1/3/5/10 milestones for all three campaigns. The report
describes a later ascension where earlier Cemetery awards are retained and the
next eligible milestone is 10 victories. Reaching seven victories legitimately
earns no new milestone, but the absence of completion feedback is confusing.

Reproduced before the fix: with Cemetery at six victories and its 1/3/5 awards
retained, the seventh victory applied correctly and showed no toast.

**C1 is fixed:** actual campaign level increases now produce an independent
victory notification. New milestones appear alongside those victories. Live
notifications last eight seconds; multiple victories from a warp or delayed
live catch-up are summarized by campaign. Offline victories appear in the
return summary instead of a flood of toasts. Existing awards and reward math
are unchanged, and no new field is added to the game save.

Focused browser checks (`qa/campaign-feedback-250.cjs`) pass:

- Cemetery's seventh victory announces completion while its earlier awards remain single.
- All three campaigns award and notify at 1/3/5/10 victories.
- Post-ascension victories notify even when all milestone awards were previously earned.
- Navigation, forecasts and unrelated purchases create no false victory notice.
- Multiple Time Warp victories have accurate counts and exactly match core resource, reward and Energy results.
- Offline victories appear in the return summary; reload does not re-announce them.
- Delayed live catch-up still notifies; the toast remains beyond the old 4.5-second duration and then expires.
- Dark/light notifications are readable at 320/390/1440px without page overflow. Generic status messages move above the victory notification to avoid covering it.

## Interface and navigation

`qa/navigation-250.cjs` passes at 320/390/900/1440px in both themes. Final release
checks repeated the mobile and desktop widths after the feedback change.
Coverage includes main-menu Overview resets, explicit deep links, persistent
rail DOM, scroll clamping, sticky behavior, keyboard navigation, focused Undead
pages, real recruitment/upgrades, Undo, reload and no horizontal page overflow.

The selected tier stays available in the left rail. Changing the tier within
Undead retains its current work area; selecting a tier from another menu enters
Overview. Game ticks and purchases do not reset submenus.

## Gameplay and saves

- 40 core scenarios pass.
- The progression/campaign forecast audit and all ten own-tier automation frontier checks pass.
- Fresh UI playthroughs pass: desktop five-minute visits with earned warps and mobile eight-hour offline returns without warps. Both complete all tiers/campaign types, ascend, purchase Grave Bloom, reload and continue a new run.
- Single-owner save checks pass: idle-tab protection, simultaneous starts, external rollback detection, back/forward recovery and unavailable/rejected Web Locks.
- Save recovery checks pass: live handoff, frozen-owner expiry, ownership fencing without storage-event delivery, orphan takeover and competing recovery attempts. The competing-recovery test waits for the asynchronous ownership transition to settle instead of sampling after an arbitrary 100ms delay.
- The core engine, milestones module, artwork, embedded logo and license match 2.4.9. V8 portable saves and schema 23 remain unchanged.

These checks cover Chromium desktop/mobile layouts and reproducible gameplay
policies. They are not claims of exhaustive coverage of every browser vendor
or every player strategy. The archive contains no private player save or new
QA screenshots.
