# 2.5.5 verification

Undead recruitment now displays “Each produces…” and “In total they produce…” for the selected tier, using real per-unit and total production. The existing preferred rate setting applies, with /hr as the default. An accent-colored View upgrades button opens upgrades for that same selected tier and follows the first-run menu gates.

Recruitment prices appear in their ingredient bars instead of a repeated price sentence. Territory recruitment now uses the same two-currency bars. Upgrade cards show bars for every currency, replacing the separate Cost sentence and incomplete primary-only progress display. Wait estimates remain separate. Cost details remain where no ingredient bars exist, such as locked-tier previews, and in purchase tooltips.

`qa/navigation-252.cjs` was extended and passes at 320, 390, 900 and 1440px in both themes. It checks exact /hr production text and correct output resources across all ten Undead tiers; upgrades opening on the selected tier; ingredient-bar counts; removal of repeated price lists; all five Territory tiers; overflow; purchases, Undo and navigation without spending.

`qa/first-steps.cjs` passes at 320, 390 and 1440px in both themes, including real intro purchases, progressive menu gates, backup, replay and skipping.

The engine and milestone scripts are byte-identical to v2.5.4. The Territory performance reproduction still makes zero full simulation calls from purchase forecasts; the Eternal War Councils click took 9.5 ms and its five refreshes took 6.9–10.9 ms in this environment. No balance, saved quantities or portable save changes.

Browser checks use Chromium via `NECRO_CHROMIUM=/usr/bin/chromium`. The deployed itch.io game needs the new ZIP uploaded to receive this UI update.
