const assert=require('assert/strict'),fs=require('fs'),path=require('path'),http=require('http'),vm=require('vm'),{chromium}=require('playwright');
const root=path.resolve(__dirname,'..'),html=fs.readFileSync(process.env.NECRO_HTML||path.join(root,'index.html'),'utf8');
const sandbox={};vm.createContext(sandbox);vm.runInContext(html.match(/<script>([\s\S]*?)<\/script>/)[1],sandbox);const C=sandbox.NecropolisCore||sandbox.window?.NecropolisCore;
const key='necropolis-v3-save',errors=[];
const server=http.createServer((req,res)=>{try{const file=path.join(root,new URL(req.url,'http://localhost').pathname);res.setHeader('Content-Type',file.endsWith('.png')?'image/png':file.endsWith('.svg')?'image/svg+xml':'text/html');res.end(file.endsWith('index.html')?html:fs.readFileSync(file));}catch{res.statusCode=404;res.end();}});
(async()=>{await new Promise(r=>server.listen(0,'127.0.0.1',r));const browser=await chromium.launch({executablePath:process.env.NECRO_CHROMIUM||'/usr/bin/chromium',args:['--no-sandbox','--disable-dev-shm-usage']});try{
for(const width of [320,390,900,1440])for(const theme of ['dark','light']){
 const state=C.fresh();for(const id of [...C.IDS,...C.TERRITORY_IDS]){state.n[id]=C.N.of(100);state.n['total_'+id]=C.N.of(100);}for(const id of ['souls','graveSeeds','territory','totalTerritory'])state.n[id]=C.N.of('1e35');state.shards=C.N.of(100);state.energy=1000;
 const ctx=await browser.newContext({viewport:{width,height:1000}});await ctx.addInitScript(({raw,key,theme})=>{if(!localStorage.getItem(key)){localStorage.setItem(key,raw);localStorage.setItem('necropolis-v3-preferences',JSON.stringify({firstSteps:'done',large:true,theme}));}window.__audioContexts=[];const Audio=window.AudioContext;window.AudioContext=class extends Audio{constructor(...args){super(...args);window.__audioContexts.push(this);}};Date.now=()=>JSON.parse(raw).last;window.setInterval=(fn,ms)=>{if(ms===1000)window.__tick=fn;return 0;};},{raw:C.serialize(state),key,theme});
 const p=await ctx.newPage();p.on('pageerror',e=>errors.push(e.message));await p.goto(`http://127.0.0.1:${server.address().port}/index.html`);await p.locator('#tabs button').first().waitFor();const tab=id=>p.locator(`#tabs [data-tab="${id}"]`).click();
 await p.locator('[data-undead-page="recruitment"]').first().click();
 // Deliberately refresh after pointerup but before native click dispatch.
 await p.evaluate(()=>document.addEventListener('pointerup',()=>window.__tick(),true));
 const read=async()=>C.unpack(await p.evaluate(k=>localStorage.getItem(k),key));
 for(let i=0;i<25;i++){const before=await read();await p.locator('[data-buy="skeletons"]').first().click();const after=await read();assert.equal(after.runManualPurchases,before.runManualPurchases+1,`pointerup tick must not swallow purchase ${i}`);assert(after.n.skeletons.cmp(before.n.skeletons)>0);}
 await p.evaluate(()=>document.addEventListener('keyup',()=>window.__tick(),true));for(let i=0;i<5;i++){const before=await read();await p.locator('[data-buy="skeletons"]').first().focus();await p.keyboard.press('Space');assert.equal((await read()).runManualPurchases,before.runManualPurchases+1,'keyboard purchase survives refresh');}
 console.log('PASS 25 purchases with refresh between pointerup and click',width);
 if(process.env.NECRO_BASELINE_ONLY){await ctx.close();continue;}
 await p.locator('[data-undead-page="overview"]').first().click();const before=await read();await p.keyboard.press('b');assert((await read()).n.skeletons.cmp(before.n.skeletons)>0);assert.equal(await p.locator('[data-undead-section]').getAttribute('data-undead-section'),'recruitment');
 await tab('empire');await p.locator('[data-army-preset="balanced"]').click();assert.equal((await read()).empire.conquest,30);assert.equal((await read()).empire.excavation,30);await p.locator('[data-action="undoPurchase"]').click();assert.equal((await read()).empire.conquest,0);
 await tab('ritual');await p.locator('[data-ritual-page="blessings"]').first().click();await p.locator('[data-blessing="stewardBlessing"][data-count="10"]').click();assert.equal((await read()).blessings.stewardBlessing,10);
 // Check real text boxes, not just document scrollWidth (the app deliberately clips root overflow).
 const clipping=[];
 for(const section of ['ritual','undead','territory','empire','energy']){
  await tab(section);if(section==='ritual')await p.locator('[data-ritual-page="blessings"]').first().click();if(section==='undead')await p.locator('[data-undead-page="upgrades"]').first().click();
  const bad=await p.evaluate(()=>[...document.querySelectorAll('#content p,#content h3,#content .fine')].filter(el=>el.getClientRects().length).flatMap(el=>{const range=document.createRange();range.selectNodeContents(el);const r=el.getBoundingClientRect(),text=range.getBoundingClientRect();return text.right>innerWidth+2||text.right>r.right+2||text.left<r.left-2||el.scrollHeight>el.clientHeight+2?[{text:el.textContent.slice(0,65),width:r.width,scroll:el.scrollWidth}]:[];}));clipping.push(...bad.map(b=>({section,...b})));
 }
 assert.deepEqual(clipping,[],'prose must fit its own box');
 await p.locator('[data-auto-upgrade="energyFlow"]').click();await p.locator('[data-auto-upgrade="warpMastery"]').click();await p.locator('[data-auto-toggle]').click();const preWarp=await read();await p.locator('[data-warp="0.25"]').click();const postWarp=await read();assert(postWarp.upgrades.energyFlow>preWarp.upgrades.energyFlow);assert(postWarp.upgrades.warpMastery>preWarp.upgrades.warpMastery);assert.equal(postWarp.energy,preWarp.energy-300);assert.match(await p.locator('#status').innerText(),/automatic purchase batches/);

 await tab('options');await p.locator('[data-action="toggleSound"]').click();assert.equal(await p.locator('[data-action="toggleSound"]').getAttribute('aria-pressed'),'true');assert.equal(await p.evaluate(()=>window.__audioContexts[0].state),'running');await p.locator('[data-action="toggleSound"]').click();assert.equal(await p.locator('[data-action="toggleSound"]').getAttribute('aria-pressed'),'false');assert.equal(await p.evaluate(()=>window.__audioContexts[0].state),'suspended');assert.equal(await p.evaluate(()=>window.__audioContexts.length),1);
 await tab('undead');assert.equal(await p.locator('[data-undead-section]').getAttribute('data-undead-section'),'recruitment');
 await ctx.close();console.log('PASS overview shortcut, presets/Undo, Starting Legion, global prose bounds and audio toggle',width);
}
assert.deepEqual(errors,[]);
}finally{await browser.close();server.close();}})().catch(e=>{console.error(e);process.exitCode=1;server.close();});
