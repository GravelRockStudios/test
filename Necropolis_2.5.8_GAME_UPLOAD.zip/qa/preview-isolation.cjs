// Executes the actual UI projection function, not a duplicate implementation.
const assert=require('assert'),fs=require('fs'),vm=require('vm'),path=require('path'),C=require('./extract-core.cjs');
const html=fs.readFileSync(process.env.NECRO_HTML||path.join(__dirname,'../index.html'),'utf8');
const code=html.slice(html.indexOf('function projectionAt('),html.indexOf('function predictWait('));
for(const id of Object.keys(C.CAMPAIGNS))for(const level of [0,1,9]){
 const s=C.fresh();s.n.totalTerritory=C.N.of(25);s.n.raiders=C.N.of(100);s.n.total_raiders=s.n.raiders;s.n.necromancers=C.N.of(10);s.n.total_necromancers=s.n.necromancers;s.empire.conquest=20;s.empire.excavation=20;s.empire.buildings={gravefields:2,crypts:2,obelisks:2};
 if(level)s.empire.campaigns.completed=[id];if(level>1)s.empire.campaigns.stages={[id]:level};C.startCampaign(s,id);
 const raw=C.serialize(s),box={s,C};vm.createContext(box);vm.runInContext(code,box);
 const seconds=C.campaignSecondsRemaining(s,id)*2;
 vm.runInContext(`projectionAt(${seconds})`,box);
 assert.equal(C.serialize(s),raw,`${id} level ${level}: a purchase-wait preview mutated the live save`);
}
console.log('PASS 9 UI projection isolation fixtures: future victories, progress, reward arrays, stages, Insight, units and resources stay private');
if(html.includes('function seedEconomyDisplay()')){
 const code=html.slice(html.indexOf('function seedEconomyDisplay()'),html.indexOf('function resourceUI()'));
 for(const active of [false,true]){const s=C.fresh();s.n.total_necromancers=C.N.of(1);s.n.souls=C.N.of('1e9');s.n.graveSeeds=C.N.of('1e6');s.autoEnabled=active;s.autoConfig.units=['skeletons'];const before=C.serialize(s),box={s,C,N:C.N,fmtRate:n=>C.N.of(n).toString()};vm.createContext(box);vm.runInContext(code,box);const result=vm.runInContext('seedEconomyDisplay()',box);assert.equal(result.negative,active);assert.equal(result.label.startsWith('−'),active);assert.equal(C.serialize(s),before);}
 console.log('PASS net Seed display preserves state and correctly shows negative buyer drain');
}
