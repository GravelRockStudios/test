# Necropolis 2.2.2 — conquest completion with automation

The 2.2.1 estimate included natural army growth but excluded future buyer
purchases. With buyers enabled on the supplied save, Cemetery was estimated at
17.6965 hours even though the live buying engine completed it in 12.4792 hours.

The new forecast advances a private state through actual five-minute buyer
cycles, including the current cycle phase, reserve, unit costs, consumed
predecessors, passive recruitment and campaign allocation. Within each cycle,
the existing integrated Territory solver determines the completion boundary.
The forecast does not change the player's resources or progress.

The screen shows separate Playing and Offline times when offline buying is
disabled. When both use the same settings, it shows one time. Pausing buyers,
changing assignments/allocation, buying manually, casting a Time Warp, importing
or Undoing an action refreshes the forecast. Warps retain their existing
production-only simulation and their preview still matches execution.

Display work is bounded to 512 future buyer cycles. If the target is not finished
within that horizon, the screen shows a rounded-down lower bound such as
Over 42 hr instead of claiming an exact completion time. This limits forecast
work only; gameplay, resource production and offline elapsed time are unchanged.
Only the active target is forecast, and results are cached between updates.

Validation covers all three allocations, ordinary and near-boundary buyer timer
phases, online/offline buying, master pause, zero initial production with future
purchases, non-mutating previews, retained contributions, Time Warp and the
reported save. Completion is checked just before and after the predicted time
using independent ten-second simulation steps.

Passed: 40 core scenarios, 14 progression scenarios, 12 permanent/campaign
scenarios, 7 focused conquest timing scenarios, 32 existing browser scenarios
and 2 focused browser scenarios. The focused browser checks run at 390px and
1440px and cover buyer toggles, offline settings, allocations, Undo, a live buyer
cycle and immediate Time Warp refresh. Save checks include 100 generated
precision fixtures and exact restoration of the supplied older save.

Original artwork, the selected license, save schema 22 and the compact V7 format
are preserved. The reported original save still exports to 685 characters and
older codes still import. Player save data is not included in the release ZIP.
