# Necropolis: Rise of the Undying

Necropolis is a free, text-based idle/incremental game about building an undead empire.

## How to play

Start in **Undead** by raising Skeletons to gather Souls. Use Souls to recruit Necromancers, then unlock stronger undead tiers. Each tier produces the tier beneath it, so your army continues growing on its own—even while you are away.

The first-run introduction reveals systems as you use them. Skip or replay it from Options.

- **Undead** — opens Recruitment; choose a tier, raise units, or use its small View upgrades shortcut.
- **Empire** — assign Skeletons to harvesting, conquest or excavation; choose a doctrine and develop Territory.
- **Territory** — recruit conquest troops and run campaigns, with optional Repeat or Rotate.
- **Dark Energy** — unlocks after raising three Necromancers or ascending. Spend energy on Time Warps; doctrine changes in Empire also cost energy.
- **Ritual** — ascend for Lich Shards and spend them on permanent blessings. Starting Legion grants starting Skeletons and Necromancers on your next ascension.
- **Milestones** — track achievements and find a suggested next action.
- **Automation** — choose unit and upgrade buyers, a reserve, and whether they run while away. Enabled buyers run every minute and during Time Warps.
- **Options** — export or restore a save, adjust display settings, enable optional ambient audio and sound effects, or read the changelog.

## Reading the numbers

Production rates use **/hr** by default. You can switch the display to `/min` or `/s` in Options. Large values stay compact with suffixes such as **K**, **M**, **B**, **T**, and **Qa**; costs and other important values are rounded to a readable whole number unless a decimal is needed for accuracy.

## Growing faster

Keep production upgrades running, expand Territory when it becomes available, and use Dark Energy for well-timed Time Warps. When you are ready, **ascend**: ascending resets the current run but awards Lich Shards for permanent blessings that make future runs stronger and faster. Ascension is crucial to keep your long-term growth accelerating.

Dark Energy Storage, Dark Conduits and Chronomancy are kept after ascension. Time Warps never refill Dark Energy.

## Saving and support

Your progress saves automatically in your browser. For safety, open **Options** and download a save backup before clearing browser data or changing devices.

Support and bug reports: [gravelrockstudios@gmail.com](mailto:gravelrockstudios@gmail.com)

**Special thanks: Evan Rosson**  

