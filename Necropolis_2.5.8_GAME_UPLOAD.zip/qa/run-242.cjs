// Focused regressions for the 2.4.2 navigation change; run with Playwright installed.
const fs=require('fs'),path=require('path'),{spawnSync}=require('child_process');
const suites=['verify','rendering','preview-isolation','portable-240','restore-browser-241','conquest-browser','preview-browser','reliability-browser-241','automation-browser-242'];
const out=path.join(__dirname,'results-2.4.2');fs.mkdirSync(out,{recursive:true});let failed=0;const results=[];
for(const name of suites){const start=Date.now(),r=spawnSync(process.execPath,[path.join(__dirname,name+'.cjs')],{encoding:'utf8',timeout:120000,maxBuffer:4e6,env:process.env});const log=(r.stdout||'')+(r.stderr||'')+(r.error?'\n'+r.error.message:'');fs.writeFileSync(path.join(out,name+'.txt'),log);const row={name,status:r.status===0?'passed':'failed',seconds:(Date.now()-start)/1000};results.push(row);console.log(JSON.stringify(row));if(r.status!==0){failed++;console.log(log.slice(-2500));}}
fs.writeFileSync(path.join(out,'summary.json'),JSON.stringify({results,failed},null,2));process.exitCode=failed?1:0;
