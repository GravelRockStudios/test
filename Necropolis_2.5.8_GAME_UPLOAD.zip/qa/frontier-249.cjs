// Own-tier gates must work at every frontier without selecting new buyers.
const assert=require('assert'),C=require('./extract-core.cjs'),N=C.N;
for(let i=0;i<C.IDS.length;i++){
 const s=C.fresh(),id=C.IDS[i];s.n.souls=N.of('1e100');s.n.territory=N.of('1e100');s.n.totalTerritory=N.of('1e100');s.n.graveSeeds=N.of('1e20');
 for(let j=0;j<i;j++){s.n[C.IDS[j]]=N.of(10000);s.n['total_'+C.IDS[j]]=N.of(10000);}
 assert(!C.autoBuyerUnlocked(s,id));assert(!C.autoUpgradeUnlocked(s,'twin_'+id));assert.equal(C.buyUpgrade(s,'twin_'+id,1),0);
 assert(C.buy(s,id,1));assert(C.autoBuyerUnlocked(s,id));assert(C.autoUpgradeUnlocked(s,'twin_'+id));assert(!s.autoConfig.units.includes(id));assert(!s.autoConfig.upgrades.includes('twin_'+id));
 assert(C.buyUpgrade(s,'twin_'+id,1));s.autoEnabled=true;s.autoConfig.offline=true;s.autoConfig.units=[id];s.autoConfig.upgrades=['twin_'+id];const before=s.n[id];
 const a=C.copyState(s),b=C.copyState(s);C.advanceWithAutomation(a,3600,{offline:true});for(let t=0;t<12;t++)C.advanceWithAutomation(b,300);
 assert(a.n[id].cmp(before)>0);for(const k of Object.keys(a.n)){if(!a.n[k].m&&!b.n[k].m)continue;assert(Math.abs(a.n[k].div(b.n[k]).num()-1)<1e-8,k);}
 const restored=C.unpack(C.serialize(a));assert.deepEqual(restored.autoConfig,a.autoConfig);
}
console.log('PASS own-tier Recruit/Multiplicity gates, opt-in defaults, actual purchases, active/offline equivalence and reload at all ten frontiers');
