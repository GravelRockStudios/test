// Reproducible strategy samples using the game's real spending and simulation code.
// This is a feasibility model, not a prediction of every player's behavior.
const C=require(process.env.NECRO_MODEL_CORE||'./extract-core.cjs'),N=C.N,fs=require('fs'),path=require('path');
const day=86400;
function manualBuy(s,id,q,conquest=false){const raised=conquest?C.buyConquest(s,id,q):C.buy(s,id,q);if(raised)s.runManualPurchases++;return raised;}
function smallUpgrade(s,id,fraction=.08){if(!C.UPGRADES[id])return;const costs=C.upgradeCosts(s,id);if(Object.entries(costs).every(([k,v])=>v.cmp(s.n[k].mul(fraction))<=0))C.buyUpgrade(s,id,1);}
function act(s,profile,t){
 if(profile.auto){s.autoEnabled=true;s.autoConfig.offline=true;s.autoConfig.units=C.IDS.filter(id=>s.n['total_'+id].cmp(1)>=0);}
 if(C.empireUnlocked(s)){s.empire.conquest=20;s.empire.excavation=10;}
 if(profile.doctrine!=='none'&&C.doctrineUnlocked(s)&&s.empire.doctrine==='none')C.chooseDoctrine(s,profile.doctrine);
 if(C.startCampaign&&s.n.totalTerritory.cmp(25)>=0&&!s.empire.campaigns.active){const ids=Object.keys(C.CAMPAIGNS).filter(id=>C.campaignLevel||!C.campaignWon(s,id));ids.sort((a,b)=>(C.campaignLevel?.(s,a)||0)-(C.campaignLevel?.(s,b)||0));if(ids.length)C.startCampaign(s,ids[0]);}
 const focus=profile.research||'seeds';if(C.teachingUnlocked(s,focus)&&s.empire.teaching!==focus)C.chooseTeaching(s,focus);
 for(const id of ['harvest','expand','energyFlow','warpMastery'])smallUpgrade(s,id);
 for(const id of C.IDS)if(s.n['total_'+id].cmp(1)>=0){smallUpgrade(s,'tier_'+id);smallUpgrade(s,'twin_'+id);}
 if(C.usedPlots(s)<C.plotCapacity(s)&&C.developmentCost(s).cmp(s.n.territory.mul(.15))<=0){const b=s.empire.buildings;C.develop(s,b.gravefields<=b.crypts+2?'gravefields':b.crypts<=b.obelisks+1?'crypts':'obelisks');}
 if(C.loreCost(s).cmp(s.empire.insight)<=0)C.studyLore(s);
 if(profile.warps&&s.energy>=2000)C.warp(s,.25); // At most one cast per check-in.
 if(profile.doctrine==='cult'&&t>0&&t%((profile.offeringMinutes||1440)*60)===0)C.sacrifice(s,10);
 // Keep Seeds for the next tier; Soul abundance alone must not justify draining Seeds.
 const goal=C.IDS.findIndex(id=>s.n['total_'+id].cmp(1)<0),reserve=N.of(C.SEED_COST[goal<0?C.IDS.length-1:goal]);
 for(let i=C.TERRITORY_IDS.length-1;i>=0;i--){if(!C.conquestRevealed(s,i))continue;const id=C.TERRITORY_IDS[i];let q=C.conquestAffordable(s,id),budget=s.n.souls.mul(.01).div(C.TERRITORY_COST[i]).floor(),seedBudget=s.n.graveSeeds.sub(reserve).mul(.01).div(C.CONQUEST_SEED_COST?.[i]||1).floor();if(budget.cmp(seedBudget)>0)budget=seedBudget;if(q.cmp(budget)>0)q=budget;if(q.cmp(1)>=0){manualBuy(s,id,q,true);break;}}
 let target=C.IDS.findIndex(id=>s.n['total_'+id].cmp(1)<0);if(target<0)target=C.IDS.length-1;
 if(target>1&&s.n[C.IDS[target-1]].cmp(C.PREV_COST[target])>=0){if(C.revealed(s,target))manualBuy(s,C.IDS[target],1);}
 else {const i=Math.max(1,target-1),id=C.IDS[i];if(C.revealed(s,i)&&C.affordable(s,id).cmp(1)>=0&&s.n[id].cmp(C.PREV_COST[i+1]*1.2)<0){let q=C.affordable(s,id);const need=N.of(C.PREV_COST[i+1]*1.2).sub(s.n[id]).div(C.batchSize(s,id)).floor().add(1);if(q.cmp(need)>0)q=need;if(q.cmp(1)>=0)manualBuy(s,id,q);}}
 if(s.n.necromancers.cmp(4)<0){let q=C.affordable(s,'skeletons').mul(.25).floor();if(q.cmp(1)<0)q=N.of(1);manualBuy(s,'skeletons',q);}
}
function run(profile,initial=C.fresh(),goal='end',horizon=90*day){
 const s=C.copyState(initial),first={},campaigns=[],seen={},step=profile.minutes*60;let firstAscend=null,t=0;
 for(;t<=horizon;t+=step){act(s,profile,t);
  for(const id of C.IDS)if(first[id]===undefined&&s.n['total_'+id].cmp(1)>=0)first[id]=t/3600;
  for(const id of Object.keys(C.CAMPAIGNS)){const level=C.campaignLevel?.(s,id)||(C.campaignWon(s,id)?1:0);if(level>(seen[id]||0)){campaigns.push({id,level,hours:t/3600});seen[id]=level;}}
  if(firstAscend===null&&C.canAscend(s))firstAscend=t/3600;
  if(goal==='ascend'&&C.canAscend(s)||goal==='end'&&first.endbringers!==undefined)break;
  C.advanceWithAutomation(s,step,{offline:profile.offline===true});
 }
 return {state:s,summary:{...profile,goal,reached:goal==='ascend'?C.canAscend(s):first.endbringers!==undefined,hours:+(t/3600).toFixed(2),firstAscensionHours:firstAscend,firstTierHours:Object.fromEntries(Object.entries(first).map(([id,h])=>[C.LABELS[C.IDS.indexOf(id)],+h.toFixed(2)])),souls:s.n.runSouls.toString(),seedRatePerSecond:+C.graveSeedRate(s).num().toPrecision(5),campaignLevels:Object.fromEntries(Object.keys(C.CAMPAIGNS).map(id=>[id,C.campaignLevel?.(s,id)||(C.campaignWon(s,id)?1:0)])),campaigns,warpCount:s.runWarpCount,shardReward:C.ascensionReward(s).toString(),nextAscensionSouls:C.ascensionRequirements(s).souls.toString()}};
}
function spendShards(s){
 if(C.legacyOffer){const ids=Object.keys(C.LEGACY_UNLOCKS).sort((a,b)=>C.legacyOffer(s,a).cost.cmp(C.legacyOffer(s,b).cost));for(const id of ids)if(C.legacyOffer(s,id).cost.cmp(s.shards.mul(.4))<=0){C.buyLegacyUnlock(s,id);break;}}
 else for(const [id,d]of Object.entries(C.LEGACY_UNLOCKS))if(!C.hasUnlock(s,id)&&s.shards.mul(.4).cmp(d.cost)>=0){C.buyLegacyUnlock(s,id);break;}
 for(const [id,f]of [['warpBlessing',.5],['harvestBlessing',.5],['summonBlessing',1]]){const q=Math.floor(s.shards.mul(f).num());if(q)C.buyBlessing(s,id,q);}
}
function cycles(profile,count=120,horizon=365*day){let s=C.fresh(),elapsed=0,rows=[];for(let i=0;i<count&&elapsed<horizon;i++){const r=run(profile,s,'ascend',horizon-elapsed);elapsed+=r.summary.hours*3600;if(!r.summary.reached)return {profile,reached:false,completed:s.prestiges,hours:elapsed/3600,wall:r.summary,rows};const reward=C.ascend(r.state);s=r.state;spendShards(s);rows.push({ascension:s.prestiges,hours:+r.summary.hours.toFixed(2),elapsedDays:+(elapsed/day).toFixed(2),reward:reward.toString(),depth:Object.keys(r.summary.firstTierHours).length,highestTier:Object.keys(r.summary.firstTierHours).at(-1),permanentRanks:Object.fromEntries(Object.keys(C.LEGACY_UNLOCKS).map(id=>[id,C.legacyRank?.(s,id)||(C.hasUnlock(s,id)?1:0)])),startingLore:s.empire.lore,nextSouls:C.ascensionRequirements(s).souls.toString()});}return {profile,reached:s.prestiges>=count,completed:s.prestiges,hours:elapsed/3600,rows};}
function main(){const profiles=[...['horde','lich','cult'].flatMap(doctrine=>[5,480].map(minutes=>({doctrine,minutes,warps:true}))),{doctrine:'horde',minutes:5,warps:false},{doctrine:'horde',minutes:480,warps:false}];const runs=profiles.map(p=>{const r=run(p);console.log(JSON.stringify({...r.summary,campaigns:undefined,firstTierHours:undefined}));return r.summary;});const loops=[{doctrine:'horde',minutes:5,warps:true},{doctrine:'horde',minutes:480,warps:true}].map(p=>{const r=cycles(p);console.log(JSON.stringify({profile:r.profile,reached:r.reached,completed:r.completed,days:r.hours/24,samples:r.rows.filter(x=>[1,10,25,50,80,100,120].includes(x.ascension))}));return r;});const output={assumptions:'Fresh saves; spending only earned resources; 20% conquest and 10% excavation; seed teaching when available; one upgrade/build/warp per check-in; conquest budget 1%; no offline cap; 90-day tier horizon and 365-day prestige horizon. No autoplay is supplied to the game.',runs,loops};const dest=process.env.NECRO_MODEL_OUTPUT||path.join(__dirname,'balance-results-2.2.0.json');fs.writeFileSync(dest,JSON.stringify(output,null,2));}
if(require.main===module)main();
module.exports={run,cycles,act,main};
