// Earned-resource policies. Hourly/eight-hour/daily visits are strategy samples, not promised completion times.
const fs=require('fs'),vm=require('vm'),path=require('path');
const C=require(process.env.NECRO_AUDIT_CORE||'./extract-core.cjs');
const src=fs.readFileSync(path.join(__dirname,'balance-model.cjs'),'utf8');
const m={exports:{}};new Function('require','module','exports','__dirname',src)(id=>id==='./extract-core.cjs'?C:require(id),m,m.exports,__dirname);
function run(minutes,warps,auto=false){const s=C.fresh(),first={},blocked={},snapshots={};let t=0;
for(;t<60*86400;t+=minutes*60){m.exports.act(s,{doctrine:'horde',minutes,warps},t);C.setCampaignAuto(s,'rotate');
if(auto){s.autoEnabled=true;s.autoConfig.offline=true;s.autoConfig.units=C.IDS.filter(id=>s.n['total_'+id].cmp(1)>=0);s.autoConfig.upgrades=['harvest','expand',...C.IDS.filter(id=>s.n['total_'+id].cmp(1)>=0).flatMap(id=>['tier_'+id,'twin_'+id])];}
for(const id of C.IDS)if(first[id]===undefined&&s.n['total_'+id].cmp(1)>=0){first[id]=t/3600;snapshots[id]={seeds:s.n.graveSeeds.toString(),seedRate:C.graveSeedRate(s).num(),souls:s.n.souls.toString(),batch:C.batchSize(s,id).num()};}
let i=C.IDS.findIndex(id=>s.n['total_'+id].cmp(1)<0);if(i<0)break;
const id=C.IDS[i];blocked[id]??={souls:0,seeds:0,previous:0};if(s.n.souls.cmp(C.SOUL_COST[i])<0)blocked[id].souls+=minutes/60;if(s.n.graveSeeds.cmp(C.SEED_COST[i])<0)blocked[id].seeds+=minutes/60;if(i&&s.n[C.IDS[i-1]].cmp(C.PREV_COST[i])<0)blocked[id].previous+=minutes/60;
C.advanceWithAutomation(s,minutes*60,{offline:minutes>=480});}
return{minutes,warps,auto,hours:t/3600,first,blocked,snapshots};}
const result=[run(5,true),run(60,false),run(480,false),run(1440,false),run(480,false,true)];fs.writeFileSync(process.env.NECRO_AUDIT_OUTPUT||path.join(__dirname,'balance-2.4.8.json'),JSON.stringify(result,null,2));console.log(JSON.stringify(result.map(({snapshots,blocked,...r})=>r),null,2));
