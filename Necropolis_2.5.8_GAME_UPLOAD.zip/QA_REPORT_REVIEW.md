# Revised report disposition - v1.5.2

Reviewed `necropolis-fix-change-report(1).pdf` dated 2026-09-28.

| Report item | Disposition |
| --- | --- |
| A1 master persistence | Retained and regression tested. |
| A2 float costs | Cleaned at the calculation source; shared affordability tolerance. Fractional Domain prices are valid, not all floating-point residue. |
| A3 Deathlords wording | Correct current tier mapping retained. |
| A4 cost flooring | Exact cost displays retained. |
| A5 warp forecast | Shared simulation verified in core and with an actual browser click. |
| A6 dead Ascend | Old failure reproduced in an iframe without `allow-modals`; native confirm was blocked. New in-game dialog tested through cancellation and completed ascension. |
| A7 false conflict | Harmless same-tab rewrite reproduced/tested; writer/revision tracking added. Real second-session changes still block stale saves. The precise origin of the reporter's external write cannot be established from the PDF alone. |
| A8 grammar | Removed the article from buyer-unlock descriptions. |
| B1 Vessel | Small bonus is intentional in the existing curve. Current percent, exact storage and next-level capacity are visible. |
| B2 energy carryover | Intentional retention verified and documented in the preview/dialog. |
| B3 Reset | New dialog tested: cancel preserves progress; accept resets and retains recovery backup. |
| B4 Conduits | Single/Max buttons and actual purchase tested at a floating-point boundary. |
| B5 Undo | Documented in Options. Refunds consumed units; 30-second manual snapshot; later automatic purchases clear it; current buyer settings survive. |
| B6 shards | Earned shards add to unspent shards; projected award and retained balance tested. |
| C1 flat pricing | Already flat at every owned quantity, verified across all ten tiers. No within-tier unit price growth to remove. |
| C2 recipe visibility | Added current ingredient progress and explicit consumption/production-loss warning. Recipes already apply throughout the ladder. |
| C3 parallel progression | Existing Territory, development, Insight and Teachings retained. A new currency or track needs a defined progression design; not invented in this bug-fix release. |
| C4 ETA | Existing shared-simulation purchase/upgrade ETA retained. |
| C5 supporting balance | Preserved offline/active parity as requested. Existing sacrifice is logarithmic, not a fixed +0.1%; new previews show the actual resulting bonus. Energy pacing not silently changed. |
| C6 number climb | Prestige access fixed; diminishing upgrades and existing ascension curves retained. |
| D1 Undo | Retained and edge cases tested. |
| D2 random proc rewards | Deferred: a new random power reward changes the deterministic economy; no such mechanic added in a bug-fix release. |
| D3 custom buying | Existing %, =amount and K/M/B/T input retained and tested in the browser. Mobile text keyboard permits suffixes and %. |
| D4 shortcuts | Existing 1-8/B/U/W retained; disabled while typing or confirming. |
| D5 milestone toasts | Existing popup observed after a real purchase. |
| D6 changelog | v1.5.2 is visible in-game; changelog included here and in Options. No external itch.io page was edited. |

All balance comparisons use the same elapsed time and starting state. Production grows during that time because upper tiers continuously generate lower tiers; that growth is shared by active play, offline progression and warps.
