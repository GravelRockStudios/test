# Fixes-to-ship report: v1.5.4 disposition

Reviewed the two-page report dated 2026-09-28 against v1.5.3. The report tested v1.5.1; earlier verified fixes are retained. All original PNG artwork is preserved.

| Item | Outcome |
| --- | --- |
| F1 Territory warp preview | Preview and execution now consume the same core warp projection. Forecast rows expose resource IDs and unrounded gains for verification. Tests compare all resource results with 300 ordinary production steps across all four doctrines, including growing Skeleton armies, conquest assignments and military units. The completion message reports actual Territory and Soul gains. The reported old-build discrepancy was not reproduced in this build. |
| F2 Archlich production / wait | Controlled 300-second production and browser accumulation checks use nine Archliches with buyers off. Displayed incoming production matches accumulation. The unit page now distinguishes incoming recruitment from that unit's output, explains purchase consumption, and warns when buyers are running. ETAs explicitly assume no buyer spending when buyers are active. |
| F3 Hidden +500 Dark Energy | Reproduced: five Soul Harvesting levels changed 2,844 to 3,344 Energy. Removed the timed reward from Soul Harvesting and Domain Expansion. Regression checks cover every ordinary upgrade and undead purchase. Time-based regeneration still works. Historical cooldown fields remain readable for save compatibility but no longer grant a reward. |
| F4 Buyer Seed drain | Every buyer shows its Seed price prominently, the full per-batch recipe and units raised. A shared preview reports selected buyers' Seed spending if a cycle ran now, compares it with five minutes of Seed income, and warns when spending exceeds that income. It respects current reserves and higher-tier-first execution. Paused status is explicit; passive recruitment is labeled free. |
| F5 Repeated Vessel toast | Notifications are deduplicated by milestone ID for the live session, independently of undoable save snapshots. Undoing and repeating the same purchase cannot notify the same milestone again. Earned milestone state still follows the save. |
| F6 Hidden storage bonus | Header tooltip gives capacity to three decimal places, including 10,004.998 after the first Vessel upgrade. The Energy page shows the same detail as ordinary text for touch users. Vessel's next-upgrade preview also shows the incremental capacity gain. Main resource totals keep compact notation. |
| F7 Articles / singulars | No remaining literal 'a Liche' or 'a Archlich' was found. Centralized unit singularization for shortages, multiplicity and buyer batch descriptions. Buyer unlock copy uses plural names and avoids article errors. |
| F8 Forecast labels | Each row explicitly contains the resource label and amount, with a stable resource identifier. Browser checks verify Souls and Skeletons labels are visible and label/value bounds do not overlap at 390px. |

## Balance decisions: B1 and B2

Keep the current blessing and warp formulas in this bug-fix release. The report labels these as design-review notes, and its runs had different warp usage and unresolved production measurements; those timings cannot establish a controlled prestige-speed comparison.

The current 20 Eternal Legion / 10 Endless Hunger allocation gives +26.035% Skeleton Soul production, +16.528% Necromancer production, +11.018% Lich production, +8.264% Archlich production and +6.611% Deathlord production before other additive bonuses. Eternal Legion's card now lists the important mid-game tier effects so the smaller upper-tier benefit is visible before further spending.

Time Warp advances the full growing production chain. Comparing its Territory forecast only with current Territory/second times its duration underestimates gains when assigned Skeletons are being produced during the warp. Warps spend 2K Energy and do not regenerate Energy or execute buyers. Chronomancy at levels 0, 2 and 15 currently advances 15, 28.8 and 352.5 minutes before Warp Lore. Warp Lore uses the same duration function in its effect preview and execution.

No blessing strength increase, consumption-cost reduction, offline cap or offline multiplier was introduced. Equal elapsed active and offline production continues to match with equivalent buyer settings. Removing the hidden purchase Energy bonus is the intentional pacing change required by F3.

## Verification scope

Automated checks cover the core simulation and an embedded Chromium game without native-modal permission, plus mobile layouts. They are controlled scenarios, not a claim of completing a new multi-day human playthrough. The old report's precise F1/F2 save snapshots were not supplied; their exact historical circumstances could not be reconstructed.
