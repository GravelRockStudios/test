// Template-level regressions; these do not replace real-browser layout checks.
const fs=require('fs'),vm=require('vm'),assert=require('assert'),C=require('./extract-core.cjs');
const html=fs.readFileSync(require('path').join(__dirname,'../index.html'),'utf8');
const sandbox={C,N:C.N,automationHelpOpen:false,AUTOMATION_PAGES:{overview:'Overview',undead:'Undead',conquest:'Conquest',resources:'Resources'},AUTOMATION_PAGE_ART:{overview:'',undead:'',conquest:'',resources:''},knownTab:()=>false,duration:()=>'',prefs:{numbers:'standard',automationPage:'overview'},s:C.fresh(),esc:String,g:C.fmt,fmtRate:x=>C.fmt(C.N.of(x).mul(3600))+'/hr',costLine:()=>'',conquestPriceLine:()=>'',assetImg:()=>'',TAB_ART:{automation:''}};
vm.createContext(sandbox);
function load(name,next){const start=html.indexOf('function '+name+'('),end=html.indexOf('\n'+next,start);assert(start>=0&&end>start,name);vm.runInContext(html.slice(start,end),sandbox);}
load('wholeDisplay','function exactDisplay');sandbox.f=sandbox.wholeDisplay;
for(const [amount,want]of [[0, '0'],[123.6,'124'],[999.6,'1K'],[944123.456,'944K'],[999600,'1M'],[1e12,'1T']])assert.equal(sandbox.energyDisplay(amount),want);
load('singularUnit','function unitCountLabel');load('unitCountLabel','function ');
load('buyRow','function productionFacts');load('productionFacts','function unitUpgrades');load('automationUI','function raiderCosts');
for(const [plural,singular] of [['Liches','Lich'],['Archliches','Archlich'],['Deathlords','Deathlord'],['Dreadlords','Dreadlord']]){assert.equal(sandbox.unitCountLabel(plural,1),singular);assert.equal(sandbox.unitCountLabel(plural,2),plural);}
for(const n of [3,14,26]){sandbox.s.shards=C.N.of(n);const max=C.maxBlessing(sandbox.s,'summonBlessing');assert(sandbox.buyRow('blessing','summonBlessing',C.N.of(max)).includes(n+' upgrades to buy'));}
sandbox.s.autoConfig.units=['necromancers'];const overview=sandbox.automationUI();assert(!overview.includes('data-auto-unit'));assert(overview.includes('After ascending, press Start buyers'));sandbox.prefs.automationPage='undead';const automation=sandbox.automationUI();assert(/data-auto-unit="necromancers" aria-pressed="false"[^>]*disabled/.test(automation));assert(automation.includes('Locked'));assert(!automation.includes('data-auto-unit="endbringers"'));
assert(sandbox.productionFacts({owned:C.N.of(1),each:1,total:1,output:'Skeletons',producer:'Necromancers',unitName:'Liches'}).includes('</strong> lich.'));
assert(html.includes("undead:'undead_army_banner.svg'"));assert(fs.existsSync(require('path').join(__dirname,'../undead_army_banner.svg')));
for(const m of html.matchAll(/<script(?:\s[^>]*)?>([\s\S]*?)<\/script>/g))new vm.Script(m[1]);
assert(!html.split('</body></html>')[1].trim(),'No source may appear outside the HTML document');
console.log('PASS template regressions: grammar, Buy Max, locked buyers, resume copy, banner reference, script syntax');
