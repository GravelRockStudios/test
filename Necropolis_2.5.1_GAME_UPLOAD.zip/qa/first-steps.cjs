const assert=require('assert/strict'),fs=require('fs'),path=require('path'),http=require('http'),{chromium}=require('playwright'),C=require('./extract-core.cjs');
const root=path.resolve(__dirname,'..'),key='necropolis-v3-save',prefsKey='necropolis-v3-preferences',errors=[];
const server=http.createServer((req,res)=>{try{const f=path.join(root,new URL(req.url,'http://localhost').pathname);res.setHeader('Content-Type',f.endsWith('.png')?'image/png':'text/html');res.end(fs.readFileSync(f));}catch{res.statusCode=404;res.end();}});
(async()=>{await new Promise(r=>server.listen(0,'127.0.0.1',r));const browser=await chromium.launch({executablePath:process.env.NECRO_CHROMIUM,args:['--no-sandbox','--disable-dev-shm-usage']});
const open=async({width=390,theme='dark',state=C.fresh(),mobile=false,ipad=false}={})=>{
 const ctx=await browser.newContext({viewport:{width,height:900},hasTouch:mobile||ipad,userAgent:mobile?'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 Mobile/15E148':'Mozilla/5.0'});
 await ctx.addInitScript(({raw,key,prefsKey,theme,ipad})=>{if(!localStorage.getItem(key)){localStorage.setItem(key,raw);localStorage.setItem(prefsKey,JSON.stringify({theme,large:true}));}const now=JSON.parse(raw).last;Date.now=()=>now;window.setInterval=(fn,ms)=>{if(ms===1000)window.__tick=fn;return 0;};if(ipad){Object.defineProperty(navigator,'platform',{get:()=> 'MacIntel'});Object.defineProperty(navigator,'maxTouchPoints',{get:()=>5});}},{raw:C.serialize(state),key,prefsKey,theme,ipad});
 const p=await ctx.newPage();p.on('pageerror',e=>errors.push(e.message));await p.goto(`http://127.0.0.1:${server.address().port}/index.html`);await p.locator('#tabs button').first().waitFor();return {ctx,p};
};
const read=p=>p.evaluate(key=>localStorage.getItem(key),key);
try{
 for(const width of [320,390,1440])for(const theme of ['dark','light']){
  const {ctx,p}=await open({width,theme,mobile:width<500});
  assert(await p.locator('#firstSteps').isVisible());assert.match(await p.locator('#firstSteps').innerText(),/1 of 4/i);
  assert.equal(await p.locator('#mobileSaveNotice').isVisible(),width<500);
  const before=await read(p);
  await p.locator('[data-action="guideOpen"]').click();assert.equal(await p.locator('[data-undead-section]').getAttribute('data-undead-section'),'recruitment');assert.equal(await read(p),before,'tour navigation spends nothing');
  await p.locator('[data-buy="skeletons"][data-count="1"]').click();const bought=C.unpack(await read(p));assert.equal(bought.n.skeletons.num(),1);assert.match(await p.locator('.suggested-action').innerText(),/Grow your Skeleton/);
  await p.locator('[data-action="undoPurchase"]').click();assert.equal(C.unpack(await read(p)).n.skeletons.num(),0);assert.match(await p.locator('.suggested-action').innerText(),/first Skeleton/);
  await p.locator('[data-action="guideNext"]').click();assert.match(await p.locator('#firstSteps').innerText(),/2 of 4/i);
  await p.reload();await p.locator('#firstStepsTitle').waitFor();assert.match(await p.locator('#firstSteps').innerText(),/2 of 4/i,'resume on reload');
  await p.locator('[data-action="guideBack"]').click();assert.match(await p.locator('#firstSteps').innerText(),/1 of 4/i);
  await p.locator('[data-action="guideNext"]').click();await p.locator('[data-action="guideOpen"]').click();assert.match(await p.locator('#content h2').innerText(),/Necromancers/);
  await p.locator('[data-action="guideNext"]').click();assert.match(await p.locator('#firstSteps').innerText(),/3 Necromancers/);await p.locator('[data-action="guideOpen"]').click();assert.match(await p.locator('#content h2').innerText(),/Legacy/);
  await p.locator('[data-action="guideNext"]').click();await p.locator('[data-action="guideOpen"]').click();assert(await p.locator('[data-action="makeSaveCode"]').isVisible());
  await p.locator('[data-action="guideNext"]').click();assert(await p.locator('#firstSteps').isHidden());
  await p.reload();await p.locator('#tabs button').first().waitFor();assert(await p.locator('#firstSteps').isHidden());assert(await p.locator('.suggested-action').isVisible());
  if(width<500){await p.locator('[data-action="backupReminder"]').click();assert.equal(await p.evaluate(()=>document.activeElement.dataset.action),'makeSaveCode');}
  else await p.locator('#tabs [data-tab="options"]').click();
  await p.locator('[data-action="makeSaveCode"]').click();await p.waitForFunction(()=>document.getElementById('portableSaveCode').value.startsWith('NECRO-SAVE-8.'));assert(await p.locator('#portableSaveCode').inputValue());
  await p.locator('[data-action="guideReplay"]').click();assert.match(await p.locator('#firstSteps').innerText(),/1 of 4/i);
  await p.locator('[data-action="guideSkip"]').focus();await p.keyboard.press('Enter');assert(await p.locator('#firstSteps').isHidden());
  await p.locator('[data-action="suggestedAction"]').click();assert.equal(await p.locator('[data-undead-section]').getAttribute('data-undead-section'),'recruitment');
  assert(await p.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));
  const clipped=await p.evaluate(()=>[...document.querySelectorAll('#tabs .tab-label,#firstSteps p,#goal p,#goal .goal-top strong,#content p')].filter(el=>el.getClientRects().length).flatMap(el=>{const range=document.createRange();range.selectNodeContents(el);const text=range.getBoundingClientRect(),box=el.matches('.tab-label')?el.closest('button').getBoundingClientRect():el.getBoundingClientRect();return text.right>box.right+1||text.left<box.left-1?[el.textContent]:[];}));
  assert.deepEqual(clipped,[],'descriptions and navigation labels fit their containers');
  if(process.env.NECRO_SCREENSHOT_DIR){await p.locator('#tabs [data-tab="options"]').click();await p.locator('[data-action="guideReplay"]').click();await p.screenshot({path:path.join(process.env.NECRO_SCREENSHOT_DIR,`first-steps-${width}-${theme}.png`),fullPage:true});}
  await ctx.close();console.log(`PASS ${width}px ${theme}: tour, actual purchase/undo, resume, completion, replay/skip, next action, external save code`);
 }
 // Existing and ascended games are not forced through the tour; hints follow unlocks.
 for(const necros of [0,1,3,5]){
  const state=C.fresh();state.n.skeletons=C.N.of(100);state.n.total_skeletons=C.N.of(100);state.n.necromancers=C.N.of(necros);state.n.total_necromancers=C.N.of(necros);
  const {ctx,p}=await open({state});assert(await p.locator('#firstSteps').isHidden());
  assert.equal(await p.locator('#tabs [data-tab="energy"]').count(),necros>=3?1:0);
  const text=await p.locator('.suggested-action').innerText();assert.match(text,necros===0?/first Necromancers/:necros===1?/3 Necromancers/:necros===3?/Grow Necromancers/:/Grave Raiders/);
  await p.locator('[data-action="suggestedAction"]').click();assert.equal(await p.locator('#tabs [aria-current="page"]').getAttribute('data-tab'),necros===5?'territory':'undead');await ctx.close();
 }
 const state=C.fresh();state.prestiges=1;const old=await open({state,ipad:true});assert(await old.p.locator('#firstSteps').isHidden());assert(await old.p.locator('#mobileSaveNotice').isVisible());await old.ctx.close();
 assert.deepEqual(errors,[]);console.log('PASS existing/ascended saves, progression hints, Dark Energy unlock explanation, iPad detection; no browser errors');
}finally{await browser.close();server.close();}
})().catch(e=>{console.error(e);server.close();process.exitCode=1;});
