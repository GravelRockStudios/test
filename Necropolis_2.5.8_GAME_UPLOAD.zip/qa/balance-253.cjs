// Compare an explicitly supplied previous build using the same earned-resource policy.
// NECRO_BASELINE_HTML=/path/to/2.5.2/index.html node qa/balance-253.cjs
const fs=require('fs'),path=require('path');
if(!process.env.NECRO_BASELINE_HTML)throw Error('Set NECRO_BASELINE_HTML to the previous build index.html');
function load(html){const m={exports:{}};new Function('module','exports',html.match(/<script[^>]*>([\s\S]*?)<\/script>/)[1])(m,m.exports);return m.exports;}
const engines={before:load(fs.readFileSync(process.env.NECRO_BASELINE_HTML,'utf8')),after:require('./extract-core.cjs')};
const modelCode=fs.readFileSync(path.join(__dirname,'balance-model.cjs'),'utf8').replace('s.energy>=2000','s.energy>=C.WARP[.25]');
const results={};
for(const [name,C] of Object.entries(engines)){
 const m={exports:{}};new Function('require','module','exports','__dirname',modelCode)(id=>id.includes('extract-core')?C:require(id),m,m.exports,__dirname);
 results[name]=[];
 for(const doctrine of ['none','horde','lich'])for(const warps of [false,true]){
 const r=m.exports.run({minutes:5,doctrine,warps},C.fresh(),'ascend',86400*3).summary;
 results[name].push(r);console.log(name,doctrine,warps,JSON.stringify({hours:r.hours,tiers:r.firstTierHours,warps:r.warpCount,rate:r.seedRatePerSecond}));
 }
}
fs.writeFileSync(path.join(__dirname,'balance-2.5.3.json'),JSON.stringify({assumptions:'Same feasibility strategy, five-minute check-ins, earned resources only; warp policy reads each build cost. Fresh first ascension, 3-day horizon. Not a prediction of player timings.',results},null,2));
