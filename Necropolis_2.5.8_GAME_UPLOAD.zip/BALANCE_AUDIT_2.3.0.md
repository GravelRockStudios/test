# Necropolis 2.3.0 — conquest correctness and economy audit

Reviewed October 1, 2026 (America/New_York). Includes the 2.2.5 Seed display update.

## The actual conquest bug

The previous fixes improved the campaign estimator but missed a separate mutation bug in the UI. `projectionAt()` copied the outer Empire object while sharing its nested campaign object with the live save. Affordability previews simulated future production on that partial copy. Crossing a campaign boundary changed the real campaign's progress, completion list, stage and active target. Opening a screen or buying an upgrade triggered more previews and could award a victory without the required elapsed time.

The fix uses `C.copyState(s)` before advancing a preview. Regression tests execute the actual UI function. They fail against the old HTML and pass against this build. A browser fixture starts a 48-hour campaign, visits Territory, Dark Energy and Empire, then persists state: it must still have zero progress at a frozen clock. Buy Max correctly changes its estimate; Undo restores the original estimate. Verified at 390 and 1440 pixels.

A purchase can still legitimately reduce a countdown drastically. An estimate describes current production, natural army growth and configured buyers; it cannot predict the player's future manual purchases or Time Warps. Targets stay fixed after purchases. We do not move the finish line to punish an upgrade. Existing campaign progress and victories are preserved because a save cannot distinguish legitimate wins from wins caused by the old bug.

## Mathematical model

Let x_i be the owned count of tier i and a_i its effective production of the tier below. Between purchases, the chain follows dx_(i-1)/dt = a_i x_i. A top-tier contribution reaches lower tiers through terms proportional to t^k/k!, multiplied by the rates along that path. Souls are the integral of harvesting Skeletons. A fixed ten-tier chain therefore has polynomial growth between decisions, not an endlessly compounding exponential rate.

Territory combines fixed specialist troop production with the integral of Skeletons assigned to conquest. Campaign completion solves:

    allocation × TerritoryGained(t) >= target − committed

The engine brackets and bisects this monotone function. Automatic purchases split time at their actual five-minute cycle boundaries. Online and offline forecasts differ only when buyer settings differ. Long automated forecasts may display a proven lower bound instead of pretending to know an exact result beyond the preview budget. Offline simulation itself is uncapped.

Upgrade costs use geometric sums for multi-buy. Unit recipes remain flat per batch. These are intentionally different rules. Neither owned counts nor old paid ranks are repriced or removed.

An upgrade's practical value is the reduction in time to the player's next objective, after paying its costs. A nominal bonus is insufficient evidence: more Souls do not help a Seed-only shortage, and Multiplicity helps future purchases rather than existing production. Compare full effective rates and resource shortfalls, not percentages in isolation.

## Changes and reasons

### 1. Give surplus Souls a purpose

Early prices through Deathlords stay unchanged. Later Soul prices now correspond more closely to what the generator chain can actually produce:

| Tier | Previous Souls per batch | New Souls per batch |
|---|---:|---:|
| Dreadlords | 2e10 | 2e12 |
| Grave Kings | 5e12 | 5e17 |
| Eternal Sovereigns | 2e15 | 2e23 |
| Void Regents | 1e18 | 1e29 |
| Endbringers | 1e21 | 1e35 |

The associated Empowerment Soul cost and Multiplicity price use the same tier cost source. Owned armies, paid upgrades and predecessor recipes remain intact. In the baseline active Horde model, the run had earned about 1.4e32 Souls by its first Endbringer, versus that unit's 1e21 Soul cost. The new model reaches it after earning about 1.85e35 against a 1e35 cost. Those totals include spent Souls and are not the same as wallet balances.

We rejected a steeper candidate ending at 1e48: active profiles reached it after about 63–64 hours, but infrequent and no-warp profiles failed to reach it within the 90-day test horizon. That would have made warping too close to mandatory. The shipped curve passes every tested no-ascension profile within 90 days.

### 2. Better returns from investing Souls in Seeds

Cultivation production, before other bonuses, changes from 1 + L to:

    1 + L + 0.05 L² Seeds/second

| Cultivation level | Old /second | New /second |
|---:|---:|---:|
| 0 | 1 | 1 |
| 1 | 2 | 2.05 |
| 10 | 11 | 16 |
| 30 | 31 | 76 |

Cultivation still costs 300 × 10^L Souls. Exponential prices outrun quadratic output, so this does not create free self-funding runaway growth. Expansion, Gravefields, research, doctrine and logarithmic Grave Offerings continue to affect the result. The UI shows actual total output before and after an upgrade, including these bonuses.

### 3. Conquest recruitment has a resource tradeoff

| Troop tier | Seeds per batch | Territory/second per unit, before bonuses |
|---|---:|---:|
| Grave Raiders | 1 | 0.07 |
| Bone Legions | 10 | 3.15 |
| Dread Marshals | 100 | 141.75 |
| Death Hosts | 1,000 | 6,378.75 |
| Eternal War Councils | 10,000 | 287,043.75 |

Previously every tier cost one Seed while each produced 45 times more Territory. Now each step costs ten times more Seeds, making higher tiers 4.5 times as Seed-efficient. Soul costs rise 450-fold per tier, so lower troops remain ten times more Soul-efficient per step. Multiplicity changes output per batch, and the preview includes Horde's extra unit. Existing troops are kept.

This reduces one source of explosive stockpile conversion. It does not guarantee a target will take a fixed number of hours: stockpiles and the Skeleton army can still make an affordable target fast.

### 4. Campaign rewards support distinct paths

- Forgotten Cemetery improves Gravefields and Seed production.
- Ruined Academy unlocks Grave Studies and now also improves Crypts using the campaign plot curve. Repeated victories continue to improve Excavation Insight. The Crypts effect makes Academy rewards useful to army growth, Souls, conquest and Excavation through the production chain.
- Black Spire improves Obelisks and Time Warp duration.

Plot bonus = 0.2 + 0.1 log2(1 + victories). Campaign targets remain base × 10^victories. Rewards therefore have diminishing marginal gains and cannot compound exponentially per victory. Academy's first victory raises each Crypt's Necromancer/Lich bonus from 20% to 30%. With five Crypts and no other bonuses, that changes each affected producer's factor from 2 to 2.5: a 25% actual increase. With more existing bonuses the relative increase is smaller; the UI's actual output preview reflects that.

Campaign cards show current → next effects, one effect per line. Zero → zero Insight text is omitted on the first Academy victory. Plot rewards need the corresponding developed plots; they are not standalone global multipliers.

### 5. Clearer output and spending information

- Upgrade comparisons show full effective Seed rates, Energy regeneration or production per unit, rather than isolated bonus components.
- Multiplicity includes the chosen doctrine's actual batch size.
- Territory Development shows the next plot's production effect; development controls align at the bottom of their cards.
- Campaign estimates state that purchases and warps can change the wait.
- Retained 2.2.5's Seed buyer-spending estimate. Fixed negative net display: the quantity class clamps subtraction to zero, so the sign must be determined by comparing spending with production before subtracting magnitudes. The tooltip identifies this as a buyer snapshot averaged over five minutes, not guaranteed future net production.

## Simulated progression

These are strategy samples using the actual game engine, not a promise of player completion times. Each check-in allows one affordable upgrade of each relevant kind, one development, one warp, and the model's recruitment decisions. The strategy assigns 20% of Skeletons to conquest and 10% to Excavation, preserves a Seed budget for the next tier and spends only 1% of surplus Seeds on specialist conquest recruitment. The earlier one-Seed budgeting assumption was corrected when troop prices changed. Ordinary models leave buyers off; separate tests enable them.

### First Endbringer without ascending

| Strategy | 2.2.4 hours | 2.3.0 hours |
|---|---:|---:|
| Horde, every 5 minutes, warps | 6.67 | 8.42 |
| Lich Dominion, every 5 minutes, warps | 9.42 | 10.25 |
| Soul Cult, every 5 minutes, warps | 9.92 | 10.58 |
| Horde, every 8 hours, warps | 400 | 472 |
| Lich Dominion, every 8 hours, warps | 560 | 584 |
| Soul Cult, every 8 hours, warps | 552 | 592 |
| Horde, every 5 minutes, no warps | 428.83 | 764.5 |
| Horde, every 8 hours, no warps | 584 | 904 |

The large active/idle difference is caused by additional purchases and warp casts, plus this model's restricted number of actions per check-in. It is not an offline production penalty. The existing elapsed-time equivalence tests still pass. More thorough spending during an infrequent visit can outperform this deliberately simple policy.

With automatic buyers enabled, the additional Horde samples reach Endbringers in 6.75 hours at five-minute check-ins and 528 hours at eight-hour check-ins. Automation spends reserves on current units and is not always optimal for saving toward the next unlock.

### Do research choices change outcomes?

Holding the spending policy constant, comparing four research choices gives these first-Endbringer times:

| Doctrine | Grave Studies | Bonebinding | Warcraft | Night Studies |
|---|---:|---:|---:|---:|
| Horde | 8.42 h | 8.00 h | 8.33 h | 8.17 h |
| Lich Dominion | 10.25 h | 10.17 h | 10.25 h | 9.92 h |
| Soul Cult | 10.58 h | 10.33 h | 10.33 h | 10.25 h |

This comparison uses hourly 10% offerings for Soul Cult. Bonebinding or Night Studies can beat a Seed focus once Souls and predecessor units matter. In the baseline Horde/Grave Studies sample, none of the observed later-tier check-ins lacked the Soul price; in the new sample 59 of 88 did. Multiple ingredients may be missing at once, so these counts are not mutually exclusive waiting-time shares. These models conserve Seeds deliberately; they do not prove Seed shortages have disappeared for players who buy lower tiers aggressively.

### Ascension feasibility

The five-minute Horde strategy completed 120 ascensions in about 12.56 simulated days, versus 12.88 previously. The eight-hour strategy completed 86 within its approximately one-year horizon versus 85 previously. Later ascensions remain achievable; a final tier is not required for every reset. These results establish feasibility, not balanced retention or optimal prestige timing.

## What this does and does not establish

This build fixes a demonstrated state-corruption bug and gives resource investments measurable jobs. It does not establish that every doctrine is equally optimal, that every existing endgame save will have the same pacing, or that the game has months of engaging content. Horde remains fast early; late repeat campaign bonuses still diminish. The selected costs deliberately avoid converting the final tier into a mandatory-warp wall.

For future games, keep production, spending, forecasting and reward transitions in one shared economy module. Require forecast purity, active/offline equivalence, conservation at reward boundaries, stable save migrations and whole-cost affordability. Evaluate progression using multiple policies and objectives—first unlock, shards per hour, seed efficiency, time to campaign completion—not a single giant-number screenshot. Validate enjoyment and repeat-session retention with playtests after mathematical feasibility passes.

## Sources reviewed

- [Kongregate, The Math of Idle Games, Part I](https://kongregatedev.ghost.io/the-math-of-idle-games-part-i/): geometric costs, production/cost comparisons and shifting investment priorities. The constants here were calibrated against Necropolis, not copied from another game's example.
- [Kongregate, Part II](https://kongregatedev.ghost.io/the-math-of-idle-games-part-ii/): directly relevant generator-of-generators model and its polynomial integration. This is a better structural match for Necropolis than a collection of independent income generators.
- [Kongregate, Part III](https://kongregatedev.ghost.io/the-math-of-idle-games-part-iii/): prestige incentives and the distinction between maximum, lifetime and run-based measures.
- [ClickerGames article supplied in the request](https://clickergames.io/blog/idle-game-math/): useful overview; not used as authority for a universal multiplier or growth rule. Necropolis's finite derivative chain is modeled explicitly.
- [Supplied incremental-games discussion](https://www.reddit.com/r/incremental_games/comments/mut60p/help_with_the_mathematics_of_an_idle_game/): design context concerning intermediate-resource bottlenecks. Community discussion is not a substitute for this game's simulation evidence.

Reproduction: `node qa/balance-model.cjs`, `node qa/choice-model.cjs`, and the tests listed in QA_2.3.0.md. `qa/baseline-2.2.4.cjs` preserves the original economy for comparison; 2.2.5 changed its UI only. Use `NECRO_MODEL_CORE=./baseline-2.2.4.cjs` and an alternate output path to reproduce baseline samples. Raw results accompany this report.
