# Necropolis 2.4.0 — player feedback and Astra review

Reviewed the four player requests against the current 2.3.1 upload. The goal is to relieve a frustrating Seed bottleneck and automate repeat work while preserving the incremental, AFK progression loop. This package has not been published to itch.io.

## Player changes

- **Grave Bloom:** a permanent blessing in Ascension costing one Lich Shard per upgrade. All Grave Seed production is multiplied by `1 + 0.5 × level^0.75`. The first upgrade gives 1.5×, four give 2.414×, and sixteen give 5×. Marginal gains diminish. The bonus applies to active production, offline progress and Time Warp, and survives ascension. No other ascension reward or requirement curve changed.
- **Complete eligible buyers:** all ten undead tiers have Empowerment and Multiplicity switches. Seed Cultivation, Seed Expansion, the three Energy upgrades, and both Conquest upgrades in all five tiers also have buyers: 35 supported upgrade switches altogether. All ten undead unit buyers and five Conquest unit buyers are available after their respective unlocks. Retired production research and permanent Shard purchases are not silently automated.
- **One resource reserve:** upgrades and recruits share the same five-minute cycle and reserve across Souls, Seeds, Territory and consumed predecessor units. Before discretionary spending, the group earmarks one batch for its highest selected unit. An unaffordable high-priority batch can accumulate ingredients instead of repeatedly losing them to cheaper buyers. New choices start Off. Ascension pauses the master and drops choices that are locked in the new run.
- **Automatic Conquest:** Territory offers manual selection, repeating the current target, or rotating Cemetery → Academy → Spire. Rotation repeats at higher stages. Both modes use exact completion boundaries, apply each earned reward at that boundary, and continue through offline time and warps. Pausing disables continuation. The chosen mode/focus survives ascension and starts again at the 25-Territory unlock. Targets still increase tenfold and rewards remain logarithmic.
- **Useful specialist troops:** Conquest troops retain their base output and add diminishing command support from the growing Skeleton host. Higher Conquest tiers command larger shares. The existing assigned Skeleton production is preserved. Conquest Empowerment is now visible, spends Souls and Territory, and keeps troops. Existing troops and previously paid upgrade levels are retained.

## Astra findings fixed

1. Very fast late-game campaigns could lose timing precision when the solver bisected an entire long offline interval. The solver now brackets completion using its actual production polynomial before bisection.
2. Cheap buyers could prevent an expensive selected buyer from ever accumulating enough Seeds. Batch earmarks prevent this starvation without bypassing reserves.
3. Exhausted stage-1024 campaigns now stop safely within the existing save validation range.
4. The new Conquest automation section initially collapsed on every render. Both Automation sections now retain their open/closed state during ticks, toggles and tab changes. Direct browser tests cover the behavior.

Astra independently checked 144 V8 combinations and 100 saves produced by the untouched 2.3.1 V7 encoder. No save defect was found. The frozen V6/V7 dictionaries remain unchanged.

## Pacing evidence

A sample advanced Horde build with Cultivation 30, Expansion 60, 20 Gravefields, Grave Studies 30 and 20 Cemetery victories makes 12,159.28 Seeds/s before Grave Bloom. Sixteen Grave Bloom upgrades increase it to 60,796.41/s. A Seed-only wait for a 1-billion-Seed Endbringer batch falls from 22.84 to 4.57 hours; other purchase requirements still apply.

With `1e30` Skeletons, 20% assigned to conquest, and troop counts 100/75/50/25/10, the five troop types add 25%/37.5%/50%/75%/125% of assigned-Skeleton production. This measures a funded late-game example, not an automatic grant or a guarantee that one new troop outproduces an entire army.

The earned-resource Horde model checking every five minutes and casting at most one warp per visit keeps the first ascension at 1.083 hours. First Endbringer time is 8.33 hours versus 8.42 hours in the original build without purchasing Grave Bloom. Eight-hour visit samples are recorded separately in `qa/afk-balance-2.4.0.json`. These are reproducible strategy samples, not predictions of individual player pace.

The game still generates resources through elapsed time, has escalating purchase costs and campaign targets, and does not require active clicks for production. Offline gains are uncapped. Automation spends earned resources under chosen settings; Time Warp still spends real Dark Energy and does not generate Energy during simulated time.

## Verification

All listed checks passed against the assembled release:

| Suite | Evidence |
| --- | --- |
| `qa/verify.cjs` | 40 core scenarios: production, currencies, unlocks, reserves, ascension and warp |
| `qa/progression.cjs` | 14 Empire and progression scenarios |
| `qa/enduring.cjs` | 12 permanent/campaign progression scenarios |
| `qa/conquest-timing.cjs` | Six live/offline/automation forecast groups |
| `qa/progression-audit.cjs` | Price, reward, efficiency and purchase-boundary checks |
| `qa/preview-isolation.cjs` | Nine state-isolation fixtures and signed Seed-budget display |
| `qa/report-231.cjs` | Seven prior-report regression groups |
| `qa/review-240.cjs` | 15 Astra review groups, including all 35 upgrades/all 15 units, starvation, exact handoffs and stage limits |
| `qa/save-code.cjs` | 100 precision fixtures, history/timestamps, legacy formats, checksums and malformed binary rejection |
| `qa/portable-240.cjs` | 36 new-format combinations, damaged metadata rejection, and actual untouched 2.3.1 V7 imports |
| `qa/rendering.cjs` | Templates, grammar, locked buyers and JavaScript syntax |
| `qa/report-browser-231.cjs` | Prior report navigation, buyer unlocks, per-unit rates, notifications, ascension and warp at 390px/1440px |
| `qa/preview-browser.cjs` | 48-hour preview isolation, Buy Max ETA refresh and Undo at both widths |
| `qa/conquest-browser.cjs` | Sandboxed iframe live/offline estimates, allocations, buyer cycles and warp at both widths |
| `qa/wording-browser.cjs` | Feature names, research/development actions, rewards and current Options version at both widths |
| `qa/feedback-browser-240.cjs` | Every new switch, real buyer cycle, accordion state, reload, V8 export/restore, ascension, rotation, warp and pause at both widths |
| `qa/feedback-balance-240.cjs` | Seed relief, late Conquest relevance and an earned-resource fresh progression sample |

Browser tests used headless Chromium and isolated synthetic saves in sandboxed iframes. No JavaScript page errors or horizontal document overflow occurred in the passing suites. The Seed blessing, Automation layout and campaign controls were visually inspected at mobile and desktop widths. The separate historic broad `qa/browser.cjs` suite was not rerun for this release. No claim is made of live itch.io or iPhone Safari playtesting.

Save schema is 23; portable exports use NECRO-SAVE-8. Existing V1–V7 codes remain supported. New exports intentionally reject in older builds, protecting new paid upgrades from being silently discarded by a downgrade. All original PNG/SVG artwork and LICENSE.txt are byte-identical to the 2.3.1 package.

## Install

Keep an external save backup, then upload `Necropolis_2.4.0_upload.zip` as the itch.io HTML game. `index.html` is at the archive root. Find Grave Bloom in Ascension, choose buyers in Automation, and select automatic campaign continuation in Territory. Offline buying is separately selectable; campaign continuation uses its own Territory setting.
